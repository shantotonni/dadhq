import Vue from 'vue'
import VueRouter from 'vue-router'
import Login from '../views/auth/Login.vue'
import Main from '../components/layouts/Main'
import Dashboard from '../views/dashboard/Index.vue'
import Sessions from '../views/sessions/Index'
import AcademicYears from "../views/years/Index"
import SessionFees from "../views/session_fees/Index"
import SessionHead from "../views/session_head/Index"
import StudentList from "../views/students/Index"
import StudentBillList from "../views/student_bill/Index"
import StudentBillPaymentList from "../views/student_bill_payment/Index"
import StudentBillPaymentCreate from "../views/student_bill_payment/Create"
import StudentBillPaymentEdit from "../views/student_bill_payment/Edit"
import StudentBillPaymentView from "../views/student_bill_payment/View"
import StudentBillPaymentPrint from "../views/student_bill_payment/Print"
import CategoryList from "../views/category/Index"
import BankList from "../views/bank/Index"
import BranchList from "../views/branch/Index"
import UserList from '../views/users/Index'
import Head from '../views/head/Index'
import MenuList from '../views/menu/List'
import MenuPermission from '../views/users/MenuPermission'
import HostelFeeList from "../views/hostel_fee/Index"
import HostelFeeInvoicePrint from "../views/hostel_fee/Print"
import HostelStudentList from "../views/hostel_fee/HostelStudentList.vue"
import PurposeList from "../views/purpose/Index"
import MiscellaniousList from "../views/miscellanious/Index"
import MiscellaniousPrint from "../views/miscellanious/MiscellaniousPrint"
//Report
import StudentPaymentReport from "../views/report/Index"
import StudentWiseSeparateReport from "../views/report/StudentWiseSeparateReport"
import StudentReportPrint from "../views/report/Print"
import HostelReportPrint from "../views/report/HostelReportPrint.vue"
import StudentHostelBillReport from "../views/report/HostelBillReport"
import StudentWiseSeparateReportDetails from "../views/report/StudentWiseSeparateReportDetails"
import StudentPaymentReportDetails from "../views/report/StudentPaymentReportDetails"
import StudentHostelReportDetails from "../views/report/StudentHostelReportDetails"
import HeadWisePaymentReport from "../views/report/HeadWisePaymentReport"
import StudentIndividualReport from "../views/report/StudentIndividualReport"
import HeadWisePaymentReportPrint from "../views/report/HeadWisePaymentReportPrint"


import NotFound from '../views/404/Index';
// import Profile from '../views/profile/Index';
import {baseurl} from '../base_url'

Vue.use(VueRouter);

const config = () => {
    let token = localStorage.getItem('token');
    return {
        headers: {Authorization: `Bearer ${token}`}
    };
}
const checkToken = (to, from, next) => {
    let token = localStorage.getItem('token');
    if (token === 'undefined' || token === null || token === '') {
        next(baseurl + 'login');
    } else {
        next();
    }
};

const activeToken = (to, from, next) => {
    let token = localStorage.getItem('token');
    if (token === 'undefined' || token === null || token === '') {
        next();
    } else {
        next(baseurl);
    }
};

const routes = [
    {
        path: baseurl,
        component: Main,
        redirect: {name: 'Dashboard'},
        children: [
            //DASHBAORD
            {
                path: baseurl + 'dashboard',
                name: 'Dashboard',
                component: Dashboard
            },
            //SESSION SETTINGS
            {path: baseurl + 'sessions-list', name: 'Sessions', component: Sessions},
            {path: baseurl + 'sessions-academic-years', name: 'AcademicYears', component: AcademicYears},
            {path: baseurl + 'sessions-fees', name: 'SessionFees', component: SessionFees},
            {path: baseurl + 'head-list', name: 'Head', component: Head},
            {path: baseurl + 'session-head-list', name: 'SessionHead', component: SessionHead},
            {path: baseurl + 'student-list', name: 'StudentList', component: StudentList},
            {path: baseurl + 'student-bill-list', name: 'StudentBillList', component: StudentBillList},
            {path: baseurl + 'category-list', name: 'CategoryList', component: CategoryList},
            {path: baseurl + 'bank-list', name: 'BankList', component: BankList},
            {path: baseurl + 'branch-list', name: 'BranchList', component: BranchList},
            {path: baseurl + 'user-list', name: 'UserList', component: UserList},
            {path: baseurl + 'hostel-fee-list', name: 'HostelFeeList', component: HostelFeeList},
            {path: baseurl + 'hostel-fee-invoice/:id', name: 'HostelFeeInvoicePrint', component: HostelFeeInvoicePrint},

            //menu vue route
            {path: baseurl + 'menu-list', name: 'MenuList', component: MenuList},
            {path: baseurl + 'user-menu-permission', name: 'UserMenuPermission', component: MenuPermission},

            //student bill payment
            {path: baseurl + 'student-bill-payment-list', name: 'StudentBillPaymentList', component: StudentBillPaymentList},
            {path: baseurl + 'student-bill-payment-create', name: 'StudentBillPaymentCreate', component: StudentBillPaymentCreate},
            {path: baseurl + 'student-bill-payment-edit/:id', name: 'StudentBillPaymentEdit', component: StudentBillPaymentEdit},
            {path: baseurl + 'student-bill-payment-view/:id', name: 'StudentBillPaymentView', component: StudentBillPaymentView},
            {path: baseurl + 'student-bill-payment-invoice/:id', name: 'StudentBillPaymentPrint', component: StudentBillPaymentPrint},
            {path: baseurl + 'student-report-print', name: 'StudentReportPrint', component: StudentReportPrint},
            {path: baseurl + 'student-hostel-report-details/:roll_no/:batch_number', name: 'StudentHostelReportDetails', component: StudentHostelReportDetails},
            {path: baseurl + 'hostel-report-print', name: 'HostelReportPrint', component: HostelReportPrint},
            {path: baseurl + 'student-payment-report', name: 'StudentPaymentReport', component: StudentPaymentReport},
            {path: baseurl + 'head-wise-payment-report', name: 'HeadWisePaymentReport', component: HeadWisePaymentReport},
            {path: baseurl + 'head_wise_payment_report_print/:sessionId/:roll_no/:studentBatch', name: 'HeadWisePaymentReportPrint', component: HeadWisePaymentReportPrint},
            {path: baseurl + 'student-wise-separate-report', name: 'StudentWiseSeparateReport', component: StudentWiseSeparateReport},
            {path: baseurl + 'details-student-bill-payment-report/:student_id', name: 'StudentWiseSeparateReportDetails', component: StudentWiseSeparateReportDetails},
            {path: baseurl + 'student-payment-report-details/:roll_no/:batch_number', name: 'StudentPaymentReportDetails', component: StudentPaymentReportDetails},
            {path: baseurl + 'hostel-bill-report', name: 'StudentHostelBillReport', component: StudentHostelBillReport},
            {path: baseurl + 'hostel-student-list', name: 'HostelStudentList', component: HostelStudentList},
            //Miscellaneous
            {path: baseurl + 'purpose-list', name: 'PurposeList', component: PurposeList},
            {path: baseurl + 'miscellanious-list', name: 'MiscellaniousList', component: MiscellaniousList},
            {path: baseurl + 'miscellaneous-invoice/:id', name: 'MiscellaniousPrint', component: MiscellaniousPrint},

            //new report /
            {path: baseurl + 'student-individual-report', name: 'StudentIndividualReport', component: StudentIndividualReport},
        ],
        beforeEnter(to, from, next) {
            checkToken(to, from, next);
        }
    },
    {
        path: baseurl + 'login',
        name: 'Login',
        component: Login,
        beforeEnter(to, from, next) {
            activeToken(to, from, next);
        }
    },
    {
        path: baseurl + '*',
        name: 'NotFound',
        component: NotFound,
    },
]

const router = new VueRouter({
    mode: 'history',
    base: process.env.baseurl,
    routes
});

router.afterEach(() => {
    $('#preloader').hide();
});

export default router
