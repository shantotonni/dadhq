export default {
    me(state) {
        return state.me;
    },
    getAllUserMenu(state){
        return state.allUserMenu
    },
}
