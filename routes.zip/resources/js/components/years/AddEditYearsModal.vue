<template>
  <div>
    <div class="modal fade" id="add-edit-years" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <div class="modal-title modal-title-font" id="exampleModalLabel">{{ title }}</div>
          </div>
          <ValidationObserver v-slot="{ handleSubmit }">
            <form class="form-horizontal" id="form" @submit.prevent="handleSubmit(onSubmit)">
              <div class="modal-body">
                <div class="row">
                  <div class="col-6 col-md-6">
                    <ValidationProvider name="name" mode="eager" rules="required" v-slot="{ errors }">
                      <div class="form-group">
                        <label for="name">Payment Mode Title</label>
                        <input type="text" class="form-control" id="name" :class="{'error-border': errors[0]}"
                               v-model="name" name="name" placeholder="Enter Title" autocomplete="off">
                        <span class="error-message"> {{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>
                  <div class="col-6 col-md-6">
                    <ValidationProvider name="status" mode="eager" rules="required" v-slot="{ errors }">
                      <div class="form-group">
                        <label for="status">Status</label>
                        <select name="status" v-model="status" class="form-control" id="status">
                          <option value="Y">Active</option>
                          <option value="N">Deactivate</option>
                        </select>
                        <span class="error-message"> {{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>
                  <div class="col-6 col-md-6">
                    <ValidationProvider name="ordering" mode="eager" rules="required" v-slot="{ errors }">
                      <div class="form-group">
                        <label for="ordering">Ordering</label>
                        <input type="number" class="form-control" id="ordering" :class="{'error-border': errors[0]}" v-model="ordering" name="ordering" placeholder="0" autocomplete="off">
                        <span class="error-message"> {{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>
                  <div class="col-6 col-md-6">
                    <ValidationProvider name="year_serial" mode="eager" rules="required" v-slot="{ errors }">
                      <div class="form-group">
                        <label for="year_serial">Year serial</label>
                        <input type="number" class="form-control" id="year_serial" :class="{'error-border': errors[0]}" v-model="year_serial" name="year_serial" placeholder="0" autocomplete="off">
                        <span class="error-message"> {{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <submit-form :name="buttonText"/>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </form>
          </ValidationObserver>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import {bus} from "../../app";
import {Common} from "../../mixins/common";
import {mapGetters} from "vuex";

export default {
  mixins: [Common],
  // components: {Multiselect},
  data() {
    return {
      title: '',
      yearId: '',
      name: '',
      year_serial: '',
      ordering: '',
      status: '',
      type: 'add',
      actionType: '',
      buttonShow: false,
      buttonText: ''
    }
  },
  computed: {},
  created() {
    // this.getData();
  },
  mounted() {
    $('#add-edit-years').on('hidden.bs.modal', () => {
      this.$emit('changeStatus')
    });
    bus.$on('add-edit-years', (row) => {
      if (row) {
        console.log('row',row)
        let instance = this;
        this.axiosGet('years/by-id/'+row.year_id,function(response) {
          var data = response.data;
          instance.title = 'Update Payment Mode';
          instance.buttonText = "Update";
          instance.yearId = data.year_id;
          instance.name = data.name;
          instance.year_serial = data.year_serial;
          instance.ordering = data.ordering;
          instance.status = data.status;
          instance.buttonShow = true;
          instance.actionType = 'edit';
        },function(error){

        });
      } else {
        this.title = 'Add Payment Mode';
        this.buttonText = "Create";
        this.name = '';
        this.year_serial = '';
        this.ordering = '';
        this.status = 'Y';
        this.actionType = 'add'
      }
      $("#add-edit-years").modal("toggle");
      // $(".error-message").html("");
    })
  },
  destroyed() {
    bus.$off('add-edit-years')
  },
  methods: {
    onSubmit() {
      this.$store.commit('submitButtonLoadingStatus', true);
      let url = '';
      if (this.actionType === 'add') url = 'years/create';
      else url = 'years/update/'+this.yearId
      this.axiosPost(url, {
        name: this.name,
        ordering: this.ordering,
        year_serial: this.year_serial,
        status: this.status,
      }, (response) => {
        this.successNoti(response.message);
        $("#add-edit-years").modal("toggle");
        bus.$emit('refresh-datatable');
        this.$store.commit('submitButtonLoadingStatus', false);
      }, (error) => {
        this.errorNoti(error);
        this.$store.commit('submitButtonLoadingStatus', false);
      })
    }
  }
}
</script>

<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
