<template>
  <div>
    <div class="modal fade" id="add-edit-session-head" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <div class="modal-title modal-title-font" id="exampleModalLabel">{{ title }}</div>
          </div>
          <ValidationObserver v-slot="{ handleSubmit }">
            <form class="form-horizontal" id="form" @submit.prevent="handleSubmit(onSubmit)">
              <div class="modal-body">
                <div class="row">
                  <div class="col-6 col-md-6">
                    <ValidationProvider name="session" mode="eager" rules="required" v-slot="{ errors }">
                      <div class="form-group">
                        <label for="session_id">Session</label>
                        <select v-model="session_id" name="session_id" id="session_id" class="form-control" :class="{'error-border': errors[0]}">
                          <option value="">Select Session</option>
                          <option :value="session.session_id" v-for="(session,index) in sessions" :key="index">{{session.name}}</option>
                        </select>
                        <span class="error-message"> {{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>
                  <div class="col-6 col-md-6">
                    <ValidationProvider name="session" mode="eager" rules="required" v-slot="{ errors }">
                      <div class="form-group">
                        <label for="head_id">Head</label>
                        <select v-model="head_id" name="head_id" id="head_id" class="form-control" :class="{'error-border': errors[0]}">
                          <option value="">Select Head</option>
                          <option :value="head.head_id" v-for="(head,index) in heads" :key="index">{{head.name}}</option>
                        </select>
                        <span class="error-message"> {{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>
                  <div class="col-6 col-md-6">
                    <ValidationProvider name="amount" mode="eager" rules="required" v-slot="{ errors }">
                      <div class="form-group">
                        <label for="amount">Amount</label>
                        <input v-model="amount" type="text" class="form-control" id="amount" :class="{'error-border': errors[0]}" name="amount" placeholder="Ex: 200000" autocomplete="off">
                        <span class="error-message"> {{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>
                </div>
              </div>
              <div class="modal-footer">
                <submit-form :name="buttonText"/>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </form>
          </ValidationObserver>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import {bus} from "../../app";
import {Common} from "../../mixins/common";
import {mapGetters} from "vuex";

export default {
  mixins: [Common],
  // components: {Multiselect},
  data() {
    return {
      title: '',
      type: 'add',
      actionType: '',
      buttonShow: false,
      buttonText: '',

      sessions: [],
      heads: [],

      session_head_id: '',
      session_id: '',
      head_id: '',
      amount: '',
    }
  },
  computed: {},
  created() {
    this.getData();
  },
  mounted() {
    $('#add-edit-session-head').on('hidden.bs.modal', () => {
      this.$emit('changeStatus')
    });
    bus.$on('add-edit-session-head', (row) => {
      if (row) {
        let instance = this;
        this.axiosGet('session-head/by-id/'+row.session_head_id,function(response) {
          var data = response.data;
          instance.title = 'Update Session';
          instance.buttonText = "Update";
          instance.session_head_id = data.session_head_id;
          instance.session_id = data.session_id;
          instance.head_id = data.head_id;
          instance.amount = data.amount;
          instance.buttonShow = true;
          instance.actionType = 'edit';
        },function(error){

        });
      } else {
        this.title = 'Add Session Head';
        this.buttonText = "Create";
        this.session_id = '';
        this.head_id = '';
        this.amount = '';
        this.actionType = 'add'
      }
      $("#add-edit-session-head").modal("toggle");
      // $(".error-message").html("");
    })
  },
  destroyed() {
    bus.$off('add-edit-session-head')
  },
  methods: {
    getData() {
      this.axiosGet('support/session-head-data',(response) => {
        this.sessions = response.sessions;
        this.heads = response.heads;
      },(error)=>{

      });
    },
    onSubmit() {
      this.$store.commit('submitButtonLoadingStatus', true);
      let url = '';
      if (this.actionType === 'add') url = 'session-head/create';
      else url = 'session-head/update/'+this.session_head_id
      this.axiosPost(url, {
        session_id: this.session_id,
        head_id: this.head_id,
        amount: this.amount
      }, (response) => {
        this.successNoti(response.message);
        $("#add-edit-session-head").modal("toggle");
        bus.$emit('refresh-datatable');
        this.$store.commit('submitButtonLoadingStatus', false);
      }, (error) => {
        this.errorNoti(error);
        this.$store.commit('submitButtonLoadingStatus', false);
      })
    }
  }
}
</script>

<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
