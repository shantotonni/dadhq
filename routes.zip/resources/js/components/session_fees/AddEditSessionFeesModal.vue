<template>
  <div>
    <div class="modal fade" id="add-edit-session-fees" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <div class="modal-title modal-title-font" id="exampleModalLabel">{{ title }}</div>
          </div>
          <ValidationObserver v-slot="{ handleSubmit }">
            <form class="form-horizontal" id="form" @submit.prevent="handleSubmit(onSubmit)">
              <div class="modal-body">
                <div class="row">
                  <div class="col-6 col-md-6">
                    <ValidationProvider name="session" mode="eager" rules="required" v-slot="{ errors }">
                      <div class="form-group">
                        <label>Session</label>
                        <select v-model="sessionId" name="session" id="session" class="form-control" :class="{'error-border': errors[0]}">
                          <option value="">Select Session</option>
                          <option :value="session.session_id" v-for="(session,index) in sessions" :key="index">{{session.name}}</option>
                        </select>
                        <span class="error-message"> {{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>
                  <div class="col-6 col-md-6">
                    <ValidationProvider name="year" mode="eager" rules="required" v-slot="{ errors }">
                      <div class="form-group">
                        <label>Payment Mode</label>
                        <select v-model="yearId" name="yearId" id="yearId" class="form-control" :class="{'error-border': errors[0]}">
                          <option value="">Select Payment Mode</option>
                          <option :value="year.year_id" v-for="(year,index) in years" :key="index">{{year.name}}</option>
                        </select>
                        <span class="error-message"> {{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>

                  <div class="col-4 col-md-4" v-if="actionType=='edit'">
                    <ValidationProvider name="category" mode="eager" rules="required" v-slot="{ errors }">
                      <div class="form-group">
                        <label>Category</label>
                        <select v-model="categoryId" name="categoryId" id="categoryId" class="form-control" :class="{'error-border': errors[0]}">
                          <option value="">Select Year</option>
                          <option :value="category.id" v-for="(category,index) in categories" :key="index">{{category.name}}</option>
                        </select>
                        <span class="error-message"> {{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>
                  <div class="col-4 col-md-4" v-if="actionType=='edit'">
                    <ValidationProvider name="amount" mode="eager" rules="required" v-slot="{ errors }">
                      <div class="form-group">
                        <label>Amount</label>
                        <input v-model="amount" type="text" class="form-control" id="amount" :class="{'error-border': errors[0]}" name="amount" placeholder="Ex: 200000" autocomplete="off">
                        <span class="error-message"> {{ errors[0] }}</span>
                      </div>
                    </ValidationProvider>
                  </div>

                </div>
                <div class="row" v-for="(find,index) in finds" :key="index" v-if="actionType=='add'">
                    <div class="col-4 col-md-4">
                      <ValidationProvider name="category" mode="eager" rules="required" v-slot="{ errors }">
                        <div class="form-group">
                          <label>Category</label>
                          <select v-model="find.catId" name="catId" id="categoryId" class="form-control" :class="{'error-border': errors[0]}">
                            <option value="">Select Category</option>
                            <option :value="category.id" v-for="(category,index) in categories" :key="index">{{category.name}}</option>
                          </select>
                          <span class="error-message"> {{ errors[0] }}</span>
                        </div>
                      </ValidationProvider>
                    </div>
                    <div class="col-4 col-md-4">
                      <ValidationProvider name="amount" mode="eager" rules="required" v-slot="{ errors }">
                        <div class="form-group">
                          <label>Amount</label>
                          <input v-model="find.cat_wise_amount" type="text" class="form-control" id="cat_wise_amount" :class="{'error-border': errors[0]}" name="amount" placeholder="Ex: 200000" autocomplete="off">
                          <span class="error-message"> {{ errors[0] }}</span>
                        </div>
                      </ValidationProvider>
                    </div>
                    <div class="col-2" style="padding-top: 30px">
                      <button type="button" class="btn btn-danger btn-sm" @click="deleteFind(index)">x</button>&nbsp;
                      <button type="button" class="btn btn-success btn-sm" @click="addFind">+</button>
                    </div>
                </div>
              </div>
              <div class="modal-footer">
                <submit-form :name="buttonText"/>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
              </div>
            </form>
          </ValidationObserver>
        </div>
      </div>
    </div>
  </div>
</template>
<script>
import {bus} from "../../app";
import {Common} from "../../mixins/common";

export default {
  mixins: [Common],
  data() {
    return {
      title: '',
      sessionFeeId: '',
      name: '',
      fromYear: '',
      toYear: '',
      status: '',
      type: 'add',
      actionType: '',
      buttonShow: false,
      buttonText: '',
      sessions: [],
      years: [],
      categories: [],
      sessionId: '',
      yearId: '',
      categoryId: '',
      amount: '',
      finds: [{ catId: '',cat_wise_amount:'' }]
    }
  },
  computed: {},
  created() {
    this.getData();
  },
  mounted() {
    $('#add-edit-session-fees').on('hidden.bs.modal', () => {
      this.$emit('changeStatus')
    });
    bus.$on('add-edit-session-fees', (row) => {
      if (row) {
        let instance = this;
        this.axiosGet('session-fees/by-id/'+row.session_fee_id,function(response) {
          var data = response.data;
          instance.title = 'Update Session';
          instance.buttonText = "Update";
          instance.sessionFeeId = data.session_fee_id;
          instance.sessionId = data.session_id;
          instance.yearId = data.year_id;
          instance.categoryId = data.category_id;
          instance.amount = data.amount;
          instance.buttonShow = true;
          instance.actionType = 'edit';
        },function(error){

        });
      } else {
        this.title = 'Add Session Fees';
        this.buttonText = "Create";
        this.sessionId = '';
        this.yearId = '';
        this.categoryId = '';
        this.amount = '';
        this.actionType = 'add'
      }
      $("#add-edit-session-fees").modal("toggle");
      // $(".error-message").html("");
    })
  },
  destroyed() {
    bus.$off('add-edit-session-fees')
  },
  methods: {
    getData() {
      this.axiosGet('support/session-years-data',(response) => {
        this.sessions = response.sessions;
        this.years = response.years
        this.categories = response.categories
      },(error)=>{

      });
    },
    addFind: function () {
      this.finds.push({ catId: '' , cat_wise_amount: ''});
    },
    deleteFind: function (index) {
      this.finds.splice(index, 1);
    },
    onSubmit() {
      this.$store.commit('submitButtonLoadingStatus', true);
      let url = '';
      if (this.actionType === 'add') url = 'session-fees/create';
      else url = 'session-fees/update/'+this.sessionFeeId
      this.axiosPost(url, {
        sessionId: this.sessionId,
        categoryId: this.categoryId,
        amount: this.amount,
        yearId: this.yearId,
        finds: this.finds,
      }, (response) => {
        console.log(response)
        this.successNoti(response.message);
        $("#add-edit-session-fees").modal("toggle");
        bus.$emit('refresh-datatable');
        this.$store.commit('submitButtonLoadingStatus', false);
      }, (error) => {
        this.errorNoti(error);
        this.$store.commit('submitButtonLoadingStatus', false);
      })
    }
  }
}
</script>

<style src="vue-multiselect/dist/vue-multiselect.min.css"></style>
