<template>
    <footer class="footer">
        <strong>Copyright &copy; {{ new Date().getFullYear() }}
            <a href="javascript:" title="Advance Management System" target="_blank">MEDICAL BILLING</a></strong>
        Developed by MIS
    </footer>
</template>
