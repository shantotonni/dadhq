<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Student Hostel Bill Print']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <router-link :to="{name: 'HostelFeeList'}" class="btn btn-primary btn-sm">
                <i class="fas fa-sync"></i>
                Back
              </router-link>
            </div>
          </div>
        </div>
      </breadcrumb>
      <div class="row">
        <div class="col-xl-12">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="datatable" v-if="!isLoading">
                  <div class="card-body hostel">
                    <div class="student">
                      <h2 style="text-align: center;font-weight: bold;margin: 0;color:#6a6ad1">Medical College for Women & Hospital</h2>
                      <p style="text-align: center;color: green;font-weight: 600;margin: 0;font-size: 15px">(A project of the medical & Health Welfare Trust)</p>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175);font-size: 15px">Plot-4,Road-9,Sector-1,Uttara Model Town,Dhaka-1230,Bangladesh</p>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175);font-size: 15px">Phone:88-02-8913939,88-02,8916005,Fax:88-02-7912428</p>
                      <!--                    <p style="text-align: center;font-weight: 400;margin: 0;color:rgb(107 107 175)">Email:medicalcollegeforwomen@yahoo.com;Web:www.medicalcollegeforwomen.edu.bd</p>-->
                      <p style="text-align: right;font-weight: 400;margin: 0;color:rgb(107 107 175);font-size: 15px">No: {{ student_hostel_bill.mro_no }}</p>
                      <h3 style="text-align: center;font-weight: bold;color: rgb(106, 106, 209);border:1px solid">Money Receipt (Hostel Charges-Office Copy)</h3>

                      <div class="row">
                        <div class="col-md-8">
                          <p style="font-size: 20px">
                            Session<span style="display: inline-block;border-bottom: 1px solid;width: 250px;text-align: center">{{ student_hostel_bill.session }}</span>
                          </p>
                        </div>
                        <div class="col-md-4">
                          <p style="font-size: 20px">
                            Month<span style="display: inline-block;border-bottom: 1px solid;width: 220px;text-align: center">{{ student_hostel_bill.total_months }}</span>
                          </p>
                          <p style="font-size: 20px">
                            Year<span style="display: inline-block;border-bottom: 1px solid;width: 240px;text-align: center;font-size: 20px">{{ student_hostel_bill.from_month }} to {{ student_hostel_bill.to_month }}</span>
                          </p>
                        </div>
                      </div>
                      <div class="first_part">
                        <p style="font-size: 20px">
                          Received from Mrs/Miss <span style="display: inline-block;border-bottom: 1px solid;width: 380px;text-align: center">{{ student_hostel_bill.received_from }}</span>
                          Date <span style="display: inline-block;border-bottom: 1px solid;width: 280px;text-align: center">{{ student_hostel_bill.year }}</span>
                        </p>
                        <p style="font-size: 20px">
                          Class Roll No <span style="display: inline-block;border-bottom: 1px solid;width: 100px;text-align: center">{{ student_hostel_bill.roll_no }}</span>
                          ID Card No <span style="display: inline-block;border-bottom: 1px solid;width: 100px;text-align: center">{{ student_hostel_bill.id_card }}</span>
                          Room No <span style="display: inline-block;border-bottom: 1px solid;width: 225px;text-align: center">{{ student_hostel_bill.room_no }}</span>
                          Seat No <span style="display: inline-block;border-bottom: 1px solid;width: 100px;text-align: center">{{ student_hostel_bill.seat_no }}</span>
                        </p>
                        <p style="font-size: 20px">
                          A sum of Taka <span style="display: inline-block;border-bottom: 1px solid;width: 140px;text-align: center">{{ student_hostel_bill.currency }} {{ student_hostel_bill.total_amount }}</span>
                          Taka in word <span style="display: inline-block;border-bottom: 1px solid;width: 536px;text-align: center">{{ student_hostel_bill.amount_in_word }}</span>
                        </p>
                        <p style="font-size: 20px">
                          Name of Bank <span style="display: inline-block;border-bottom: 1px solid;width: 330px;text-align: center">{{ student_hostel_bill.pay_from_bank_name }}</span>
<!--                          Branch <span style="display: inline-block;border-bottom: 1px solid;width: 395px;text-align: center">{{ student_hostel_bill.branch_name }}</span>-->
                        </p>
                        <p style="font-size: 20px">
                          on PO/HO/IRM No <span style="display: inline-block;border-bottom: 1px solid;width: 250px;text-align: center">{{ student_hostel_bill.po_do_no }}</span>
                          of Date <span style="display: inline-block;border-bottom: 1px solid;width: 200px;text-align: center">{{ student_hostel_bill.po_date }}</span> With thanks.
                        </p>

                        <br>
                        <br>
                        <div class="row">
                          <div class="col-md-6">

                          </div>
                          <div class="col-md-6">
                            <div style="text-align: center;width: 100%">
                              <p style="margin:0">
                                <span style="display: inline-block;border-top: 1px solid;width: 400px;text-align: center"></span>
                              </p>
                              <p style="color: rgb(106, 106, 209);font-size:20px;margin:0">Accounts Officer/Authorized Person</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>

                    <hr>

                    <div class="office">
                      <h2 style="text-align: center;font-weight: bold;margin: 0;color:#6a6ad1">Medical College for Women & Hospital</h2>
                      <p style="text-align: center;color: green;font-weight: 600;margin: 0;font-size: 15px">(A project of the medical & Health Welfare Trust)</p>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175);font-size: 15px">Plot-4,Road-9,Sector-1,Uttara Model Town,Dhaka-1230,Bangladesh</p>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175);font-size: 15px">Phone:88-02-8913939,88-02,8916005,Fax:88-02-7912428</p>
                      <!--                    <p style="text-align: center;font-weight: 400;margin: 0;color:rgb(107 107 175)">Email:medicalcollegeforwomen@yahoo.com;Web:www.medicalcollegeforwomen.edu.bd</p>-->
                      <p style="text-align: right;font-weight: 400;margin: 0;color:rgb(107 107 175);font-size: 15px">No: {{ student_hostel_bill.mro_no }}</p>
                      <h3 style="text-align: center;font-weight: bold;color: rgb(106, 106, 209);border:1px solid">Money Receipt (Hostel Charges-Student Copy)</h3>
                      <div class="row">
                        <div class="col-md-8">
                          <p style="font-size: 20px">
                            Session<span style="display: inline-block;border-bottom: 1px solid;width: 250px;text-align: center">{{ student_hostel_bill.session }}</span>
                          </p>
                        </div>
                        <div class="col-md-4">
                          <p style="font-size: 20px">
                            Month<span style="display: inline-block;border-bottom: 1px solid;width: 220px;text-align: center">{{ student_hostel_bill.total_months }}</span>
                          </p>
                          <p style="font-size: 20px">
                            Year<span style="display: inline-block;border-bottom: 1px solid;width: 240px;text-align: center;font-size: 20px">{{ student_hostel_bill.from_month }} to {{ student_hostel_bill.to_month }}</span>
                          </p>
                        </div>
                      </div>
                      <div class="first_part">
                        <p style="font-size: 20px">
                          Received from Mrs/Miss <span style="display: inline-block;border-bottom: 1px solid;width: 380px;text-align: center">{{ student_hostel_bill.received_from }}</span>
                          Date <span style="display: inline-block;border-bottom: 1px solid;width: 280px;text-align: center">{{ student_hostel_bill.year }}</span>
                        </p>
                        <p style="font-size: 20px">
                          Class Roll No <span style="display: inline-block;border-bottom: 1px solid;width: 100px;text-align: center">{{ student_hostel_bill.roll_no }}</span>
                          ID Card No <span style="display: inline-block;border-bottom: 1px solid;width: 100px;text-align: center">{{ student_hostel_bill.id_card }}</span>
                          Room No <span style="display: inline-block;border-bottom: 1px solid;width: 225px;text-align: center">{{ student_hostel_bill.room_no }}</span>
                          Seat No <span style="display: inline-block;border-bottom: 1px solid;width: 100px;text-align: center">{{ student_hostel_bill.seat_no }}</span>
                        </p>
                        <p style="font-size: 20px">
                          A sum of Taka <span style="display: inline-block;border-bottom: 1px solid;width: 140px;text-align: center">{{ student_hostel_bill.currency }} {{ student_hostel_bill.total_amount }}</span>
                          Taka in word <span style="display: inline-block;border-bottom: 1px solid;width: 536px;text-align: center">{{ student_hostel_bill.amount_in_word }}</span>
                        </p>
                        <p style="font-size: 20px">
                          Name of Bank <span style="display: inline-block;border-bottom: 1px solid;width: 330px;text-align: center">{{ student_hostel_bill.pay_from_bank_name }}</span>
<!--                          Branch <span style="display: inline-block;border-bottom: 1px solid;width: 395px;text-align: center">{{ student_hostel_bill.branch_name }}</span>-->
                        </p>
                        <p style="font-size: 20px">
                          on PO/HO/IRM No <span style="display: inline-block;border-bottom: 1px solid;width: 250px;text-align: center">{{ student_hostel_bill.po_do_no }}</span>
                          of Date <span style="display: inline-block;border-bottom: 1px solid;width: 200px;text-align: center">{{ student_hostel_bill.po_date }}</span> With thanks.
                        </p>

                        <br>
                        <br>
                        <div class="row">
                          <div class="col-md-6">

                          </div>
                          <div class="col-md-6">
                            <div style="text-align: center;width: 100%">
                              <p style="margin:0">
                                <span style="display: inline-block;border-top: 1px solid;width: 400px;text-align: center"></span>
                              </p>
                              <p style="color: rgb(106, 106, 209);font-size:20px;margin:0">Accounts Officer/Authorized Person</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div v-else>
                  <skeleton-loader :row="14"/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
import {Common} from "../../mixins/common";
export default {
  name: "List",
  mixins: [Common],
  components: {
    Datepicker
  },
  data() {
    return {
      student_hostel_bill: {},
      isLoading: false,
      isDisabled: true,
    }
  },
  created() {
    axios.get(baseurl + `api/hostel-fee-invoice/${this.$route.params.id}`).then((response)=>{
      this.student_hostel_bill = response.data.data;
      setTimeout(function(){
        window.print()
      },2000)
    });
  },

  mounted() {
    document.title = 'Student Hostel Bill Print | Bill';
  },
  methods: {
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    },
  },
}
</script>

<style scoped>
.side_note label{
  font-size: 11px!important;
  margin-bottom: 0;
}
.side_note .form-control {
  height: 25px!important;
}
.side_note .form-group {
  margin-bottom: 0;
}
.hostel p{
  font-size: 12px;
}
</style>
