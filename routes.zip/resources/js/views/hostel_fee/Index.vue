<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Hostel Bill List']"/>
      <div class="row">
        <div class="col-xl-12">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <div class="d-flex">
                  <div class="flex-grow-1">
                    <div class="row">
                      <div class="col-md-2">
                        <div class="form-group">
                          <select name="sessionId" id="sessionId" v-model="sessionId" class="form-control">
                            <option disabled value="">Select Session</option>
                            <option :value="session.name" v-for="(session , index) in sessions" :key="index">{{ session.name }}</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-group">
                          <select name="categoryId" id="categoryId" v-model="categoryId" class="form-control">
                            <option disabled value="">Select Category</option>
                            <option :value="category.name" v-for="(category , index) in categories" :key="index">{{ category.name }}</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <button type="submit" @click="getAllHostelFee" class="btn btn-success"><i class="mdi mdi-filter"></i>Filter</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="datatable" v-if="!isLoading">
              <div class="card-body">
                <div class="d-flex">
                  <div class="flex-grow-1">
                    <div class="row">
                      <div class="col-md-2">
                        <input v-model="query" type="text" class="form-control" placeholder="Search">
                      </div>
                    </div>
                  </div>
                  <div class="card-tools">
                    <button type="button" class="btn btn-success btn-sm" @click="createHostelFeeModel">
                      <i class="fas fa-plus"></i>
                      Add Hostel Bill
                    </button>
                    <button type="button" class="btn btn-primary btn-sm" @click="reload">
                      <i class="fas fa-sync"></i>
                      Reload
                    </button>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                    <thead>
                      <tr>
                        <th>SN</th>
                        <th>Received From</th>
                        <th>Category</th>
                        <th>Session</th>
                        <th>Roll</th>
                        <th>Batch Number</th>
                        <th>From Month</th>
                        <th>ID Card</th>
                        <th>Room No</th>
                        <th>Seat No</th>
                        <th>Bank Name</th>
                        <th>Branch Name</th>
                        <th>PO/HO/IRM No</th>
                        <th>Total Amount</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(fee, i) in hostel_fee" :key="fee.id" v-if="hostel_fee.length">
                        <th scope="row">{{ ++i }}</th>
                        <td>{{ fee.received_from }}</td>
                        <td>{{ fee.category }}</td>
                        <td>{{ fee.session }}</td>
                        <td>{{ fee.roll_no }}</td>
                        <td>{{ fee.batch_number }}</td>
                        <td>{{ fee.from_month }}</td>
                        <td>{{ fee.id_card }}</td>
                        <td>{{ fee.room_no }}</td>
                        <td>{{ fee.seat_no }}</td>
                        <td>{{ fee.bank_name }}</td>
                        <td>{{ fee.branch_name }}</td>
                        <td>{{ fee.po_do_no }}</td>
                        <td>{{ fee.total_amount }}</td>
                        <td>
                          <button @click="edit(fee)" class="btn btn-success btn-sm"><i class="far fa-edit"></i></button>
                          <router-link :to="`hostel-fee-invoice/${fee.id}`" class="btn btn-info btn-sm"><i class="mdi mdi-printer"></i> Invoice</router-link>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="row">
                  <div class="col-4">
                    <div class="data-count">
                      Show {{ pagination.from }} to {{ pagination.to }} of {{ pagination.total }} rows
                    </div>
                  </div>
                  <div class="col-8">
                    <pagination
                        v-if="pagination.last_page > 1"
                        :pagination="pagination"
                        :offset="5"
                        @paginate="query === '' ? getAllHostelFee() : searchData()"
                    ></pagination>
                  </div>
                </div>
              </div>
            </div>
            <div v-else>
              <skeleton-loader :row="14"/>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--  Modal content for the above example -->
    <div class="modal fade" id="StudentModelModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true" data-keyboard="false" data-backdrop="static">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title mt-0" id="myLargeModalLabel">{{ editMode ? "Edit" : "Add" }} Hostel Bill</h5>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true" @click="closeModal">×</button>
          </div>
          <form @submit.prevent="editMode ? update() : store()" @keydown="form.onKeydown($event)">
            <div class="modal-body">
              <div class="col-md-12">
                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>MR No</label>
                      <input type="text" name="mro_no" v-model="form.mro_no" class="form-control" :class="{ 'is-invalid': form.errors.has('mro_no') }">
                      <div class="error" v-if="form.errors.has('mro_no')" v-html="form.errors.get('mro_no')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Payment Head</label>
                      <input type="text" name="title" v-model="form.title" class="form-control" :class="{ 'is-invalid': form.errors.has('title') }">
                      <div class="error" v-if="form.errors.has('title')" v-html="form.errors.get('title')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Select Session</label>
                      <select name="session_id" id="session_id" v-model="form.session_id" class="form-control" @change="studentInfo()">
                        <option disabled value="">Select Session</option>
                        <option :value="session.session_id" v-for="(session , index) in sessions" :key="index">{{ session.name }}</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Roll No</label>
                      <input type="text" name="roll_no" v-model="form.roll_no" class="form-control" :class="{ 'is-invalid': form.errors.has('roll_no') }" @keyup="studentInfo()">
                      <div class="error" v-if="form.errors.has('roll_no')" v-html="form.errors.get('roll_no')" />
                    </div>
                  </div>

                  <input type="hidden" name="student_id" v-model="form.student_id" class="form-control" >
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Category</label>
                      <input type="text" name="category" v-model="form.category" class="form-control" readonly :class="{ 'is-invalid': form.errors.has('category') }">
                      <div class="error" v-if="form.errors.has('category')" v-html="form.errors.get('category')" />
                    </div>
                  </div>

                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Received From</label>
                      <input type="text" name="received_from" v-model="form.received_from" class="form-control" readonly :class="{ 'is-invalid': form.errors.has('received_from') }">
                      <div class="error" v-if="form.errors.has('received_from')" v-html="form.errors.get('received_from')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Batch Number</label>
                      <input type="text" name="batch_number" v-model="form.batch_number" class="form-control" readonly :class="{ 'is-invalid': form.errors.has('batch_number') }">
                      <div class="error" v-if="form.errors.has('batch_number')" v-html="form.errors.get('batch_number')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Id Card</label>
                      <input type="text" name="id_card" v-model="form.id_card" class="form-control" :class="{ 'is-invalid': form.errors.has('id_card') }">
                      <div class="error" v-if="form.errors.has('id_card')" v-html="form.errors.get('id_card')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Room Number</label>
                      <input type="text" name="room_no" v-model="form.room_no" class="form-control" :class="{ 'is-invalid': form.errors.has('room_no') }">
                      <div class="error" v-if="form.errors.has('room_no')" v-html="form.errors.get('room_no')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Seat No</label>
                      <input type="text" name="seat_no" v-model="form.seat_no" class="form-control" :class="{ 'is-invalid': form.errors.has('seat_no') }">
                      <div class="error" v-if="form.errors.has('seat_no')" v-html="form.errors.get('seat_no')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>From Month</label>
                      <datepicker v-model="form.from_month" :format="customFormatter" placeholder="Enter Month" input-class="form-control"></datepicker>
                      <div class="error" v-if="form.errors.has('from_month')" v-html="form.errors.get('from_month')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>To Month</label>
                      <datepicker v-model="form.to_month" :format="customFormatter" placeholder="Enter Month" input-class="form-control" @input="getTotalMonthFormTwoDate"></datepicker>
                      <div class="error" v-if="form.errors.has('to_month')" v-html="form.errors.get('to_month')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Total Months</label>
                      <input type="text" name="total_months" readonly v-model="form.total_months" class="form-control" :class="{ 'is-invalid': form.errors.has('total_months') }">
                      <div class="error" v-if="form.errors.has('total_months')" v-html="form.errors.get('total_months')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Pay From(Bank Name)</label>
                      <input type="text" name="pay_from_bank_name" v-model="form.pay_from_bank_name" class="form-control" :class="{ 'is-invalid': form.errors.has('pay_from_bank_name') }">
                      <div class="error" v-if="form.errors.has('pay_from_bank_name')" v-html="form.errors.get('pay_from_bank_name')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Pay From(Account Number)</label>
                      <input type="text" name="pay_from_account_no" v-model="form.pay_from_account_no" class="form-control" :class="{ 'is-invalid': form.errors.has('pay_from_account_no') }">
                      <div class="error" v-if="form.errors.has('pay_from_account_no')" v-html="form.errors.get('pay_from_account_no')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Pay To (Bank Name)</label>
                      <select name="bank_id" id="bank_id" class="form-control" v-model="form.bank_id" :class="{ 'is-invalid': form.errors.has('bank_id') }" @change="getAllBankWiseBranch()">
                        <option disabled value="">Select Bank</option>
                        <option :value="bank.id" v-for="(bank , index) in banks" :key="index">{{ bank.name }}</option>
                      </select>
                      <div class="error" v-if="form.errors.has('bank_id')" v-html="form.errors.get('bank_id')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Pay To(Branch)</label>
                      <select name="branch_id" id="branch_id" class="form-control" v-model="form.branch_id" :class="{ 'is-invalid': form.errors.has('branch_id') }" @change="branchWiseAccount()">
                        <option disabled value="">Select Branch</option>
                        <option :value="branche.id" v-for="(branche , index) in branches" :key="index">{{ branche.name }}</option>
                      </select>
                      <div class="error" v-if="form.errors.has('branch_id')" v-html="form.errors.get('branch_id')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Pay To (Account No)</label>
                      <input type="text" name="account_no" v-model="form.account_no" readonly class="form-control" :class="{ 'is-invalid': form.errors.has('account_no') }">
                      <div class="error" v-if="form.errors.has('account_no')" v-html="form.errors.get('account_no')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Currency</label>
                      <input type="currency" name="currency" v-model="form.currency" readonly class="form-control" :class="{ 'is-invalid': form.errors.has('currency') }">
                      <div class="error" v-if="form.errors.has('currency')" v-html="form.errors.get('currency')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Total Amount</label>
                      <input type="number" name="total_amount" v-model="form.total_amount" class="form-control" :class="{ 'is-invalid': form.errors.has('total_amount') }">
                      <div class="error" v-if="form.errors.has('total_amount')" v-html="form.errors.get('total_amount')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Remarks(Optional)</label>
                      <input type="text" name="remarks" v-model="form.remarks" class="form-control" :class="{ 'is-invalid': form.errors.has('remarks') }">
                      <div class="error" v-if="form.errors.has('remarks')" v-html="form.errors.get('remarks')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>PO/HO/IRM No</label>
                      <input type="text" name="po_do_no" v-model="form.po_do_no" class="form-control" :class="{ 'is-invalid': form.errors.has('po_do_no') }">
                      <div class="error" v-if="form.errors.has('po_do_no')" v-html="form.errors.get('po_do_no')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>PO/HO/IRM Date</label>
                      <datepicker v-model="form.po_date" :format="customFormatter" placeholder="Enter Year" input-class="form-control"></datepicker>
                      <div class="error" v-if="form.errors.has('po_date')" v-html="form.errors.get('po_date')" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal" @click="closeModal">Close</button>
              <button :disabled="form.busy" type="submit" class="btn btn-primary">{{ editMode ? "Update" : "Create" }} Hostel Bill</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
import {baseurl} from '../../base_url'
export default {
  name: "List",
  components: {
    Datepicker
  },
  data() {
    return {
      hostel_fee: [],
      sessions: [],
      categories: [],
      banks: [],
      students: [],
      branches: [],
      pagination: {
        current_page: 1,
        from: 1,
        to: 1,
        total: 1,
      },
      query: "",
      editMode: false,
      isLoading: false,
      form: new Form({
        id :'',
        mro_no :'',
        title :'',
        from_month:'',
        to_month:'',
        //year:'',
        pay_from_bank_name:'',
        pay_from_account_no:'',
        received_from:'',
        total_months:'',
        roll_no:'',
        id_card:'',
        room_no:'',
        seat_no:'',
        total_amount:'',
        remarks:'',
        currency:'',
        bank_id:'',
        branch_id:'',
        account_no:'',
        po_do_no:'',
        po_date:'',
        batch_number:'',
        category: '',
        student_id: '',
        session_id: '',
      }),
      sessionId: '',
      categoryId: '',
    }
  },
  watch: {
    query: function(newQ, old) {
      if (newQ === "") {
        this.getAllHostelFee();
      } else {
        this.searchData();
      }
    }
  },
  mounted() {
    document.title = 'Student Hostel Bill | Bill';
    this.getAllHostelFee();
    this.getAllSession();
    this.getAllCategory();
  },
  methods: {
    getAllHostelFee(){
      this.isLoading = true;
      axios.get(baseurl+ 'api/hostel-fee?page='+ this.pagination.current_page
          + "&sessionId=" + this.sessionId
          + "&categoryId=" + this.categoryId
      ).then((response)=>{
        this.hostel_fee = response.data.data;
        this.pagination = response.data.meta;
        this.isLoading = false;
      }).catch((error)=>{

      })
    },
    searchData(){
      axios.get(baseurl+"api/search/hostel-fee/" + this.query + "?page=" + this.pagination.current_page).then(response => {
        this.students = response.data.data;
        this.pagination = response.data.meta;
      }).catch(e => {
        this.isLoading = false;
      });
    },
    reload(){
      this.getAllHostelFee();
      this.query = "";
      this.$toaster.success('Data Successfully Refresh');
    },
    closeModal(){
      $("#StudentModelModal").modal("hide");
    },
    createHostelFeeModel(){
      this.getAllSession();
      this.getAllBank();
      this.getAllStudent();
      this.editMode = false;
      this.form.reset();
      this.form.clear();
      $("#StudentModelModal").modal("show");
    },
    store(){
      this.form.busy = true;
      this.form.post(baseurl + "api/hostel-fee").then(response => {
        $("#StudentModelModal").modal("hide");
        this.getAllHostelFee();
      }).catch(e => {
        this.isLoading = false;
      });
    },
    edit(role) {
      this.editMode = true;
      this.form.reset();
      this.form.clear();
      this.form.fill(role);
      this.form.studentId = role.student
      this.getAllSession();
      this.getAllCategory();
      this.getAllBank();
      this.getAllStudent();
      this.getAllBankWiseBranch();
      $("#StudentModelModal").modal("show");
    },
    update(){
      this.form.busy = true;
      this.form.put(baseurl+"api/hostel-fee/" + this.form.id).then(response => {
        $("#StudentModelModal").modal("hide");
        this.getAllHostelFee();
      }).catch(e => {
        this.isLoading = false;
      });
    },
    destroy(id){
      Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then((result) => {
        if (result.isConfirmed) {
          axios.delete(baseurl+'api/hostel-fee/'+ id).then((response)=>{
            this.getAllHostelFee();
            Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
            )
          })
        }
      })
    },
    studentInfo(){
      axios.post(baseurl + "api/student-details/",{ session_id: this.form.session_id, roll_no: this.form.roll_no}).then(response => {
        console.log(response)
        this.form.received_from = response.data.data.full_name;
        this.form.batch_number = response.data.data.batch_number;
        this.form.category = response.data.data.category_name;
        this.form.currency = response.data.data.currency;
        this.form.student_id = response.data.data.student_id;
      }).catch(e => {
        this.isLoading = false;
      });
    },
    getAllSession(){
      axios.get(baseurl+'api/get-all-session').then((response)=>{
        this.sessions = response.data.sessions;
      }).catch((error)=>{

      })
    },
    getAllCategory(){
      axios.get(baseurl+'api/get-all-category').then((response)=>{
        this.categories = response.data.categories;
      }).catch((error)=>{

      })
    },
    getAllBank(){
      axios.get(baseurl+'api/get-all-bank').then((response)=>{
        this.banks = response.data.banks;
      }).catch((error)=>{

      })
    },
    getAllBankWiseBranch(){
      axios.get(baseurl + 'api/get-all-bank-wise-branch/' + this.form.bank_id).then((response)=>{
        console.log(response)
        this.branches = response.data.branches;
      }).catch((error)=>{

      })
    },
    branchWiseAccount(){
      axios.post(baseurl+'api/get-account-by-branch/', {
        bank_id: this.form.bank_id,
        branch_id: this.form.branch_id,
      }).then((response)=>{
        this.form.account_no = response.data.account_no;
      }).catch((error)=>{

      })
    },
    getAllStudent(){
      axios.get(baseurl+'api/get-all-student').then((response)=>{
        console.log(response.data.students)
        this.students = response.data.students.data;
      }).catch((error)=>{

      })
    },
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    },
    customYearFormatter(date) {
      return moment(date).format('YYYY');
    },
    getTotalMonthFormTwoDate(){
      let fromdate =  this.form.from_month ? moment(this.form.from_month) : '';
      let todate =  this.form.to_month ? moment(this.form.to_month) : '';

      let dayDiff = todate.diff(fromdate, 'months');
      this.form.total_months = dayDiff + 1;
    },
  },
}
</script>

<style scoped>

</style>
