<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Sessions Fees']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <button class="btn btn-primary" @click="addSessionFees()">Add Session Fees</button>
            </div>
          </div>
        </div>
      </breadcrumb>
      <advanced-datatable :options="tableOptions">
        <template slot="action" slot-scope="row">
          <a href="javascript:" @click="addSessionFees(row.item)"> <i class="ti-pencil-alt"></i></a>
        </template>
      </advanced-datatable>
      <add-edit-session-fees @changeStatus="changeStatus" v-if="loading"/>
      <reset-password @changeStatus="changeStatus" v-if="loading"/>
    </div>
  </div>
</template>
<script>
import {bus} from "../../app";
import {Common} from "../../mixins/common";

export default {
  mixins: [Common],
  data() {
    return {
      tableOptions: {
        source: 'session-fees/list',
        search: true,
        slots: [4],
        hideColumn: ['session_fee_id'],
        slotsName: ['action'],
        sortable: [],
        pages: [20, 50, 100],
        addHeader: ['Action'],
        textRight: [3],
      },
      loading: false,
      cpLoading: false
    }
  },
  mounted() {
    bus.$off('changeStatus',function () {
      this.changeStatus()
    })
  },
  methods: {
    changeStatus() {
      this.loading = false
    },
    addSessionFees(row = '') {
      this.loading = true;
      setTimeout(() => {
        bus.$emit('add-edit-session-fees', row);
      })
    }
  }
}
</script>
