<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Miscellaneous Print']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <router-link :to="{name: 'MiscellaniousList'}" class="btn btn-primary btn-sm">
                <i class="fas fa-sync"></i>
                Back
              </router-link>
            </div>
          </div>
        </div>
      </breadcrumb>
      <div class="row">
        <div class="col-xl-12">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="datatable" v-if="!isLoading">
                  <div class="card-body hostel">
                    <br>
                    <br>
                    <br>
                    <div class="student">
                      <h2 style="text-align: center;font-weight: bold;margin: 0;color:#6a6ad1">The Medical & Health Walfare Trust</h2>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175);font-size: 15px">Plot-4,Road-9,Sector-1,Uttara Model Town,Dhaka-1230,Bangladesh</p>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175);font-size: 18px">Money Receipt(Office Copy)</p>
                      <p style="text-align: right;font-weight: 400;margin: 0;color:rgb(107 107 175);font-size: 15px">No: {{ miscellaneous.id }}</p>

                      <div class="row">
                        <div class="col-md-8">
                          <p style="font-size: 20px">
                          </p>
                        </div>
                        <div class="col-md-4">
                          <p style="font-size: 20px">
                            Date<span style="display: inline-block;border-bottom: 1px solid;width: 200px;text-align: center">{{ miscellaneous.current_date }}</span>
                          </p>
                        </div>
                      </div>
                      <div class="first_part">
                        <p style="font-size: 20px">
                          Received from Mrs/Miss <span style="display: inline-block;border-bottom: 1px solid;width: 400px;text-align: center">{{ miscellaneous.received_from }}</span>
                          Session <span style="display: inline-block;border-bottom: 1px solid;width: 190px;text-align: center">{{ miscellaneous.session }}</span>
                        </p>
                        <p style="font-size: 20px">
                          a sum of tk <span style="display: inline-block;border-bottom: 1px solid;width: 150px;text-align: center">{{ miscellaneous.amount }}</span>
                          Taka <span style="display: inline-block;border-bottom: 1px solid;width: 590px;text-align: center">{{ miscellaneous.amount_in_word }}</span>
                        </p>
                        <p style="font-size: 20px">

                        </p>
                        <p style="font-size: 20px">
                          in cash by check No <span style="display: inline-block;border-bottom: 1px solid;width: 280px;text-align: center">{{ miscellaneous.check_no }}</span>
                          Dated <span style="display: inline-block;border-bottom: 1px solid;width: 380px;text-align: center">{{ miscellaneous.payment_date }}</span>
                        </p>
                        <p style="font-size: 20px">
                          of <span style="display: inline-block;border-bottom: 1px solid;width: 250px;text-align: center"></span>
                          on account of <span style="display: inline-block;border-bottom: 1px solid;width: 480px;text-align: center">{{ miscellaneous.purpose_name }}</span>
                        </p>

                        <br>
                        <br>
                        <br>
                        <div class="row">
                          <div class="col-md-6">

                          </div>
                          <div class="col-md-6">
                            <div style="text-align: center;width: 100%">
                              <p style="margin:0">
                                <span style="display: inline-block;border-top: 1px solid;width: 400px;text-align: center"></span>
                              </p>
                              <p style="color: rgb(106, 106, 209);font-size:20px;margin:0">Cashier/Accounts Officer</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <br>
                    <hr>
                    <br>
                    <br>
                    <br>
                    <div class="office">
                      <h2 style="text-align: center;font-weight: bold;margin: 0;color:#6a6ad1">The Medical & Health Walfare Trust</h2>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175);font-size: 15px">Plot-4,Road-9,Sector-1,Uttara Model Town,Dhaka-1230,Bangladesh</p>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175);font-size: 18px">Money Receipt(Student Copy)</p>
                      <p style="text-align: right;font-weight: 400;margin: 0;color:rgb(107 107 175);font-size: 15px">No: {{ miscellaneous.id }}</p>

                      <div class="row">
                        <div class="col-md-8">
                          <p style="font-size: 20px">
                          </p>
                        </div>
                        <div class="col-md-4">
                          <p style="font-size: 20px">
                            Date<span style="display: inline-block;border-bottom: 1px solid;width: 220px;text-align: center">{{ miscellaneous.current_date }}</span>
                          </p>
                        </div>
                      </div>
                      <div class="first_part">
                        <p style="font-size: 20px">
                          Received from Mrs/Miss <span style="display: inline-block;border-bottom: 1px solid;width: 400px;text-align: center">{{ miscellaneous.received_from }}</span>
                          Session <span style="display: inline-block;border-bottom: 1px solid;width: 190px;text-align: center">{{ miscellaneous.session }}</span>
                        </p>
                        <p style="font-size: 20px">
                          a sum of tk <span style="display: inline-block;border-bottom: 1px solid;width: 150px;text-align: center">{{ miscellaneous.amount }}</span>
                          Taka <span style="display: inline-block;border-bottom: 1px solid;width: 590px;text-align: center">{{ miscellaneous.amount_in_word }}</span>
                        </p>
                        <p style="font-size: 20px">

                        </p>
                        <p style="font-size: 20px">
                          in cash by check No <span style="display: inline-block;border-bottom: 1px solid;width: 280px;text-align: center">{{ miscellaneous.check_no }}</span>
                          Dated <span style="display: inline-block;border-bottom: 1px solid;width: 380px;text-align: center">{{ miscellaneous.payment_date }}</span>
                        </p>
                        <p style="font-size: 20px">
                          of <span style="display: inline-block;border-bottom: 1px solid;width: 250px;text-align: center"></span>
                          on account of <span style="display: inline-block;border-bottom: 1px solid;width: 480px;text-align: center">{{ miscellaneous.purpose_name }}</span>
                        </p>

                        <br>
                        <br>
                        <br>
                        <div class="row">
                          <div class="col-md-6">

                          </div>
                          <div class="col-md-6">
                            <div style="text-align: center;width: 100%">
                              <p style="margin:0">
                                <span style="display: inline-block;border-top: 1px solid;width: 400px;text-align: center"></span>
                              </p>
                              <p style="color: rgb(106, 106, 209);font-size:20px;margin:0">Cashier/Accounts Officer</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div v-else>
                  <skeleton-loader :row="14"/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
import {Common} from "../../mixins/common";
export default {
  name: "List",
  mixins: [Common],
  components: {
    Datepicker
  },
  data() {
    return {
      miscellaneous: {},
      isLoading: false,
      isDisabled: true,
    }
  },
  created() {
    axios.get(baseurl + `api/miscellaneous-invoice/${this.$route.params.id}`).then((response)=>{
      this.miscellaneous = response.data.data;
      setTimeout(function(){
        window.print()
      },2000)
    });
  },

  mounted() {
    document.title = 'Student Hostel Bill Print | Bill';
  },
  methods: {
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    },
  },
}
</script>

<style scoped>
.side_note label{
  font-size: 11px!important;
  margin-bottom: 0;
}
.side_note .form-control {
  height: 25px!important;
}
.side_note .form-group {
  margin-bottom: 0;
}
.hostel p{
  font-size: 12px;
}
</style>
