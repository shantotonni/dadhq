<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Miscellaneous List']"/>
      <div class="row">
        <div class="col-xl-12">
          <div class="col-md-12">
            <div class="card">
              <div class="card-body">
                <div class="d-flex">
                  <div class="flex-grow-1">
                    <div class="row">
                      <div class="col-md-2">
                        <div class="form-group">
                          <select name="sessionId" id="sessionId" v-model="sessionId" class="form-control">
                            <option disabled value="">Select Session</option>
                            <option :value="session.name" v-for="(session , index) in sessions" :key="index">{{ session.name }}</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-group">
                          <select name="categoryId" id="categoryId" v-model="categoryId" class="form-control">
                            <option disabled value="">Select Category</option>
                            <option :value="category.name" v-for="(category , index) in categories" :key="index">{{ category.name }}</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <button type="submit" @click="getAllMiscellaneous" class="btn btn-success"><i class="mdi mdi-filter"></i>Filter</button>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div class="card">
            <div class="datatable" v-if="!isLoading">
              <div class="card-body">
                <div class="d-flex">
                  <div class="flex-grow-1">
                    <div class="row">
                      <div class="col-md-2">
                        <input v-model="query" type="text" class="form-control" placeholder="Search">
                      </div>
                    </div>
                  </div>
                  <div class="card-tools">
                    <button type="button" class="btn btn-success btn-sm" @click="createMiscellaneous">
                      <i class="fas fa-plus"></i>
                      Add Miscellaneous
                    </button>
                    <button type="button" class="btn btn-primary btn-sm" @click="reload">
                      <i class="fas fa-sync"></i>
                      Reload
                    </button>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                    <thead>
                      <tr>
                        <th>SN</th>
                        <th>Title</th>
                        <th>Received from</th>
                        <th>Roll No</th>
                        <th>Session</th>
                        <th>Category</th>
                        <th>Batch Number</th>
                        <th>Check No</th>
                        <th>Amount</th>
                        <th>Payment date</th>
                        <th>Purpose name</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(misce, i) in miscellaneous" :key="misce.id" v-if="miscellaneous.length">
                        <th scope="row">{{ ++i }}</th>
                        <td>{{ misce.title }}</td>
                        <td>{{ misce.received_from }}</td>
                        <td>{{ misce.roll_no }}</td>
                        <td>{{ misce.session }}</td>
                        <td>{{ misce.category }}</td>
                        <td>{{ misce.batch_number }}</td>
                        <td>{{ misce.check_no }}</td>
                        <td>{{ misce.amount }}</td>
                        <td>{{ misce.payment_date }}</td>
                        <td>{{ misce.purpose_name }}</td>
                        <td class="text-center">
                          <button @click="edit(misce)" class="btn btn-success btn-sm"><i class="far fa-edit"></i></button>
                          <button @click="destroy(misce.id)" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                          <router-link :to="`miscellaneous-invoice/${misce.id}`" class="btn btn-info btn-sm"><i class="mdi mdi-printer"></i> Invoice</router-link>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <br>
                  <pagination
                      v-if="pagination.last_page > 1"
                      :pagination="pagination"
                      :offset="5"
                      @paginate="query === '' ? getAllMiscellaneous() : searchData()"
                  ></pagination>
                </div>
              </div>
            </div>
            <div v-else>
              <skeleton-loader :row="14"/>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--  Modal content for the above example -->
    <div class="modal fade" id="CategoryModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title mt-0" id="myLargeModalLabel">{{ editMode ? "Edit" : "Add" }} Miscellaneous</h5>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true" @click="closeModal">×</button>
          </div>
          <form @submit.prevent="editMode ? update() : store()" @keydown="form.onKeydown($event)">
            <div class="modal-body">
              <div class="col-md-12">
                <div class="row">
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Payment Head</label>
                      <input type="text" name="title" v-model="form.title" class="form-control" :class="{ 'is-invalid': form.errors.has('title') }">
                      <div class="error" v-if="form.errors.has('title')" v-html="form.errors.get('title')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Select Session</label>
                      <select name="session_id" id="session_id" v-model="form.session_id" class="form-control">
                        <option disabled value="">Select Session</option>
                        <option :value="session.session_id" v-for="(session , index) in sessions" :key="index">{{ session.name }}</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Roll No</label>
                      <input type="text" name="roll_no" v-model="form.roll_no" class="form-control" :class="{ 'is-invalid': form.errors.has('roll_no') }" @keyup="studentInfo()">
                      <div class="error" v-if="form.errors.has('roll_no')" v-html="form.errors.get('roll_no')" />
                    </div>
                  </div>

                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Category</label>
                      <input type="text" name="category" v-model="form.category" class="form-control" readonly :class="{ 'is-invalid': form.errors.has('category') }">
                      <div class="error" v-if="form.errors.has('category')" v-html="form.errors.get('category')" />
                    </div>
                  </div>

                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Received From</label>
                      <input type="text" name="received_from" v-model="form.received_from" class="form-control" readonly :class="{ 'is-invalid': form.errors.has('received_from') }">
                      <div class="error" v-if="form.errors.has('received_from')" v-html="form.errors.get('received_from')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Batch Number</label>
                      <input type="text" name="batch_number" v-model="form.batch_number" class="form-control" readonly :class="{ 'is-invalid': form.errors.has('batch_number') }">
                      <div class="error" v-if="form.errors.has('batch_number')" v-html="form.errors.get('batch_number')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Amount</label>
                      <input type="text" name="amount" v-model="form.amount" class="form-control" :class="{ 'is-invalid': form.errors.has('amount') }">
                      <div class="error" v-if="form.errors.has('amount')" v-html="form.errors.get('amount')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Payment Date</label>
                      <datepicker v-model="form.payment_date" :format="customFormatter" placeholder="Enter Date" input-class="form-control"></datepicker>
                      <div class="error" v-if="form.errors.has('payment_date')" v-html="form.errors.get('payment_date')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Check No</label>
                      <input type="text" name="check_no" v-model="form.check_no" class="form-control" :class="{ 'is-invalid': form.errors.has('check_no') }">
                      <div class="error" v-if="form.errors.has('check_no')" v-html="form.errors.get('check_no')" />
                    </div>
                  </div>
                  <div class="col-md-4">
                    <div class="form-group">
                      <label>Select Purpose</label>
                      <select name="purpose_id" id="purpose_id" class="form-control" v-model="form.purpose_id" :class="{ 'is-invalid': form.errors.has('purpose_id') }">
                        <option disabled value="">Select Purpose</option>
                        <option :value="purpose.id" v-for="(purpose , index) in purposes" :key="index">{{ purpose.name }}</option>
                      </select>
                      <div class="error" v-if="form.errors.has('purpose_id')" v-html="form.errors.get('purpose_id')" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal" @click="closeModal">Close</button>
              <button :disabled="form.busy" type="submit" class="btn btn-primary">{{ editMode ? "Update" : "Create" }} Miscellaneous</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
export default {
  name: "List",
  components: {
    Datepicker
  },
  data() {
    return {
      miscellaneous: [],
      purposes: [],
      sessions: [],
      categories: [],
      pagination: {
        current_page: 1
      },
      query: "",
      editMode: false,
      isLoading: false,
      form: new Form({
        id :'',
        title :'',
        amount :'',
        check_no :'',
        payment_date :'',
        purpose_id :'',
        type :'',
        received_from:'',
        roll_no:'',
        batch_number:'',
        category: '',
        student_id: '',
        session_id: '',
      }),
      sessionId: '',
      categoryId: '',
    }
  },
  watch: {
    query: function(newQ, old) {
      if (newQ === "") {
        this.getAllMiscellaneous();
      } else {
        this.searchData();
      }
    }
  },
  mounted() {
    document.title = 'Miscellaneous List | Bill';
    this.getAllMiscellaneous();
    this.getAllSession();
    this.getAllCategory();
  },
  methods: {
    getAllMiscellaneous(){
      axios.get(baseurl + 'api/miscellanious?page='+ this.pagination.current_page
          + "&sessionId=" + this.sessionId
          + "&categoryId=" + this.categoryId
      ).then((response)=>{
        this.miscellaneous = response.data.data;
        this.pagination = response.data.meta;
      }).catch((error)=>{

      })
    },
    searchData(){
      axios.get(baseurl + "api/search/miscellanious/" + this.query + "?page=" + this.pagination.current_page).then(response => {
        this.miscellaneous = response.data.data;
        this.pagination = response.data.meta;
      }).catch(e => {
        this.isLoading = false;
      });
    },
    reload(){
      this.getAllMiscellaneous();
      this.query = "";
      this.$toaster.success('Data Successfully Refresh');
    },
    closeModal(){
      $("#CategoryModal").modal("hide");
    },
    createMiscellaneous(){
      this.editMode = false;
      this.form.reset();
      this.form.clear();
      $("#CategoryModal").modal("show");
      this.getAllPurpose();
    },
    store(){
      this.form.busy = true;
      this.form.post(baseurl + "api/miscellanious").then(response => {
        $("#CategoryModal").modal("hide");
        this.getAllMiscellaneous();
      }).catch(e => {
        this.isLoading = false;
      });
    },
    edit(misce) {
      this.editMode = true;
      this.form.reset();
      this.form.clear();
      this.form.fill(misce);
      $("#CategoryModal").modal("show");
      this.getAllPurpose();
      this.getAllSession();
    },
    update(){
      this.form.busy = true;
      this.form.put(baseurl + "api/miscellanious/" + this.form.id).then(response => {
        $("#CategoryModal").modal("hide");
        this.getAllMiscellaneous();
      }).catch(e => {
        this.isLoading = false;
      });
    },
    destroy(id){
      Swal.fire({
        title: 'Are You Delete?',
        // text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        // confirmButtonText: 'Yes, delete it!'
      }).then((result) => {
        if (result.isConfirmed) {
          axios.delete(baseurl + 'api/miscellanious/'+ id).then((response)=>{
            this.getAllMiscellaneous();
            Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
            )
          })
        }
      })
    },
    getAllPurpose(){
      axios.get(baseurl + 'api/get-all-purpose').then((response)=>{
        this.purposes = response.data.purpose;
      }).catch((error)=>{

      })
    },
    getAllSession(){
      axios.get(baseurl+'api/get-all-session').then((response)=>{
        this.sessions = response.data.sessions;
      }).catch((error)=>{

      })
    },
    getAllCategory(){
      axios.get(baseurl+'api/get-all-category').then((response)=>{
        this.categories = response.data.categories;
      }).catch((error)=>{

      })
    },
    studentInfo(){
      axios.post(baseurl + "api/student-details/",{ session_id: this.form.session_id, roll_no: this.form.roll_no}).then(response => {
        this.form.received_from = response.data.data.full_name;
        this.form.batch_number = response.data.data.batch_number;
        this.form.category = response.data.data.category_name;
        this.form.currency = response.data.data.currency;
        this.form.student_id = response.data.data.student_id;
      }).catch(e => {
        this.isLoading = false;
      });
    },
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    },
    customYearFormatter(date) {
      return moment(date).format('YYYY');
    },
  },
}
</script>

<style scoped>

</style>
