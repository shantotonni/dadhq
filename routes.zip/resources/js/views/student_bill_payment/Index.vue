<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Student Bill Payment List']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <router-link :to="{name: 'StudentBillPaymentCreate'}" class="btn btn-success btn-sm" style="color: white">
                <i class="fas fa-plus"></i>
                Add Student Bill Payment
              </router-link>
              <button type="button" class="btn btn-primary btn-sm" @click="exportStudentPaymentBil">
                <i class="fas fa-sync"></i>
                Export
              </button>
            </div>
          </div>
        </div>
      </breadcrumb>

      <div class="row">
        <div class="col-xl-12">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex">
                    <div class="flex-grow-1">
                      <div class="row">
                        <div class="col-md-2">
                          <div class="form-group">
                            <select name="sessionId" id="sessionId" v-model="sessionId" class="form-control">
                              <option disabled value="">Select Session</option>
                              <option :value="session.session_id" v-for="(session , index) in sessions" :key="index">{{ session.name }}</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="form-group">
                            <input v-model="roll_number" type="text" class="form-control" placeholder="Roll Number">
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="form-group">
                            <select name="bank_id" id="bank_id" class="form-control" v-model="bank_id" >
                              <option disabled value="">Select Bank</option>
                              <option :value="bank.id" v-for="(bank , index) in banks" :key="index">{{ bank.name }}</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <button type="submit" @click="getAllStudentBillPaymentList" class="btn btn-success"><i class="mdi mdi-filter"></i>Filter</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                      <thead>
                      <tr>
                        <th class="text-center">SN</th>
                        <th class="text-center">Student Name</th>
                        <th class="text-center">Student Category</th>
                        <th class="text-center">Roll</th>
                        <th class="text-center">Session</th>
                        <th class="text-center">Payment Date</th>
                        <th class="text-center">PO/HO/IRM No</th>
                        <th class="text-center">PO/HO/IRM Date</th>
                        <th class="text-center">Bank</th>
                        <th class="text-center">Branch</th>
                        <th class="text-center">Account No</th>
<!--                        <th class="text-center">Amount</th>-->
                        <th class="text-center">Status</th>
                        <th class="text-center">Action</th>
                      </tr>
                      </thead>
                      <tbody>
                      <tr v-for="(bill, i) in student_bill_payment" :key="bill.id" v-if="student_bill_payment.length">
                        <th scope="row">{{ ++i }}</th>
                        <td>{{ bill.name }}</td>
                        <td>{{ bill.student_category }}</td>
                        <td>{{ bill.roll_no }}</td>
                        <td>{{ bill.session }}</td>
                        <td>{{ bill.payment_date }}</td>
                        <td>{{ bill.po_do_no }}</td>
                        <td>{{ bill.po_date }}</td>
                        <td>{{ bill.bank }}</td>
                        <td>{{ bill.branch }}</td>
                        <td>{{ bill.account_no }}</td>
<!--                        <td class="text-right">{{ bill.symbol }}{{ bill.amount }}</td>-->
                        <td>{{ bill.status }}</td>
                        <td class="text-center">
                          <router-link :to="`student-bill-payment-view/${bill.id}`" class="btn btn-info btn-sm"><i class="mdi mdi-eye"></i></router-link>
                          <router-link :to="`student-bill-payment-edit/${bill.id}`" class="btn btn-warning btn-sm"><i class="mdi mdi-square-edit-outline"></i></router-link>
                          <router-link :to="`student-bill-payment-invoice/${bill.id}`" class="btn btn-info btn-sm"><i class="mdi mdi-printer"></i> Invoice</router-link>
                          <button @click="destroy(bill.id)" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                        </td>
                      </tr>
                      </tbody>
                    </table>
                  </div>
                  <div class="row">
                    <div class="col-4">
                      <div class="data-count">
                        Show {{ pagination.from }} to {{ pagination.to }} of {{ pagination.total }} rows
                      </div>
                    </div>
                    <div class="col-8">
                      <pagination
                          v-if="pagination.last_page > 1"
                          :pagination="pagination"
                          :offset="5"
                          @paginate="query === '' ? getAllStudentBillPaymentList() : searchData()"
                      ></pagination>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <data-export/>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
import {bus} from "../../app";
export default {
  name: "List",
  components: {
    Datepicker
  },
  data() {
    return {
      student_bill_payment: [],
      sessions: [],
      banks: [],
      pagination: {
        current_page: 1,
        from: 1,
        to: 1,
        total: 1,
      },
      query: "",
      editMode: false,
      isLoading: false,
      sessionId: '',
      roll_number: '',
      bank_id: '',
    }
  },
  watch: {
    query: function(newQ, old) {
      if (newQ === "") {
        this.getAllStudentBillPaymentList();
      } else {
        this.searchData();
      }
    }
  },
  mounted() {
    document.title = 'Student Bill Payment List | Bill';
    this.getAllStudentBillPaymentList();
    this.getAllSession();
    this.getAllBank();
  },
  methods: {
    getAllStudentBillPaymentList(){
      axios.get(baseurl + 'api/student-payment-bill?page='+ this.pagination.current_page
          + "&sessionId=" + this.sessionId
          + "&roll_number=" + this.roll_number
          + "&bank_id=" + this.bank_id
      ).then((response)=>{
        console.log(response)
        this.student_bill_payment = response.data.data;
        this.pagination = response.data.meta;
      }).catch((error)=>{

      })
    },
    searchData(){
      axios.get(baseurl+"api/search/student-payment-bill/" + this.query + "?page=" + this.pagination.current_page).then(response => {
        this.student_bill_payment = response.data.data;
        this.pagination = response.data.meta;
      }).catch(e => {
        this.isLoading = false;
      });
    },
    exportStudentPaymentBil(){
      axios.get(baseurl + 'api/export-student-payment-bill?sessionId='+ this.sessionId + "&roll_number=" + this.roll_number)
          .then((response)=>{
            console.log(response)
            let dataSets = response.data.data;
            if (dataSets.length > 0) {
              let columns = Object.keys(dataSets[0]);
              columns = columns.filter((item) => item !== 'row_num');
              let rex = /([A-Z])([A-Z])([a-z])|([a-z])([A-Z])/g;
              columns = columns.map((item) => {
                let title = item.replace(rex, '$1$4 $2$3$5')
                return {title, key: item}
              });
              bus.$emit('data-table-import', dataSets, columns, 'Student Payment Bill List')
            }
          }).catch((error)=>{
      })
    },
    destroy(id){
      Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then((result) => {
        if (result.isConfirmed) {
          axios.delete(baseurl+'api/student-payment-bill/'+ id).then((response)=>{
            this.getAllStudentBillPaymentList();
            Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
            )
          })
        }
      })
    },
    getAllSession(){
      axios.get(baseurl+'api/get-all-session').then((response)=>{
        this.sessions = response.data.sessions;
      }).catch((error)=>{

      })
    },
    getAllBank(){
      axios.get(baseurl+'api/get-all-bank').then((response)=>{
        this.banks = response.data.banks;
      }).catch((error)=>{

      })
    },
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    }
  },
}
</script>

<style scoped>

</style>
