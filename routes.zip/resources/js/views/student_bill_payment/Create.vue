<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Student Payment Bill Create']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <router-link :to="{name: 'StudentBillPaymentList'}" class="btn btn-primary btn-sm">
                <i class="fas fa-sync"></i>
                Back
              </router-link>
            </div>
          </div>
        </div>
      </breadcrumb>
      <div class="row">
        <div class="col-xl-12">
          <form @submit.prevent="store()" @keydown="form.onKeydown($event)">
            <div class="row">
              <div class="col-md-7">
                <div class="card">
                  <div class="datatable" v-if="!isLoading">
                    <div class="card-body">
                      <div class="col-md-12">
                         <div class="row">
                           <div class="col-md-4">
                             <div class="form-group">
                               <div class="form-group">
                                 <label>MR. NO</label>
                                 <input type="text" name="mro_no" readonly v-model="form.mro_no" class="form-control" :class="{ 'is-invalid': form.errors.has('mro_no') }">
                               </div>
                             </div>
                           </div>
                           <div class="col-md-4">
                             <div class="form-group">
                               <label>Payment date</label>
                               <datepicker v-model="form.payment_date" :format="customFormatter" placeholder="Enter Payment Date" input-class="form-control"></datepicker>
                               <div class="error" v-if="form.errors.has('payment_date')" v-html="form.errors.get('payment_date')" />
                             </div>
                           </div>
<!--                           <div class="col-md-4">-->
<!--                             <div class="form-group">-->
<!--                               <label>Pay For</label>-->
<!--                               <select name="head_id" id="head_id" class="form-control" v-model="form.head_id" :class="{ 'is-invalid': form.errors.has('head_id') }">-->
<!--                                 <option disabled value="">Select Pay For</option>-->
<!--                                 <option :value="pay.year_id" v-for="(pay , index) in pay_for" :key="index">{{ pay.name }}</option>-->
<!--                               </select>-->
<!--                               <div class="error" v-if="form.errors.has('year_id')" v-html="form.errors.get('year_id')" />-->
<!--                             </div>-->
<!--                           </div>-->
                         </div>
                        <hr>
                      </div>
                      <div class="col-md-12">
                        <div class="row">
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>Session</label>
                              <select v-model="form.session_id" name="session_id" id="session_id" class="form-control" :class="{ 'is-invalid': form.errors.has('session_id') }" @change="SessionWiseBatch">
                                <option value="">Select Session</option>
                                <option :value="session.session_id" v-for="(session,index) in sessions" :key="index">{{session.name}}</option>
                              </select>
                              <div class="error" v-if="form.errors.has('session_id')" v-html="form.errors.get('session_id')" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>Batch</label>
                              <input type="text" name="batch_number" v-model="form.batch_number" readonly class="form-control" :class="{ 'is-invalid': form.errors.has('batch_number') }">
                              <div class="error" v-if="form.errors.has('batch_number')" v-html="form.errors.get('batch_number')" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>Roll No</label>
                              <input type="text" name="roll_no" v-model="form.roll_no" class="form-control" :class="{ 'is-invalid': form.errors.has('roll_no') }" @keyup="rollSessionBatchWiseStudent">
                              <div class="error" v-if="form.errors.has('roll_no')" v-html="form.errors.get('roll_no')" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>Student Name</label>
                              <input type="text" name="name" readonly v-model="form.name" class="form-control" :class="{ 'is-invalid': form.errors.has('name') }">
                              <div class="error" v-if="form.errors.has('name')" v-html="form.errors.get('name')" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>Pay From(Bank Name)</label>
                              <input type="text" name="pay_from_bank_name" v-model="form.pay_from_bank_name" class="form-control" :class="{ 'is-invalid': form.errors.has('pay_from_bank_name') }">
                              <div class="error" v-if="form.errors.has('pay_from_bank_name')" v-html="form.errors.get('pay_from_bank_name')" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>Pay From(Account Number)</label>
                              <input type="text" name="pay_from_account_no" v-model="form.pay_from_account_no" class="form-control" :class="{ 'is-invalid': form.errors.has('pay_from_account_no') }">
                              <div class="error" v-if="form.errors.has('pay_from_account_no')" v-html="form.errors.get('pay_from_account_no')" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>PO/HO/IRM NO</label>
                              <input type="text" name="po_do_no" v-model="form.po_do_no" class="form-control" :class="{ 'is-invalid': form.errors.has('po_do_no') }">
                              <div class="error" v-if="form.errors.has('po_do_no')" v-html="form.errors.get('po_do_no')" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>PO/HO/IRM Date</label>
                              <datepicker v-model="form.po_date" :format="customFormatter" placeholder="Enter Date" input-class="form-control"></datepicker>
                              <div class="error" v-if="form.errors.has('po_date')" v-html="form.errors.get('po_date')" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>Pay To (Bank Name)</label>
                              <select name="bank_id" id="bank_id" class="form-control" v-model="form.bank_id" :class="{ 'is-invalid': form.errors.has('bank_id') }" @change="getAllBankWiseBranch()">
                                <option disabled value="">Select Bank</option>
                                <option :value="bank.id" v-for="(bank , index) in banks" :key="index">{{ bank.name }}</option>
                              </select>
                              <div class="error" v-if="form.errors.has('bank_id')" v-html="form.errors.get('bank_id')" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>Pay To(Branch)</label>
                              <select name="branch_id" id="branch_id" class="form-control" v-model="form.branch_id" :class="{ 'is-invalid': form.errors.has('branch_id') }" @change="branchWiseAccount()">
                                <option disabled value="">Select Branch</option>
                                <option :value="branche.id" v-for="(branche , index) in branches" :key="index">{{ branche.name }}</option>
                              </select>
                              <div class="error" v-if="form.errors.has('branch_id')" v-html="form.errors.get('branch_id')" />
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>Pay To (Account No)</label>
                              <input type="text" name="account_no" v-model="form.account_no" readonly class="form-control" :class="{ 'is-invalid': form.errors.has('account_no') }">
                              <div class="error" v-if="form.errors.has('account_no')" v-html="form.errors.get('account_no')" />
                            </div>
                          </div>
<!--                          <div class="col-md-4">-->
<!--                            <div class="form-group">-->
<!--                              <label>Amount</label>-->
<!--                              <input type="text" name="amount" v-model="form.amount" class="form-control" :class="{ 'is-invalid': form.errors.has('amount') }" @change="checkAmount()">-->
<!--                              <div class="error" v-if="form.errors.has('amount')" v-html="form.errors.get('amount')" />-->
<!--                            </div>-->
<!--                          </div>-->
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>Currency</label>
                              <input type="text" name="currency" readonly v-model="form.currency" class="form-control" :class="{ 'is-invalid': form.errors.has('currency') }">
                            </div>
                          </div>
                          <div class="col-md-4">
                            <div class="form-group">
                              <label>Remarks</label>
                              <input type="text" name="remarks" v-model="form.remarks" class="form-control" :class="{ 'is-invalid': form.errors.has('remarks') }">
                            </div>
                          </div>
                        </div>
                        <hr>
                       </div>
                      <div class="row" v-for="(find,index) in form.finds" :key="index">
                        <div class="col-4 col-md-4">
                          <div class="form-group">
                            <label>Pay For</label>
                            <select name="head_id" id="head_id" class="form-control" v-model="find.head_id" :class="{ 'is-invalid': form.errors.has('head_id') }">
                              <option disabled value="">Select Pay For</option>
                              <option :value="pay.year_id" v-for="(pay , index) in pay_for" :key="index">{{ pay.name }}</option>
                            </select>
                            <div class="error" v-if="form.errors.has('year_id')" v-html="form.errors.get('year_id')" />
                          </div>
                        </div>
                        <div class="col-3 col-md-3">
                          <div class="form-group">
                            <label>Amount BDT</label>
                            <input type="text" name="amount_bdt" v-model="find.amount_bdt" class="form-control" :class="{ 'is-invalid': form.errors.has('amount_bdt') }">
                            <div class="error" v-if="form.errors.has('amount_bdt')" v-html="form.errors.get('amount_bdt')" />
                          </div>
                        </div>
                        <div class="col-3 col-md-3">
                          <div class="form-group">
                            <label>Amount USD (Optional)</label>
                            <input type="text" name="amount_usd" v-model="find.amount_usd" class="form-control" :class="{ 'is-invalid': form.errors.has('amount_usd') }">
                            <div class="error" v-if="form.errors.has('amount_usd')" v-html="form.errors.get('amount_usd')" />
                          </div>
                        </div>
                        <div class="col-2" style="padding-top: 30px">
                          <button type="button" class="btn btn-danger btn-sm" @click="deleteFind(index)">x</button>&nbsp;
                          <button type="button" class="btn btn-success btn-sm" @click="addFind">+</button>
                        </div>
                      </div>

                      <div class="col-md-12">
<!--                        <div class="row">-->
<!--                          <div class="col-md-4">-->
<!--                            <div class="form-group">-->
<!--                              <label>Late Fee</label>-->
<!--                              <select name="late_fee" id="late_fee" class="form-control" v-model="form.late_fee" :class="{ 'is-invalid': form.errors.has('late_fee') }" @change="lateFeeStatus">-->
<!--                                <option disabled value="">Select Late Fee</option>-->
<!--                                <option value="Y">Yes</option>-->
<!--                                <option value="N">No</option>-->
<!--                              </select>-->
<!--                              <div class="error" v-if="form.errors.has('late_fee')" v-html="form.errors.get('late_fee')" />-->
<!--                            </div>-->
<!--                          </div>-->
<!--                          <div class="col-md-4" v-if="late_fee_status">-->
<!--                            <div class="form-group">-->
<!--                              <label>Late Fee Percentage(%)</label>-->
<!--                              <input type="text" name="late_fee_percentage" v-model="form.late_fee_percentage" class="form-control" :class="{ 'is-invalid': form.errors.has('late_fee_percentage') }" @keyup="lateFeePercentage()">-->
<!--                              <div class="error" v-if="form.errors.has('late_fee_percentage')" v-html="form.errors.get('late_fee_percentage')" />-->
<!--                            </div>-->
<!--                          </div>-->
<!--                          <div class="col-md-4" v-if="late_fee_status">-->
<!--                            <div class="form-group">-->
<!--                              <label>Late Fee Amount</label>-->
<!--                              <input type="text" name="late_fee_amount" readonly v-model="form.late_fee_amount" class="form-control" :class="{ 'is-invalid': form.errors.has('late_fee_amount') }">-->
<!--                              <div class="error" v-if="form.errors.has('late_fee_amount')" v-html="form.errors.get('late_fee_amount')" />-->
<!--                            </div>-->
<!--                          </div>-->
<!--                        </div>-->
                          <div class="modal-footer">
                            <button v-if="isDisabled" type="submit" class="btn btn-primary">Add</button>
                          </div>
                        </div>
                      </div>
                  </div>
                  <div v-else>
                    <skeleton-loader :row="14"/>
                  </div>
                </div>
              </div>
              <div class="col-md-5">
                <div class="card">
                  <div class="datatable" v-if="!isLoading">
                    <div class="card-body">
                      <div class="col-md-12">
                        <div class="row side_note">
                          <div class="col-md-12" v-for="(schedule, i) in bill_schedule" :key="schedule.student_bill_id" v-if="bill_schedule.length">
                            <div class="row">
                                <div class="col-md-4">
                                  <div class="form-group">
                                    <label>{{ schedule.payment_head }}</label>
                                    <input type="text" name="name" readonly class="form-control" :value="schedule.amount">
                                  </div>
                                </div>
                                <div class="col-md-4">
                                  <div class="form-group">
                                    <label>Paid Amount</label>
                                    <input type="text" name="name" readonly class="form-control" :value="schedule.paid_amount">
                                  </div>
                                </div>
                              <div class="col-md-4">
                                <div class="form-group">
                                  <label>Due Amount</label>
                                  <input type="text" name="name" readonly class="form-control" :value="schedule.due_amount">
                                </div>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                  <div v-else>
                    <skeleton-loader :row="14"/>
                  </div>
                </div>
              </div>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
import {Common} from "../../mixins/common";
export default {
  name: "List",
  mixins: [Common],
  components: {
    Datepicker
  },
  data() {
    return {
      student: [],
      pay_for: [],
      sessions: [],
      banks: [],
      branches: [],
      bill_schedule: [],
      currencies: [],
      form: new Form({
        id :'',
        student_id :'',
        session_id :'',
        payment_date: new Date(),
        roll_no:'',
        batch_number:'',
        categoryId:'',
        name:'',
        pay_from_bank_name:'',
        pay_from_account_no:'',
        bank_id:'',
        branch_id:'',
        po_do_no:'',
        po_date:'',
        account_no:'',
        remarks:'',
        currency:'',
        mro_no:'',
        //late_fee:'',
        //late_fee_percentage:'',
        //late_fee_amount:'',
        finds: [{ head_id: '',amount_bdt:'', amount_usd: '' }],
      }),
      isLoading: false,
      isDisabled: true,
      //late_fee_status: false,
    }
  },

  mounted() {
    document.title = 'Student Payment Bill Create | Bill';
    this.getAllPaymentMethod();
    this.getAllSession();
    this.getAllBank();
    this.getAllCurrency();
    this.mroNo();
  },
  methods: {
    store(){
      this.form.busy = true;
      this.form.post(baseurl + "api/student-payment-bill").then(response => {
        if (response.data.status === 'error'){
          this.errorNoti(response.data.message);
        }else {
          this.redirect(this.mainOrigin + 'student-bill-payment-list')
        }
      }).catch(e => {
        this.isLoading = false;
      });
    },
    getAllPaymentMethod(){
      axios.get(baseurl+'api/get-all-payment-method').then((response)=>{
        this.pay_for = response.data.payment_method;
      }).catch((error)=>{

      })
    },
    getAllSession(){
      axios.get(baseurl+'api/get-all-session').then((response)=>{
        this.sessions = response.data.sessions;
      }).catch((error)=>{

      })
    },
    getAllBank(){
      axios.get(baseurl+'api/get-all-bank').then((response)=>{
        this.banks = response.data.banks;
      }).catch((error)=>{

      })
    },
    getAllCurrency(){
      axios.get(baseurl+'api/get-all-currency').then((response)=>{
        this.currencies = response.data.currencies;
      }).catch((error)=>{

      })
    },
    getAllBankWiseBranch(){
      axios.get(baseurl + 'api/get-all-bank-wise-branch/' + this.form.bank_id).then((response)=>{
        console.log(response)
        this.branches = response.data.branches;
      }).catch((error)=>{

      })
    },
    SessionWiseBatch(){
      axios.get(baseurl + 'api/session-wise-batch/' + this.form.session_id).then((response)=>{
        console.log(response)
        this.form.batch_number = response.data.batch;
      }).catch((error)=>{

      })
    },
    rollSessionBatchWiseStudent(){
      axios.post(baseurl+'api/get-roll-wise-student/', {
        session_id: this.form.session_id,
        batch_number: this.form.batch_number,
        roll_no: this.form.roll_no,
      }).then((response)=>{
        console.log(response)
        this.student = response.data.student;
        this.form.student_id = response.data.student.student_id;
        this.form.categoryId = response.data.student.category_id;
        this.bill_schedule = response.data.bill_schedule;
        this.form.name = response.data.student.first_name+ ' ' + response.data.student.last_name
        this.form.session = response.data.student.session.name;
        this.form.session_id = response.data.student.session.session_id;
        this.form.currency = response.data.student.category.currency.name;
      }).catch((error)=>{

      })
    },
    branchWiseAccount(){
      axios.post(baseurl+'api/get-account-by-branch/', {
        bank_id: this.form.bank_id,
        branch_id: this.form.branch_id,
      }).then((response)=>{
        this.form.account_no = response.data.account_no;
      }).catch((error)=>{

      })
    },
    // lateFeeStatus(){
    //   if (this.form.late_fee === 'Y'){
    //     this.late_fee_status = true;
    //   }else {
    //     this.late_fee_status = false;
    //   }
    // },
    // lateFeePercentage(){
    //   this.form.late_fee_amount = (this.form.amount * this.form.late_fee_percentage)/ 100;
    // },
    mroNo(){
      axios.get(baseurl + 'api/get-mro-no/').then((response)=>{
        this.form.mro_no = response.data.mro_no;
      }).catch((error)=>{

      })
    },
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    },
    checkAmount(){
      this.form.busy = true;
      this.form.post(baseurl + "api/student-payment-bill/check-amount").then(response => {
        if (response.data.status === 'error'){
          this.errorNoti(response.data.message);
        }else {
          this.successNoti(response.data.message);
          this.isDisabled = true;
        }
      }).catch(e => {
        this.isLoading = false;
      });
    },
    addFind: function () {
      this.form.finds.push({ head_id: '' , amount_bdt: '', amount_usd : ''});
    },
    deleteFind: function (index) {
      this.form.finds.splice(index, 1);
    },
  },
}
</script>

<style scoped>
.side_note label{
  font-size: 11px!important;
  margin-bottom: 0;
}
.side_note .form-control {
  height: 25px!important;
}
.side_note .form-group {
  margin-bottom: 0;
}
</style>
