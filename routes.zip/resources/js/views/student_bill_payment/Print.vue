<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Student Payment Bill Create']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <router-link :to="{name: 'StudentBillPaymentList'}" class="btn btn-primary btn-sm">
                <i class="fas fa-sync"></i>
                Back
              </router-link>
            </div>
          </div>
        </div>
      </breadcrumb>
      <div class="row">
        <div class="col-xl-12">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="datatable" v-if="!isLoading">
                  <div class="card-body">
                    <div class="student">
                      <h2 style="text-align: center;font-weight: bold;margin: 0;color:#6a6ad1">Medical College for Women & Hospital</h2>
                      <p style="text-align: center;color: green;font-weight: 600;margin: 0;">(A project of the medical & Health Welfare Trust)</p>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175)">Plot-4,Road-9,Sector-1,Uttara Model Town,Dhaka-1230,Bangladesh</p>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175)">Phone:88-02-8913939,88-02,8916005,Fax:88-02-7912428</p>
                      <p style="text-align: center;font-weight: 400;margin: 0;color:rgb(107 107 175)">Email:medicalcollegeforwomen@yahoo.com;Web:www.medicalcollegeforwomen.edu.bd</p>
                      <h3 style="text-align: center;font-weight: bold;color: rgb(106, 106, 209);border:1px solid">Student Money Receipt (Student Copy)</h3>
                      <div class="col-md-12 first_part" >
                        <div class="row">
                          <div class="col-md-8">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Money Receipt No <span style="margin-left: 70px">: {{ student_bill.mro_no }}</span></p>
                          </div>
                          <div class="col-md-4">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Date : {{ student_bill.payment_date }}</p>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-8">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Name <span style="margin-left: 174px">: {{ student_bill.name }}</span></p>
                          </div>
                          <div class="col-md-4">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Roll : {{ student_bill.roll_no }}</p>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-8">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Session <span style="margin-left: 156px">: {{ student_bill.session }}</span></p>
                          </div>
                          <div class="col-md-4">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Student Type : {{ student_bill.student_category }}</p>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-8">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">PO/HO/IRM NO <span style="margin-left: 87px">: {{ student_bill.po_do_no }}</span></p>
                          </div>
                          <div class="col-md-4">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Particular : {{ student_bill.pay_from_bank_name }}</p>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-8">
                            <div class="table-responsive">
                              <table class="table table-bordered table-striped table-hover dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                                <thead>
                                <tr style="color: black!important;background: white;font-size: 16px">
                                  <th>Payment Head</th>
                                  <th>Amount BDT</th>
                                  <th>Amount USD</th>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-for="(detail, i) in details" :key="detail.id" v-if="details.length" style="font-size: 16px">
                                  <td>{{ detail.payment_head }}</td>
                                  <td class="text-right">৳ {{ detail.amount_bdt.toLocaleString() }}</td>
                                  <td class="text-right">$ {{ detail.amount_usd }}</td>
                                </tr>
                                </tbody>
                                <tfoot>
                                  <tr style="font-size: 16px">
                                    <td>Total Amount</td>
                                    <td class="text-right">৳ {{ totalAmountBDT(details).toLocaleString() }}</td>
                                    <td class="text-right">${{ totalAmountUSD(details) }}</td>
                                  </tr>
                                </tfoot>
                              </table>
                            </div>
                          </div>
                        </div>
                        <!--<h4 style="text-align: center;font-weight: bold;color: rgb(106, 106, 209);border:1px solid;text-transform: capitalize">{{ student_bill.amount_in_word }}</h4>-->
                        <br>
                        <br>
                        <br>
                        <br>
                        <div class="row">
                          <div class="col-md-6">

                          </div>
                          <div class="col-md-6">
                            <div style="text-align: center;width: 100%">
                              <p style="margin:0">
                                <span style="display: inline-block;border-top: 1px solid;width: 400px;text-align: center"></span>
                              </p>
                              <p style="color: rgb(106, 106, 209);font-size:20px;margin:0">Accounts Officer/Authorized Person</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                    <br>
                    <br>
                    <hr>
                    <br>
                    <br>
                    <div class="office">
                      <h2 style="text-align: center;font-weight: bold;margin: 0;color:#6a6ad1">Medical College for Women & Hospital</h2>
                      <p style="text-align: center;color: green;font-weight: 600;margin: 0;">(A project of the medical & Health Welfare Trust)</p>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175)">Plot-4,Road-9,Sector-1,Uttara Model Town,Dhaka-1230,Bangladesh</p>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175)">Phone:88-02-8913939,88-02,8916005,Fax:88-02-7912428</p>
                      <p style="text-align: center;font-weight: 400;margin: 0;color:rgb(107 107 175)">Email:medicalcollegeforwomen@yahoo.com;Web:www.medicalcollegeforwomen.edu.bd</p>
                      <h3 style="text-align: center;font-weight: bold;color: rgb(106, 106, 209);border:1px solid">Student Money Receipt (Office Copy)</h3>
                      <div class="col-md-12 first_part" >
                        <div class="row">
                          <div class="col-md-8">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Money Receipt No <span style="margin-left: 70px">: {{ student_bill.mro_no }}</span></p>
                          </div>
                          <div class="col-md-4">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Date : {{ student_bill.payment_date }}</p>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-8">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Name <span style="margin-left: 174px">: {{ student_bill.name }}</span></p>
                          </div>
                          <div class="col-md-4">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Roll : {{ student_bill.roll_no }}</p>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-8">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Session <span style="margin-left: 156px">: {{ student_bill.session }}</span></p>
                          </div>
                          <div class="col-md-4">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Student Type : {{ student_bill.student_category }}</p>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-8">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">PO/HO/IRM NO <span style="margin-left: 87px">: {{ student_bill.po_do_no }}</span></p>
                          </div>
                          <div class="col-md-4">
                            <p style="font-size: 20px;color: rgb(106, 106, 209)">Particular : {{ student_bill.pay_from_bank_name }}</p>
                          </div>
                        </div>
                        <div class="row">
                          <div class="col-md-8">
                            <div class="table-responsive">
                              <table class="table table-bordered table-striped table-hover dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                                <thead>
                                  <tr style="color: black!important;background: white;font-size: 16px">
                                    <th>Payment Head</th>
                                    <th>Amount BDT</th>
                                    <th>Amount USD</th>
                                  </tr>
                                </thead>
                                <tbody>
                                  <tr v-for="(detail, i) in details" :key="detail.id" v-if="details.length" style="font-size: 16px">
                                    <td>{{ detail.payment_head }}</td>
                                    <td class="text-right">৳ {{ detail.amount_bdt.toLocaleString() }}</td>
                                    <td class="text-right">$ {{ detail.amount_usd }}</td>
                                  </tr>
                                </tbody>
                                <tfoot>
                                <tr style="font-size: 16px">
                                  <td>Total Amount</td>
                                  <td class="text-right">৳ {{ totalAmountBDT(details).toLocaleString() }}</td>
                                  <td class="text-right">$ {{ totalAmountUSD(details) }}</td>
                                </tr>
                                </tfoot>
                              </table>
                            </div>
                          </div>
                        </div>
                        <!--<h4 style="text-align: center;font-weight: bold;color: rgb(106, 106, 209);border:1px solid;text-transform: capitalize">{{ student_bill.amount_in_word }}</h4>-->
                        <br>
                        <br>
                        <br>
                        <br>
                        <div class="row">
                          <div class="col-md-6">

                          </div>
                          <div class="col-md-6">
                            <div style="text-align: center;width: 100%">
                              <p style="margin:0">
                                <span style="display: inline-block;border-top: 1px solid;width: 400px;text-align: center"></span>
                              </p>
                              <p style="color: rgb(106, 106, 209);font-size:20px;margin:0">Accounts Officer/Authorized Person</p>
                            </div>
                          </div>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div v-else>
                  <skeleton-loader :row="14"/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
import {Common} from "../../mixins/common";
export default {
  name: "List",
  mixins: [Common],
  components: {
    Datepicker
  },
  data() {
    return {
      student_bill: {},
      details: {},
      isLoading: false,
      isDisabled: true,
    }
  },
  created() {
    axios.get(baseurl + `api/student-bill-payment-invoice/${this.$route.params.id}`).then((response)=>{
      this.student_bill = response.data.data
      this.details = response.data.data.finds
      setTimeout(function(){
        window.print()
      },2000)
    });
  },

  mounted() {
    document.title = 'Student Payment Bill Print | Bill';
  },
  methods: {
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    },
    totalAmountBDT: function (values) {
      return values.reduce((acc, val) => {
        return acc + parseInt(val.amount_bdt);
      }, 0);
    },
    totalAmountUSD: function (values) {
      return values.reduce((acc, val) => {
        return acc + parseInt(val.amount_usd);
      }, 0);
    },
  },
}
</script>

<style scoped>
.side_note label{
  font-size: 11px!important;
  margin-bottom: 0;
}
.side_note .form-control {
  height: 25px!important;
}
.side_note .form-group {
  margin-bottom: 0;
}
p{
  margin: 5px;
}
.first_part p{
  margin: 0;
}
</style>
