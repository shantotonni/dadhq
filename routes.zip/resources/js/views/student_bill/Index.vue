<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Student Bill List']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <button type="button" class="btn btn-success btn-sm" @click="create">
                <i class="fas fa-plus"></i>
                Add Student Schedule
              </button>
              <button type="button" class="btn btn-primary btn-sm" @click="reload">
                <i class="fas fa-sync"></i>
                Reload
              </button>
              <button type="button" class="btn btn-primary btn-sm" @click="exportStudentScheduleData">
                <i class="fas fa-sync"></i>
                Export
              </button>
            </div>
          </div>
        </div>
      </breadcrumb>
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
            <div class="datatable" v-if="!isLoading">
              <div class="card-body">
                <div class="d-flex">
                  <div class="flex-grow-1">
                    <div class="row">
                      <div class="col-md-2">
                        <div class="form-group">
                          <select name="sessionId" id="sessionId" v-model="sessionId" class="form-control" @change="sessionWiseStudent()">
                            <option disabled value="">Select Session</option>
                            <option :value="session.session_id" v-for="(session , index) in sessions" :key="index">{{ session.name }}</option>
                          </select>
                        </div>
                      </div>

                      <div class="col-md-2">
                        <div class="form-group">
                          <input type="text" class="form-control" v-model="studentBatch" name="studentBatch" placeholder="Student Batch" readonly>
                        </div>
                      </div>
                      <div class="col-md-2">
                        <div class="form-group">
                          <input type="text" class="form-control" v-model="roll_no" name="roll_no" placeholder="Select Roll">
                        </div>
                      </div>
                      <div class="col-md-3">
                        <button type="submit" @click="getAllStudentBill" class="btn btn-success"><i class="mdi mdi-filter"></i>Filter</button>
                      </div>
                    </div>
                  </div>
                  <div class="card-tools">
                    <input v-model="query" type="text" class="form-control" placeholder="Search">
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                    <thead>
                    <tr>
                      <th class="text-center">SN</th>
                      <th class="text-center">Student Name</th>
                      <th class="text-center">Student Roll</th>
                      <th class="text-center">Student Category</th>
                      <th class="text-center">Session</th>
                      <th class="text-center">Expected Payment Date</th>
                      <th class="text-center">Payment head</th>
                      <th class="text-center">Amount</th>
                      <th class="text-center">Paid Amount</th>
                      <th class="text-center">Due amount</th>
                      <th class="text-center">Ordering</th>
                      <th class="text-center">Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr v-for="(bill, i) in student_bill" :key="bill.student_bill_id" v-if="student_bill.length">
                      <th scope="row">{{ ++i }}</th>
                      <td>{{ bill.student_name }}</td>
                      <td>{{ bill.student_roll }}</td>
                      <td>{{ bill.category }}</td>
                      <td>{{ bill.session }}</td>
                      <td>{{ bill.expected_payment_date }}</td>
                      <td>{{ bill.payment_head }}</td>
                      <td class="text-right">{{ bill.currency_symbol }} {{ bill.amount }}</td>
                      <td class="text-right">{{ bill.currency_symbol }} {{ bill.paid_amount }}</td>
                      <td class="text-right">{{ bill.currency_symbol }} {{ bill.due_amount }}</td>
                      <td class="text-right">{{ bill.ordering }}</td>
                      <td class="text-center">
                        <button @click="edit(bill)" class="btn btn-success btn-sm"><i class="far fa-edit"></i></button>
<!--                        <button v-if="bill.due_amount === 0" class="btn btn-info btn-sm"><i class="fa fa-check"></i> Completed</button>-->
                        <button @click="destroy(bill.student_bill_id)" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </div>
                <div class="row">
                  <div class="col-4">
                    <div class="data-count">
                      Show {{ pagination.from }} to {{ pagination.to }} of {{ pagination.total }} rows
                    </div>
                  </div>
                  <div class="col-8">
                    <pagination
                        v-if="pagination.last_page > 1"
                        :pagination="pagination"
                        :offset="5"
                        @paginate="query === '' ? getAllStudentBill() : searchData()"
                    ></pagination>
                  </div>
                </div>
              </div>
            </div>
            <div v-else>
              <skeleton-loader :row="14"/>
            </div>
          </div>
        </div>
      </div>
    </div>
    <data-export/>
    <!--  Modal content for the above example -->
    <div class="modal fade" id="StudentBillModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title mt-0" id="myLargeModalLabel">{{ editMode ? "Edit" : "Add" }} Student Bill</h5>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true" @click="closeModal">×</button>
          </div>
          <form @submit.prevent="editMode ? update() : store()" @keydown="form.onKeydown($event)">
            <div class="modal-body">
              <div class="col-md-12">
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Select Session</label>
                      <select name="session_id" id="session_id" v-model="form.session_id" class="form-control" @change="sessionRollWiseStudent()">
                        <option disabled value="">Select Session</option>
                        <option :value="session.session_id" v-for="(session , index) in sessions" :key="index">{{ session.name }}</option>
                      </select>
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Roll No</label>
                      <input type="text" name="roll_no" v-model="form.roll_no" class="form-control" :class="{ 'is-invalid': form.errors.has('roll_no') }" @keyup="sessionRollWiseStudent()">
                      <div class="error" v-if="form.errors.has('roll_no')" v-html="form.errors.get('roll_no')" />
                    </div>
                  </div>

                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Student Name</label>
                      <input type="text" name="student_name" v-model="form.student_name" class="form-control" :class="{ 'is-invalid': form.errors.has('student_name') }" readonly>
                      <div class="error" v-if="form.errors.has('student_name')" v-html="form.errors.get('student_name')" />
                    </div>
                  </div>
                  <input type="hidden" name="student_id" v-model="form.student_id" class="form-control" >
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Payment head</label>
                      <input type="text" name="payment_head" v-model="form.payment_head" class="form-control" :class="{ 'is-invalid': form.errors.has('payment_head') }">
                      <div class="error" v-if="form.errors.has('payment_head')" v-html="form.errors.get('payment_head')" />
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Expected Payment Date</label>
                      <datepicker v-model="form.expected_payment_date" :format="customFormatter" input-class="form-control"></datepicker>
                      <!--                      <input type="text" name="date_of_birth" v-model="form.date_of_birth" class="form-control" :class="{ 'is-invalid': form.errors.has('date_of_birth') }">-->
                      <div class="error" v-if="form.errors.has('expected_payment_date')" v-html="form.errors.get('expected_payment_date')" />
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Amount</label>
                      <input type="text" name="amount" v-model="form.amount" class="form-control" :class="{ 'is-invalid': form.errors.has('amount') }" @keyup="amount()">
                      <div class="error" v-if="form.errors.has('amount')" v-html="form.errors.get('amount')" />
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Paid amount</label>
                      <input type="number" name="paid_amount" v-model="form.paid_amount" class="form-control" :class="{ 'is-invalid': form.errors.has('paid_amount') }" @keyup="paidAmount()">
                      <div class="error" v-if="form.errors.has('paid_amount')" v-html="form.errors.get('paid_amount')" />
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Due amount</label>
                      <input type="text" name="due_amount" v-model="form.due_amount" class="form-control" :class="{ 'is-invalid': form.errors.has('due_amount') }" readonly>
                      <div class="error" v-if="form.errors.has('due_amount')" v-html="form.errors.get('due_amount')" />
                    </div>
                  </div>
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Ordering</label>
                      <input type="number" name="ordering" v-model="form.ordering" class="form-control" :class="{ 'is-invalid': form.errors.has('ordering') }">
                      <div class="error" v-if="form.errors.has('ordering')" v-html="form.errors.get('ordering')" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal" @click="closeModal">Close</button>
              <button :disabled="form.busy" type="submit" class="btn btn-primary">{{ editMode ? "Update" : "Create" }} Student Bill</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
import {bus} from "../../app";
export default {
  name: "List",
  components: {
    Datepicker
  },
  data() {
    return {
      student_bill: [],
      students: [],
      sessions: [],
      pagination: {
        current_page: 1,
        from: 1,
        to: 1,
        total: 1,
      },
      query: "",
      editMode: false,
      isLoading: false,
      form: new Form({
        student_bill_id :'',
        session_id :'',
        roll_no :'',
        student_id :'',
        student_name :'',
        expected_payment_date :'',
        payment_head:'',
        amount:'',
        paid_amount:0,
        due_amount:'',
        ordering:'',
      }),
      studentId: '',
      sessionId: '',
      roll_no: '',
      studentBatch: '',
    }
  },
  watch: {
    query: function(newQ, old) {
      if (newQ === "") {
        this.getAllStudentBill();
      } else {
        this.searchData();
      }
    }
  },
  mounted() {
    document.title = 'Student Bill List | Bill';
    this.getAllStudentBill();
   // this.getAllStudent();
    this.getAllSession();
  },
  methods: {
    getAllStudentBill(){
      axios.get(baseurl+'api/student-bill?page='+ this.pagination.current_page + "&studentBatch=" + this.studentBatch + "&roll_no=" + this.roll_no+ "&sessionId=" + this.sessionId).then((response)=>{
        this.student_bill = response.data.data;
        this.pagination = response.data.meta;
      }).catch((error)=>{

      })
    },
    searchData(){
      axios.get(baseurl+"api/search/student-bill/" + this.query + "?page=" + this.pagination.current_page).then(response => {
        this.student_bill = response.data.data;
        this.pagination = response.data.meta;
      }).catch(e => {
        this.isLoading = false;
      });
    },
    reload(){
      this.getAllStudentBill();
      this.query = "";
      this.$toaster.success('Data Successfully Refresh');
    },
    closeModal(){
      $("#StudentBillModal").modal("hide");
    },
    create(){
      this.getAllStudent();
      this.editMode = false;
      this.form.reset();
      this.form.clear();
      $("#StudentBillModal").modal("show");
    },
    store(){
      this.form.busy = true;
      this.form.post(baseurl+"api/student-bill").then(response => {
        $("#StudentBillModal").modal("hide");
        this.getAllStudentBill();
      }).catch(e => {
        this.isLoading = false;
      });
    },
    edit(role) {
      this.editMode = true;
      this.form.reset();
      this.form.clear();
      this.form.fill(role);
      this.sessionRollWiseStudent()
      $("#StudentBillModal").modal("show");
    },
    update(){
      this.form.busy = true;
      this.form.put(baseurl+"api/student-bill/" + this.form.student_bill_id).then(response => {
        $("#StudentBillModal").modal("hide");
        this.getAllStudentBill();
      }).catch(e => {
        this.isLoading = false;
      });
    },
    sessionWiseStudent(){
      axios.post(baseurl+'api/session-wise-student/', {
        sessionId: this.sessionId,
      }).then((response)=>{
        //this.students = response.data.data;
        this.studentBatch = response.data.session.batch_number;
      }).catch((error)=>{

      })
    },
    sessionRollWiseStudent(){
      axios.post(baseurl+'api/session-roll-wise-student/', {
        session_id: this.form.session_id,
        roll_no: this.form.roll_no,
      }).then((response)=>{
        console.log(response)
        this.form.student_name = response.data.student.first_name + ' ' + response.data.student.last_name;
        this.form.student_id = response.data.student.student_id;
      }).catch((error)=>{

      })
    },
    exportStudentScheduleData(){
      axios.get(baseurl + 'api/export-student-wise-schedule?studentBatch='+ "&studentBatch=" + this.studentBatch + "&roll_no=" + this.roll_no+ "&sessionId=" + this.sessionId +"&query=" + this.query)
          .then((response)=>{
            let dataSets = response.data.data;
            if (dataSets.length > 0) {
              let columns = Object.keys(dataSets[0]);
              columns = columns.filter((item) => item !== 'row_num');
              let rex = /([A-Z])([A-Z])([a-z])|([a-z])([A-Z])/g;
              columns = columns.map((item) => {
                let title = item.replace(rex, '$1$4 $2$3$5')
                return {title, key: item}
              });
              bus.$emit('data-table-import', dataSets, columns, 'Student Bill Schedule')
            }
          }).catch((error)=>{
      })
    },
    destroy(id){
      Swal.fire({
        title: 'Are you sure?',
        text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Yes, delete it!'
      }).then((result) => {
        if (result.isConfirmed) {
          axios.delete(baseurl+'api/student-bill/'+ id).then((response)=>{
            this.getAllStudentBill();
            Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
            )
          })
        }
      })
    },
    getAllSession(){
      axios.get(baseurl+'api/get-all-session').then((response)=>{
        this.sessions = response.data.sessions;
      }).catch((error)=>{

      })
    },
    getAllStudent(){
      axios.get(baseurl+'api/get-all-student').then((response)=>{
        console.log(response.data.students)
        this.students = response.data.students.data;
      }).catch((error)=>{

      })
    },
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    },
    amount(){
      this.form.due_amount = this.form.amount;
    },
    paidAmount(){
      if (this.form.paid_amount > this.form.amount){
        this.form.paid_amount = this.form.amount;
      }else {
        this.form.due_amount = this.form.amount - this.form.paid_amount
      }
    }
  },
}
</script>

<style scoped>

</style>
