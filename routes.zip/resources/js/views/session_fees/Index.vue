<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Student Bill List']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <button type="button" class="btn btn-success btn-sm" @click="create">
                <i class="fas fa-plus"></i>
                Add Session Fees
              </button>
              <button type="button" class="btn btn-primary btn-sm" @click="reload">
                <i class="fas fa-sync"></i>
                Reload
              </button>
            </div>
          </div>
        </div>
      </breadcrumb>
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
            <div class="datatable" v-if="!isLoading">
              <div class="card-body">
                <div class="d-flex">
                  <div class="flex-grow-1">
                    <div class="row">
                      <div class="col-md-2">
                        <div class="form-group">
                          <select name="sessionId" id="sessionId" v-model="sessionId" class="form-control">
                            <option disabled value="">Select Session</option>
                            <option :value="session.session_id" v-for="(session , index) in sessions" :key="index">{{ session.name }}</option>
                          </select>
                        </div>
                      </div>
                      <div class="col-2 col-md-2">
                        <div class="form-group">
                          <select v-model="categoryId" name="categoryId" id="categoryId" class="form-control" :class="{ 'is-invalid': form.errors.has('categoryId') }">
                            <option value="">Select Category</option>
                            <option :value="category.id" v-for="(category,index) in categories" :key="index">{{category.name}}</option>
                          </select>
                          <div class="error" v-if="form.errors.has('categoryId')" v-html="form.errors.get('categoryId')" />
                        </div>
                      </div>
                      <div class="col-md-3">
                        <button type="submit" @click="getAllSessionFee" class="btn btn-success"><i class="mdi mdi-filter"></i>Filter</button>
                      </div>
                    </div>
                  </div>
<!--                  <div class="card-tools">-->
<!--                    <input v-model="query" type="text" class="form-control" placeholder="Search">-->
<!--                  </div>-->
                </div>
                <div class="table-responsive">
                  <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                    <thead>
                    <tr>
                      <th>SN</th>
                      <th>Session Name</th>
                      <th>Payment Head</th>
                      <th>Category</th>
                      <th>Amount</th>
                      <th>Action</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr v-for="(fess, i) in session_fess" :key="fess.session_fee_id" v-if="session_fess.length">
                      <th scope="row">{{ ++i }}</th>
                      <td>{{ fess.session_name }}</td>
                      <td>{{ fess.year_name }}</td>
                      <td>{{ fess.category_name }}</td>
                      <td>{{ fess.amount }}</td>
                      <td>
                        <button @click="edit(fess)" class="btn btn-success btn-sm"><i class="far fa-edit"></i></button>
                       <button @click="destroy(fess.session_fee_id)" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                      </td>
                    </tr>
                    </tbody>
                  </table>
                </div>
                <div class="row">
                  <div class="col-4">
                    <div class="data-count">
                      Show {{ pagination.from }} to {{ pagination.to }} of {{ pagination.total }} rows
                    </div>
                  </div>
                  <div class="col-8">
                    <pagination
                        v-if="pagination.last_page > 1"
                        :pagination="pagination"
                        :offset="5"
                        @paginate="query === '' ? getAllSessionFee() : searchData()"
                    ></pagination>
                  </div>
                </div>
              </div>
            </div>
            <div v-else>
              <skeleton-loader :row="14"/>
            </div>
          </div>
        </div>
      </div>
    </div>
    <data-export/>
    <!--  Modal content for the above example -->
    <div class="modal fade" id="SessionFeesModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title mt-0" id="myLargeModalLabel">{{ editMode ? "Edit" : "Add" }} Session Fees</h5>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true" @click="closeModal">×</button>
          </div>
          <form @submit.prevent="editMode ? update() : store()" @keydown="form.onKeydown($event)">
            <div class="modal-body">
              <div class="col-md-12">
                <div class="row">
                  <div class="col-6 col-md-6">
                      <div class="form-group">
                        <label>Session</label>
                        <select v-model="form.session_id" name="session_id" id="session_id" class="form-control" :class="{ 'is-invalid': form.errors.has('session_id') }">
                          <option value="">Select Session</option>
                          <option :value="session.session_id" v-for="(session,index) in sessions" :key="index">{{session.name}}</option>
                        </select>
                        <div class="error" v-if="form.errors.has('session_id')" v-html="form.errors.get('session_id')" />
                      </div>
                  </div>
                  <div class="col-6 col-md-6">
                      <div class="form-group">
                        <label>Payment Mode</label>
                        <select v-model="form.year_id" name="year_id" id="year_id" class="form-control" :class="{ 'is-invalid': form.errors.has('year_id') }">
                          <option value="">Select Payment Mode</option>
                          <option :value="year.year_id" v-for="(year,index) in years" :key="index">{{year.name}}</option>
                        </select>
                        <div class="error" v-if="form.errors.has('year_id')" v-html="form.errors.get('year_id')" />
                      </div>
                  </div>
                  <div class="col-4 col-md-4" v-if="actionType=='edit'">
                      <div class="form-group">
                        <label>Category</label>
                        <select v-model="form.category_id" name="category_id" id="category_id" class="form-control" :class="{ 'is-invalid': form.errors.has('category_id') }">
                          <option value="">Select Category</option>
                          <option :value="category.id" v-for="(category,index) in categories" :key="index">{{category.name}}</option>
                        </select>
                        <div class="error" v-if="form.errors.has('category_id')" v-html="form.errors.get('category_id')" />
                      </div>
                  </div>
                  <div class="col-4 col-md-4" v-if="actionType=='edit'">
                      <div class="form-group">
                        <label>Amount</label>
                        <input v-model="form.amount" type="text" class="form-control" id="amount" :class="{ 'is-invalid': form.errors.has('amount') }" name="amount" placeholder="Ex: 200000" autocomplete="off">
                        <div class="error" v-if="form.errors.has('amount')" v-html="form.errors.get('amount')" />
                      </div>
                  </div>
                </div>
                <div class="row" v-for="(find,index) in form.finds" :key="index" v-if="actionType=='add'">
                  <div class="col-4 col-md-4">
                      <div class="form-group">
                        <label>Category</label>
                        <select v-model="find.catId" name="catId" id="catId" class="form-control" :class="{ 'is-invalid': form.errors.has('catId') }">
                          <option value="">Select Category</option>
                          <option :value="category.id" v-for="(category,index) in categories" :key="index">{{category.name}}</option>
                        </select>
                        <div class="error" v-if="form.errors.has('catId')" v-html="form.errors.get('catId')" />
                      </div>
                  </div>
                  <div class="col-4 col-md-4">
                      <div class="form-group">
                        <label>Amount</label>
                        <input v-model="find.cat_wise_amount" type="text" class="form-control" id="cat_wise_amount" :class="{ 'is-invalid': form.errors.has('cat_wise_amount') }" name="amount" placeholder="Ex: 200000">
                        <div class="error" v-if="form.errors.has('cat_wise_amount')" v-html="form.errors.get('cat_wise_amount')" />
                      </div>
                  </div>
                  <div class="col-2" style="padding-top: 30px">
                    <button type="button" class="btn btn-danger btn-sm" @click="deleteFind(index)">x</button>&nbsp;
                    <button type="button" class="btn btn-success btn-sm" @click="addFind">+</button>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal" @click="closeModal">Close</button>
              <button :disabled="form.busy" type="submit" class="btn btn-primary">{{ editMode ? "Update" : "Create" }} Session Fees</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
import {bus} from "../../app";
export default {
  name: "List",
  components: {
    Datepicker
  },
  data() {
    return {
      session_fess: [],
      sessions: [],
      categories: [],
      years: [],
      pagination: {
        current_page: 1,
        from: 1,
        to: 1,
        total: 1,
      },
      query: "",
      editMode: false,
      isLoading: false,
      form: new Form({
        session_fee_id :'',
        session_id :'',
        year_id :'',
        category_id:'',
        amount:'',
        finds: [{ catId: '',cat_wise_amount:'' }],
      }),
      sessionId: '',
      categoryId: '',
      actionType: '',
    }
  },
  watch: {
    query: function(newQ, old) {
      if (newQ === "") {
        this.getAllSessionFee();
      } else {
        this.searchData();
      }
    }
  },
  mounted() {
    document.title = 'Session Fees List | Bill';
    this.getAllSessionFee();
    this.getData();
  },
  methods: {
    getAllSessionFee(){
      axios.get(baseurl + 'api/session-fees?page='+ this.pagination.current_page + "&sessionId=" + this.sessionId + "&categoryId=" + this.categoryId).then((response)=>{
        //console.log(response)
        this.session_fess = response.data.data;
        this.pagination = response.data.meta;
      }).catch((error)=>{

      })
    },
    searchData(){
      axios.get(baseurl+"api/search/session-fees/" + this.query + "?page=" + this.pagination.current_page).then(response => {
        this.session_fess = response.data.data;
        this.pagination = response.data.meta;
      }).catch(e => {
        this.isLoading = false;
      });
    },
    reload(){
      this.getAllSessionFee();
      this.query = "";
      this.$toaster.success('Data Successfully Refresh');
    },
    closeModal(){
      $("#SessionFeesModal").modal("hide");
    },
    create(){
      this.editMode = false;
      this.actionType = 'add'
      this.form.reset();
      this.form.clear();
      $("#SessionFeesModal").modal("show");
    },
    store(){
      this.form.busy = true;
      this.form.post(baseurl + "api/session-fees").then(response => {
        $("#SessionFeesModal").modal("hide");
        this.getAllSessionFee();
      }).catch(e => {
        this.isLoading = false;
      });
    },
    edit(role) {
      this.actionType = 'edit'
      this.editMode = true;
      this.form.reset();
      this.form.clear();
      this.form.fill(role);
      $("#SessionFeesModal").modal("show");
    },
    update(){
      this.form.busy = true;
      this.form.put(baseurl+"api/session-fees/" + this.form.session_fee_id).then(response => {
        $("#SessionFeesModal").modal("hide");
        this.getAllSessionFee();
      }).catch(e => {
        this.isLoading = false;
      });
    },
    destroy(id){
      Swal.fire({
        title: 'You Can not Delete This Item',
        // text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        // confirmButtonText: 'Yes, delete it!'
      }).then((result) => {
        if (result.isConfirmed) {
          axios.delete(baseurl+'api/session-fees/'+ id).then((response)=>{
            this.getAllSessionFee();
            Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
            )
          })
        }
      })
    },
    getData(){
      axios.get(baseurl + 'api/support/session-years-data').then((response)=>{
        console.log(response)
        this.sessions = response.data.sessions;
        this.years = response.data.years
        this.categories = response.data.categories
      }).catch((error)=>{

      })
    },
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    },
    addFind: function () {
      this.form.finds.push({ catId: '' , cat_wise_amount: ''});
    },
    deleteFind: function (index) {
      this.form.finds.splice(index, 1);
    },
  },
}
</script>

<style scoped>

</style>
