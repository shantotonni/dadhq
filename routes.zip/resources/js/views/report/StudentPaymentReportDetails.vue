<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Student Bill Payment Details']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <router-link :to="{name: 'StudentPaymentReport'}" class="btn btn-primary btn-sm">
                <i class="fas fa-sync"></i>
                Back
              </router-link>
            </div>
          </div>
        </div>
      </breadcrumb>

      <div class="row">
        <div class="col-xl-12">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-12">
                      <h4 class="page-title" style="font-size: 14px">Student Bill Payment List</h4>
                      <div class="table-responsive">
                        <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                          <thead>
                          <tr>
                            <th class="text-center">SN</th>
                            <th class="text-center">Student Name</th>
                            <th class="text-center">Student Category</th>
                            <th class="text-center">Roll</th>
                            <th class="text-center">Session</th>
                            <th class="text-center">Payment Date</th>
                            <th class="text-center">PO/HO/IRM No</th>
                            <th class="text-center">PO/HO/IRM Date</th>
                            <th class="text-center">Bank</th>
                            <th class="text-center">Branch</th>
                            <th class="text-center">Account No</th>
                            <th class="text-center">Status</th>
                          </tr>
                          </thead>
                          <tbody>
                          <tr v-for="(bill, i) in student_payment_bill" :key="bill.id" v-if="student_payment_bill.length">
                            <th scope="row">{{ ++i }}</th>
                            <td>{{ bill.name }}</td>
                            <td>{{ bill.student_category }}</td>
                            <td>{{ bill.roll_no }}</td>
                            <td>{{ bill.session }}</td>
                            <td>{{ bill.payment_date }}</td>
                            <td>{{ bill.po_do_no }}</td>
                            <td>{{ bill.po_date }}</td>
                            <td>{{ bill.bank }}</td>
                            <td>{{ bill.branch }}</td>
                            <td>{{ bill.account_no }}</td>
                            <td>{{ bill.status }}</td>
                          </tr>
                          </tbody>
                        </table>
                      </div>

                      <h4 class="page-title" style="font-size: 14px">Payment Details</h4>
                      <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                          <thead>
                          <tr>
                            <th>Payment Head</th>
                            <th>Amount BDT</th>
                            <th>Amount USD</th>
                          </tr>
                          </thead>
                          <tbody>
                          <tr v-for="(detail, i) in details" :key="detail.id" v-if="details.length">
                            <td>{{ detail.payment_head }}</td>
                            <td>৳ {{ detail.amount_bdt }}</td>
                            <td>$ {{ detail.amount_usd }}</td>
                          </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <data-export/>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';

export default {
  name: "List",
  components: {
    Datepicker
  },
  data() {
    return {
      student_payment_bill: [],
      details: [],
      bill_schedule: [],
    }
  },
  created() {
    axios.get(baseurl + `api/report/student_payment_report_details/${this.$route.params.roll_no}/${this.$route.params.batch_number}`).then((response)=>{
      console.log(response.data)
       this.student_payment_bill = response.data.student_payment_bill.data
       this.details = response.data.payment_details
      // this.bill_schedule = response.data.bill_schedule
    });
  },
}
</script>

<style scoped>

</style>