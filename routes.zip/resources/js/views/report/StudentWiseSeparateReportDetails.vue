<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Student Bill Payment Details']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <router-link :to="{name: 'StudentBillPaymentList'}" class="btn btn-primary btn-sm">
                <i class="fas fa-sync"></i>
                Back
              </router-link>
            </div>
          </div>
        </div>
      </breadcrumb>

      <div class="row">
        <div class="col-xl-12">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-6">
                      <h4 class="page-title" style="font-size: 14px">Student Information</h4>
                      <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                          <tbody>
                            <tr>
                              <th>MRO No</th>
                              <th>{{ student_bill_payment_details.mro_no }}</th>
                            </tr>
                            <tr>
                              <th>Payment Date</th>
                              <th>{{ student_bill_payment_details.payment_date }}</th>
                            </tr>
                            <tr>
                              <th>Student Name</th>
                              <th>{{ student_bill_payment_details.name }}</th>
                            </tr>
                            <tr>
                              <th>Student Category</th>
                              <th>{{ student_bill_payment_details.student_category }}</th>
                            </tr>
                            <tr>
                              <th>Student Roll</th>
                              <th>{{ student_bill_payment_details.roll_no }}</th>
                            </tr>
                            <tr>
                              <th>Batch</th>
                              <th>{{ student_bill_payment_details.batch_number }}</th>
                            </tr>
                            <tr>
                              <th>Student Session</th>
                              <th>{{ student_bill_payment_details.session }}</th>
                            </tr>
                          </tbody>
                        </table>
                      </div>

                      <h4 class="page-title" style="font-size: 14px">Payment Details</h4>
                      <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                          <thead>
                            <tr>
                              <th>Payment Head</th>
                              <th>Amount BDT</th>
                              <th>Amount USD</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr v-for="(detail, i) in details" :key="detail.id" v-if="details.length">
                              <td>{{ detail.payment_head }}</td>
                              <td>{{ student_bill_payment_details.symbol }} {{ detail.amount_bdt }}</td>
                              <td>{{ detail.amount_usd }}</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                    <div class="col-md-6">
                      <h4 class="page-title" style="font-size: 14px">Financial Information</h4>
                      <h4 class="page-title" style="font-size: 12px">Pay From Info</h4>
                      <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                          <tbody>
                            <tr>
                              <th>Bank Name</th>
                              <th>{{ student_bill_payment_details.pay_from_bank_name }}</th>
                            </tr>
                            <tr>
                              <th>Account No</th>
                              <th>{{ student_bill_payment_details.pay_from_account_no }}</th>
                            </tr>
                            <tr>
                              <th>PO/HO/IRM No</th>
                              <th>{{ student_bill_payment_details.po_do_no }}</th>
                            </tr>
                            <tr>
                              <th>PO/HO/IRM Date</th>
                              <th>{{ student_bill_payment_details.po_date }}</th>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                      <br>
                      <h4 class="page-title" style="font-size: 12px">Pay To Info</h4>
                      <div class="table-responsive">
                        <table class="table table-bordered table-striped table-hover dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                          <tbody>
                          <tr>
                            <th>Bank Name</th>
                            <th>{{ student_bill_payment_details.bank }}</th>
                          </tr>
                          <tr>
                            <th>Branch Name</th>
                            <th>{{ student_bill_payment_details.branch }}</th>
                          </tr>
                          <tr>
                            <th>Account No</th>
                            <th>{{ student_bill_payment_details.account_no }}</th>
                          </tr>
                          <tr>
                            <th>Currency</th>
                            <th>{{ student_bill_payment_details.currency }}</th>
                          </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <data-export/>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
import {bus} from "../../app";
export default {
  name: "List",
  components: {
    Datepicker
  },
  data() {
    return {
      student_bill_payment_details: [],
      details: [],
    }
  },
  created() {
    axios.get(baseurl + `api/student-payment-bill-details/${this.$route.params.student_id}`).then((response)=>{
      this.student_bill_payment_details = response.data.data
      this.details = response.data.data.finds
    });
  },
}
</script>

