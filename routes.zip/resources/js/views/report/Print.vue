<template>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
            <div class="datatable" v-if="!isLoading">
              <div class="card-body">
                <br>
                <br>
                <div class="first_part">
                  <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                    <thead>
                    <tr style="color: black">
                      <th>SN</th>
                      <th>Student Name</th>
                      <th>Student Category</th>
                      <th>Roll</th>
                      <th>Session</th>
                      <th>Currency</th>
                      <th class="text-right">Amount BDT</th>
                      <th class="text-right">Amount USD</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr v-for="(bill, i) in getAllFilterVal" :key="bill.id" v-if="getAllFilterVal.length">
                      <td>{{ ++i }}</td>
                      <td>{{ bill.name }}</td>
                      <td>{{ bill.student_category }}</td>
                      <td>{{ bill.roll_no }}</td>
                      <td>{{ bill.session }}</td>
                      <td>{{ bill.currency }}</td>
                      <td class="text-right">৳ {{ bill.amount_bdt }}</td>
                      <td class="text-right">$ {{ bill.amount_usd }}</td>
                    </tr>
                    </tbody>
                    <tfoot style="background: #8f8d8d;color: white">
                      <tr v-if="getAllFilterVal.length">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td style="color: black">Total</td>
                        <td class="text-right" style="color: black" >৳ {{ totalAmountBDT(getAllFilterVal).toLocaleString() }}</td>
                        <td class="text-right" style="color: black" >$ {{ totalAmountUSD(getAllFilterVal) }}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import {bus} from "../../app";
export default {
  name: "List",
  data() {
    return {
      student_payment_report: [],
      isMessage : false,
      isLoading: false,
      sessionId: '',
      categoryId: '',
      from_date: '',
      to_date: '',
    }
  },
  computed: {
    getAllFilterVal(){
      return this.$store.state.allFilterVal;
    },
  },
  mounted() {
    setTimeout(function(){
      window.print()
    },2000)
  },
  created() {
   //
  },

  methods: {
    totalAmountBDT: function (values) {
      return values.reduce((acc, val) => {
        return acc + parseInt(val.amount_bdt);
      }, 0);
    },
    totalAmountUSD: function (values) {
      return values.reduce((acc, val) => {
        return acc + parseInt(val.amount_usd);
      }, 0);
    },
  },
}
</script>

<style lang="scss" scoped>

</style>
