<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Head Wise Payment Report']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <router-link :to="{name: 'HeadWisePaymentReport'}" class="btn btn-primary btn-sm">
                <i class="fas fa-sync"></i>
                Back
              </router-link>
            </div>
          </div>
        </div>
      </breadcrumb>
      <div class="row">
        <div class="col-xl-12">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="datatable" v-if="!isLoading">
                  <div class="card-body">
                    <div class="student">
                      <h2 style="text-align: center;font-weight: bold;margin: 0;color:#6a6ad1">Medical College for Women & Hospital</h2>
                      <p style="text-align: center;color: green;font-weight: 600;margin: 0;">(A project of the medical & Health Welfare Trust)</p>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175)">Plot-4,Road-9,Sector-1,Uttara Model Town,Dhaka-1230,Bangladesh</p>
                      <p style="text-align: center;font-weight: 600;margin: 0;color:rgb(107 107 175)">Phone:88-02-8913939,88-02,8916005,Fax:88-02-7912428</p>
                      <p style="text-align: center;font-weight: 400;margin: 0;color:rgb(107 107 175)">Email:medicalcollegeforwomen@yahoo.com;Web:www.medicalcollegeforwomen.edu.bd</p>
                      <h3 style="text-align: center;font-weight: bold;color: rgb(106, 106, 209);border:1px solid">Student Payment Report</h3>
                      <div class="col-md-12 first_part" >
                        <div class="table-responsive">
                          <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                            <thead>
                            <tr style="background: white;color: black">
                              <th class="text-center">SN</th>
                              <th class="text-center">Session</th>
                              <th class="text-center">Student Name</th>
                              <th class="text-center">Student Roll</th>
                              <th class="text-center">Student Batch</th>
                              <th class="text-center">Expected Payment Date</th>
                              <th class="text-center">Payment head</th>
                              <th class="text-center">Total Amount</th>
                              <th class="text-center">Paid Amount</th>
                              <th class="text-center">Due amount</th>
                            </tr>
                            </thead>
                            <tbody>
                            <tr v-for="(bill, i) in student_bill_report" :key="bill.student_bill_id" v-if="student_bill_report.length">
                              <th scope="row">{{ ++i }}</th>
                              <td>{{ bill.session }}</td>
                              <td>{{ bill.student_name }}</td>
                              <td>{{ bill.student_roll }}</td>
                              <td>{{ bill.student_batch }}</td>
                              <td>{{ bill.expected_payment_date }}</td>
                              <td>{{ bill.payment_head }}</td>
                              <td class="text-right">{{ bill.currency_symbol }} {{ bill.amount }}</td>
                              <td class="text-right">{{ bill.currency_symbol }} {{ bill.paid_amount }}</td>
                              <td class="text-right">{{ bill.currency_symbol }} {{ bill.due_amount }}</td>
                            </tr>
                            </tbody>
                            <tfoot style="background: #8f8d8d;color: white">
                            <tr v-if="student_bill_report.length" style="background: white;color: black">
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td></td>
                              <td>Total</td>
                              <td class="text-right">৳ {{ totalAmount(student_bill_report) }}</td>
                              <td class="text-right">$ {{ totalPaidAmount(student_bill_report) }}</td>
                              <td class="text-right">$ {{ totalDueAmount(student_bill_report) }}</td>
                            </tr>
                            </tfoot>
                          </table>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
                <div v-else>
                  <skeleton-loader :row="14"/>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
import {Common} from "../../mixins/common";
export default {
  name: "List",
  mixins: [Common],
  components: {
    Datepicker
  },
  data() {
    return {
      student_bill_report: {},
      isLoading: false,
      isDisabled: true,
    }
  },
  created() {
    axios.get(baseurl + `api/report/head_wise_payment_report_print/${this.$route.params.sessionId}/${this.$route.params.roll_no}/${this.$route.params.studentBatch}`).then((response)=>{
      this.student_bill_report = response.data.data
      setTimeout(function(){
        window.print()
      },2000)
    });
  },

  mounted() {
    document.title = 'Student Payment Bill Print | Bill';
  },
  methods: {
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    },

    totalAmount: function (values) {
      return values.reduce((acc, val) => {
        return acc + parseInt(val.amount);
      }, 0);
    },
    totalPaidAmount: function (values) {
      return values.reduce((acc, val) => {
        return acc + parseInt(val.paid_amount);
      }, 0);
    },
    totalDueAmount: function (values) {
      return values.reduce((acc, val) => {
        return acc + parseInt(val.due_amount);
      }, 0);
    },
  },
}
</script>

<style scoped>
.side_note label{
  font-size: 11px!important;
  margin-bottom: 0;
}
.side_note .form-control {
  height: 25px!important;
}
.side_note .form-group {
  margin-bottom: 0;
}
p{
  margin: 5px;
}
.first_part p{
  margin: 0;
}
</style>
