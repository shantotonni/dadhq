<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Student Individual Report']">

      </breadcrumb>

      <div class="row">
        <div class="col-xl-12">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex">
                    <div class="flex-grow-1">
                      <div class="row">
                        <div class="col-md-2">
                          <div class="form-group">
                            <select name="sessionId" id="sessionId" v-model="sessionId" class="form-control" @change="sessionWiseStudent()">
                              <option disabled value="">Select Session</option>
                              <option :value="session.session_id" v-for="(session , index) in sessions" :key="index">{{ session.name }}</option>
                            </select>
                          </div>
                        </div>

                        <div class="col-md-2">
                          <div class="form-group">
                            <input type="text" class="form-control" v-model="studentBatch" name="studentBatch" placeholder="Student Batch" readonly>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="form-group">
                            <input type="text" class="form-control" v-model="roll_no" name="roll_no" placeholder="Select Roll">
                          </div>
                        </div>
                        <div class="col-md-2">
                          <button type="submit" @click="getStudentIndividualReport" class="btn btn-success"><i class="mdi mdi-filter"></i>Filter</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
      <div class="row">
        <div class="col-md-9">
          <div class="card">
            <div class="card-body">
              <h3 style="font-size: 14px">Student Bill Payment Details</h3>
              <div class="table-responsive">
                <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                  <thead>
                  <tr style="font-size: 9px">
                    <th class="text-center">SN</th>
                    <th class="text-center">Student Category</th>
                    <th class="text-center">Student Name</th>
                    <th class="text-center">Student Roll</th>
                    <th class="text-center">Student Batch</th>
                    <th class="text-center">Payment Date</th>
                    <th class="text-center">Payment head</th>
                    <th class="text-center">Bank</th>
                    <th class="text-center">Branch</th>
                    <th class="text-center">Account No</th>
                    <th class="text-center">PO/DO no</th>
                    <th class="text-center">PO/DO Date</th>
                    <th class="text-center">Total Amount</th>
                    <th class="text-center">Paid Amount BDT</th>
                    <th class="text-center">Due amount BDT</th>
                    <th class="text-center">Paid Amount USD</th>
                    <th class="text-center">Due amount USD</th>
                    <th class="text-center">Remarks</th>
                  </tr>
                  </thead>
                      <tbody>
                        <tr v-for="(bill, i) in student_Individual_payment" :key="bill.student_bill_id" v-if="student_Individual_payment.length" style="font-size: 9px">
                          <th scope="row">{{ ++i }}</th>
                          <td>{{ bill.student_category }}</td>
                          <td>{{ bill.student_name }}</td>
                          <td>{{ bill.roll_no }}</td>
                          <td>{{ bill.batch_number }}</td>
                          <td>{{ bill.payment_date }}</td>
                          <td>{{ bill.payment_head }}</td>
                          <td>{{ bill.bank }}</td>
                          <td>{{ bill.branch }}</td>
                          <td>{{ bill.account_no }}</td>
                          <td>{{ bill.po_do_no }}</td>
                          <td>{{ bill.po_date }}</td>
                          <td>{{ bill.total_amount }}</td>
                          <td>৳ {{ bill.paid_amount_bdt.toLocaleString() }}</td>
                          <td>৳ {{ bill.due_amount_bdt.toLocaleString() }}</td>
                          <td>$ {{ bill.paid_amount_usd }}</td>
                          <td>৳ {{ bill.due_amount_usd }}</td>
                          <td> {{ bill.remarks }}</td>
                        </tr>
                      </tbody>
                </table>
              </div>
              <br>
              <h3 style="font-size: 14px">Student Hostel Bill Details</h3>
              <div class="table-responsive">
                <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                  <thead>
                  <tr>
                    <th>SN</th>
                    <th>Received From</th>
                    <th>Category</th>
                    <th>Session</th>
                    <th>Roll</th>
                    <th>Batch Number</th>
                    <th>From Month</th>
                    <th>ID Card</th>
                    <th>Room No</th>
                    <th>Seat No</th>
                    <th>Bank Name</th>
                    <th>Branch Name</th>
                    <th>PO/HO/IRM No</th>
                    <th>Total Amount</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr v-for="(fee, i) in hostel_fee" :key="fee.id" v-if="hostel_fee.length">
                    <th scope="row">{{ ++i }}</th>
                    <td>{{ fee.received_from }}</td>
                    <td>{{ fee.category }}</td>
                    <td>{{ fee.session }}</td>
                    <td>{{ fee.roll_no }}</td>
                    <td>{{ fee.batch_number }}</td>
                    <td>{{ fee.from_month }}</td>
                    <td>{{ fee.id_card }}</td>
                    <td>{{ fee.room_no }}</td>
                    <td>{{ fee.seat_no }}</td>
                    <td>{{ fee.bank_name }}</td>
                    <td>{{ fee.branch_name }}</td>
                    <td>{{ fee.po_do_no }}</td>
                    <td>{{ fee.total_amount }}</td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
        <div class="col-md-3">
          <div class="card">
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                  <thead>
                  <tr style="font-size: 9px">
                    <th class="text-center">Head</th>
                    <th class="text-center">Paid Amount</th>
                    <th class="text-center">Due Amount</th>
                  </tr>
                  </thead>
                  <tbody>
                  <tr v-for="(shedule, i) in student_bill_shedule" :key="shedule.student_bill_id" v-if="student_bill_shedule.length" style="font-size: 9px">
                    <td>{{ shedule.payment_head }}</td>
                    <td>{{ shedule.paid_amount }}</td>
                    <td>{{ shedule.due_amount }}</td>
                  </tr>
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
export default {
  name: "List",
  components: {
    Datepicker
  },
  data() {
    return {
      student_Individual_payment: [],
      student_bill_shedule: [],
      hostel_fee: [],
      sessions: [],
      query: "",
      editMode: false,
      isLoading: false,
      roll_no: '',
      sessionId: '',
      studentBatch: '',
    }
  },
  mounted() {
    document.title = 'Student Individual Report | Bill';
    this.getStudentIndividualReport();
    this.getAllSession();
  },
  methods: {
    getStudentIndividualReport(){
      axios.get(baseurl + 'api/report/student-individual-payment-report?sessionId='+ this.sessionId
          + "&studentBatch=" + this.studentBatch
          + "&roll_no=" + this.roll_no
      ).then((response)=>{
        console.log(response)
        this.student_Individual_payment = response.data.payment_summary_report.data;
        this.student_bill_shedule = response.data.all_student_bill.data;
        this.hostel_fee = response.data.hostel_fee.data;
      }).catch((error)=>{

      })
    },

    studentReportPrint(){
      let filterData = this.student_payment;
      this.$store.commit('filterData', filterData);
      this.$router.push({name: 'StudentReportPrint'})
    },

    exportStudentHeadWisePaymentReport(){
      axios.get(baseurl + 'api/report/export-student-head-wise-payment-report?sessionId='+ this.sessionId
          + "&studentBatch=" + this.studentBatch
          + "&roll_no=" + this.roll_no
      ).then((response)=>{
        console.log(response)
        let dataSets = response.data.data;
        if (dataSets.length > 0) {
          let columns = Object.keys(dataSets[0]);
          columns = columns.filter((item) => item !== 'row_num');
          let rex = /([A-Z])([A-Z])([a-z])|([a-z])([A-Z])/g;
          columns = columns.map((item) => {
            let title = item.replace(rex, '$1$4 $2$3$5')
            return {title, key: item}
          });
          bus.$emit('data-table-import', dataSets, columns, 'Student Payment Report List')
        }
      }).catch((error)=>{
      })
    },

    // totalAmountBDT: function (values) {
    //   return values.reduce((acc, val) => {
    //     return acc + parseInt(val.amount_bdt);
    //   }, 0);
    // },
    // totalAmountUSD: function (values) {
    //   return values.reduce((acc, val) => {
    //     return acc + parseInt(val.amount_usd);
    //   }, 0);
    // },

    getAllSession(){
      axios.get(baseurl+'api/get-all-session').then((response)=>{
        this.sessions = response.data.sessions;
      }).catch((error)=>{

      })
    },
    sessionWiseStudent(){
      axios.post(baseurl+'api/session-wise-student/', {
        sessionId: this.sessionId,
      }).then((response)=>{
        this.studentBatch = response.data.session.batch_number;
      }).catch((error)=>{

      })
    },
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    }
  },
}
</script>

<style scoped>

</style>