<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Head Wise Payment Report']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <router-link :to="`head_wise_payment_report_print/${this.sessionId}/${this.roll_no}/${this.studentBatch}/${this.studentBatch}`" class="btn btn-primary btn-sm"> Print</router-link>
              <button type="button" class="btn btn-primary btn-sm" @click="exportStudentHeadWisePaymentReport">
                <i class="fas fa-sync"></i>
                Export
              </button>
            </div>
          </div>
        </div>
      </breadcrumb>

      <div class="row">
        <div class="col-xl-12">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                  <div class="d-flex">
                    <div class="flex-grow-1">
                      <div class="row">
                        <div class="col-md-2">
                          <div class="form-group">
                            <select name="sessionId" id="sessionId" v-model="sessionId" class="form-control" @change="sessionWiseStudent()">
                              <option disabled value="">Select Session</option>
                              <option :value="session.session_id" v-for="(session , index) in sessions" :key="index">{{ session.name }}</option>
                            </select>
                          </div>
                        </div>

                        <div class="col-md-2">
                          <div class="form-group">
                            <input type="text" class="form-control" v-model="studentBatch" name="studentBatch" placeholder="Student Batch" readonly>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="form-group">
                            <select name="headId" id="headId" v-model="headId" class="form-control">
                              <option disabled value="">Select Head</option>
                              <option :value="head.year_id" v-for="(head , index) in heads" :key="index">{{ head.name }}</option>
                            </select>
                          </div>
                        </div>
                        <div class="col-md-2">
                          <div class="form-group">
                            <input type="text" class="form-control" v-model="roll_no" name="roll_no" placeholder="Select Roll">
                          </div>
                        </div>
                        <div class="col-md-2">
                          <button type="submit" @click="getAllStudentPaymentList" class="btn btn-success"><i class="mdi mdi-filter"></i>Filter</button>
                        </div>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                  <div class="table-responsive">
                    <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                      <thead>
                      <tr>
                        <th class="text-center">SN</th>
                        <th class="text-center">Student Name</th>
                        <th class="text-center">Student Roll</th>
                        <th class="text-center">Expected Payment Date</th>
                        <th class="text-center">Payment head</th>
                        <th class="text-center">Total Amount</th>
                        <th class="text-center">Paid Amount</th>
                        <th class="text-center">Due amount</th>
                      </tr>
                      </thead>
                      <tbody>
                      <tr v-for="(bill, i) in student_payment" :key="bill.student_bill_id" v-if="student_payment.length">
                        <th scope="row">{{ ++i }}</th>
                        <td>{{ bill.student_name }}</td>
                        <td>{{ bill.student_roll }}</td>
                        <td>{{ bill.expected_payment_date }}</td>
                        <td>{{ bill.payment_head }}</td>
                        <td class="text-right">{{ bill.currency_symbol }} {{ bill.amount }}</td>
                        <td class="text-right">{{ bill.currency_symbol }} {{ bill.paid_amount }}</td>
                        <td class="text-right">{{ bill.currency_symbol }} {{ bill.due_amount }}</td>
                      </tr>
                      </tbody>
                      <tfoot v-if="total_amount" style="background: #8f8d8d;color: white">
                      <tr v-if="student_payment.length">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td>Total</td>
                        <td class="text-right">৳ {{ totalAmount(student_payment) }}</td>
                        <td class="text-right">$ {{ totalPaidAmount(student_payment) }}</td>
                        <td class="text-right">$ {{ totalDueAmount(student_payment) }}</td>
                      </tr>
                      </tfoot>
                    </table>
                  </div>
                  <br>
                  <div class="row">
                    <div class="col-4">
                      <div class="data-count">
                        Show {{ pagination.from }} to {{ pagination.to }} of {{ pagination.total }} rows
                      </div>
                    </div>
                    <div class="col-8">
                      <pagination
                          v-if="pagination.last_page > 1"
                          :pagination="pagination"
                          :offset="5"
                          @paginate="query === '' ? getAllStudentPaymentList() : searchData()"
                      ></pagination>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <data-export/>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
import {bus} from "../../app";
export default {
  name: "List",
  components: {
    Datepicker
  },
  data() {
    return {
      student_payment: [],
      sessions: [],
      heads: [],
      pagination: {
        current_page: 1,
        from: 1,
        to: 1,
        total: 1,
      },
      query: "",
      editMode: false,
      isLoading: false,
      studentId: '',
      roll_no: '',
      sessionId: '',
      headId: '',
      studentBatch: '',
      total_amount: false,
    }
  },
  watch: {
    query: function(newQ, old) {
      if (newQ === "") {
        this.getAllStudentPaymentList();
      } else {
        this.searchData();
      }
    }
  },
  mounted() {
    document.title = 'Head Wise Report | Bill';
    this.getAllStudentPaymentList();
    this.getAllSession();
    this.getAllHead();
  },
  methods: {
    getAllStudentPaymentList(){
      if (this.sessionId){
        this.total_amount = true;
      }
      axios.get(baseurl + 'api/report/head-wise-student-payment-report?page='+ this.pagination.current_page
          + "&sessionId=" + this.sessionId
          + "&headId=" + this.headId
          + "&roll_no=" + this.roll_no
      ).then((response)=>{
        console.log(response)
        this.student_payment = response.data.data;
        this.pagination = response.data.meta;
      }).catch((error)=>{

      })
    },

    studentReportPrint(){
      let filterData = this.student_payment;
      this.$store.commit('filterData', filterData);
      this.$router.push({name: 'StudentReportPrint'})
    },

    exportStudentHeadWisePaymentReport(){
      axios.get(baseurl + 'api/report/export-student-head-wise-payment-report?sessionId='+ this.sessionId
          + "&headId=" + this.headId
          + "&roll_no=" + this.roll_no
      ).then((response)=>{
        console.log(response)
        let dataSets = response.data.data;
        if (dataSets.length > 0) {
          let columns = Object.keys(dataSets[0]);
          columns = columns.filter((item) => item !== 'row_num');
          let rex = /([A-Z])([A-Z])([a-z])|([a-z])([A-Z])/g;
          columns = columns.map((item) => {
            let title = item.replace(rex, '$1$4 $2$3$5')
            return {title, key: item}
          });
          bus.$emit('data-table-import', dataSets, columns, 'Student Payment Report List')
        }
      }).catch((error)=>{
        //error result
      })
    },

    totalAmount: function (values) {
      return values.reduce((acc, val) => {
        return acc + parseInt(val.amount);
      }, 0);
    },
    totalPaidAmount: function (values) {
      return values.reduce((acc, val) => {
        return acc + parseInt(val.paid_amount);
      }, 0);
    },
    totalDueAmount: function (values) {
      return values.reduce((acc, val) => {
        return acc + parseInt(val.due_amount);
      }, 0);
    },

    getAllSession(){
      axios.get(baseurl+'api/get-all-session').then((response)=>{
        this.sessions = response.data.sessions;
      }).catch((error)=>{

      })
    },
    sessionWiseStudent(){
      axios.post(baseurl+'api/session-wise-student/', {
        sessionId: this.sessionId,
      }).then((response)=>{
        //this.students = response.data.data;
        this.studentBatch = response.data.session.batch_number;
      }).catch((error)=>{

      })
    },
    getAllHead(){
      axios.get(baseurl+'api/get-all-head').then((response)=>{
        this.heads = response.data.heads;
      }).catch((error)=>{

      })
    },
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    }
  },
}
</script>

<style scoped>

</style>