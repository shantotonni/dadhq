<template>
  <div class="content">
    <div class="container-fluid">
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
            <div class="datatable" v-if="!isLoading">
              <div class="card-body">
                <br>
                <h3 style="text-align: center">Student Hostel Bill</h3>
                <br>
                <div class="first_part">
                  <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                    <thead>
                    <tr style="color: black">
                      <th>SN</th>
                      <th>Received From</th>
                      <th>Student Category</th>
                      <th>Session</th>
                      <th>Roll</th>
                      <th>Batch Number</th>
                      <th class="text-center">Amount</th>
                    </tr>
                    </thead>
                    <tbody>
                    <tr v-for="(bill, i) in getAllHostelFilterVal" :key="bill.id" v-if="getAllHostelFilterVal.length">
                      <td>{{ ++i }}</td>
                      <td>{{ bill.received_from }}</td>
                      <td>{{ bill.CategoryName }}</td>
                      <td>{{ bill.SessionName }}</td>
                      <td>{{ bill.roll_no }}</td>
                      <td>{{ bill.batch_number }}</td>
                      <td class="text-right">৳ {{ bill.amount }}</td>
                    </tr>
                    </tbody>
                    <tfoot style="background: #8f8d8d;color: white">
                      <tr v-if="getAllHostelFilterVal.length">
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td style="color: black">Total</td>
                        <td class="text-right" style="color: black" >৳ {{ totalAmount(getAllHostelFilterVal) }}</td>
                      </tr>
                    </tfoot>
                  </table>
                </div>
                </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import {bus} from "../../app";
export default {
  name: "List",
  data() {
    return {
      isMessage : false,
      isLoading: false,
      sessionId: '',
      categoryId: '',
      from_date: '',
      to_date: '',
    }
  },
  computed: {
    getAllHostelFilterVal(){
      return this.$store.state.allHostelFilterVal;
    },
  },
  mounted() {
    setTimeout(function(){
      window.print()
    },2000)
  },
  created() {
   //
  },

  methods: {
    totalAmount: function (values) {
      return values.reduce((acc, val) => {
        return acc + parseInt(val.amount);
      }, 0);
    },
  },
}
</script>

<style lang="scss" scoped>

</style>
