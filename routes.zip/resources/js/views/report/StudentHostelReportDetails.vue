<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Student Hostel Report Details']">
        <div class="col-sm-6">
          <div class="float-right d-none d-md-block">
            <div class="card-tools">
              <router-link :to="{name: 'StudentHostelBillReport'}" class="btn btn-primary btn-sm">
                <i class="fas fa-sync"></i>
                Back
              </router-link>
            </div>
          </div>
        </div>
      </breadcrumb>

      <div class="row">
        <div class="col-xl-12">
          <div class="row">
            <div class="col-md-12">
              <div class="card">
                <div class="card-body">
                  <div class="row">
                    <div class="col-md-12">
                      <h4 class="page-title" style="font-size: 14px">Student Hostel Report Details List</h4>
                      <div class="table-responsive">
                        <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                          <thead>
                          <tr>
                            <th>SN</th>
                            <th>Title</th>
                            <th>Received From</th>
                            <th>Category</th>
                            <th>Session</th>
                            <th>Roll</th>
                            <th>Batch Number</th>
                            <th>From Month</th>
                            <th>To Month</th>
                            <th>ID Card</th>
                            <th>Room No</th>
                            <th>Seat No</th>
                            <th>Pay from(Bank name) </th>
                            <th>Pay from(Account no) </th>
                            <th>Bank Name</th>
                            <th>Branch Name</th>
                            <th>Account no</th>
                            <th>PO/HO/IRM No</th>
                            <th>Total Amount</th>
                            <th>Remarks</th>
                          </tr>
                          </thead>
                          <tbody>
                          <tr v-for="(fee, i) in details" :key="fee.id" v-if="details.length">
                            <th scope="row">{{ ++i }}</th>
                            <td>{{ fee.title }}</td>
                            <td>{{ fee.received_from }}</td>
                            <td>{{ fee.category }}</td>
                            <td>{{ fee.session }}</td>
                            <td>{{ fee.roll_no }}</td>
                            <td>{{ fee.batch_number }}</td>
                            <td>{{ fee.from_month }}</td>
                            <td>{{ fee.to_month }}</td>
                            <td>{{ fee.id_card }}</td>
                            <td>{{ fee.room_no }}</td>
                            <td>{{ fee.seat_no }}</td>
                            <td>{{ fee.pay_from_bank_name }}</td>
                            <td>{{ fee.pay_from_account_no }}</td>
                            <td>{{ fee.bank_name }}</td>
                            <td>{{ fee.branch_name }}</td>
                            <td>{{ fee.account_no }}</td>
                            <td>{{ fee.po_do_no }}</td>
                            <td>৳ {{ fee.total_amount }}</td>
                            <td>{{ fee.remarks }}</td>
                          </tr>
                          </tbody>
                        </table>
                      </div>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
    <data-export/>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
import Datepicker from 'vuejs-datepicker';

export default {
  name: "List",
  components: {
    Datepicker
  },
  data() {
    return {
      details: [],
    }
  },
  created() {
    axios.get(baseurl + `api/report/student-hostel-report-details/${this.$route.params.roll_no}/${this.$route.params.batch_number}`).then((response)=>{
      console.log(response.data)
      this.details = response.data.data
    });
  },
}
</script>


<style scoped>

</style>