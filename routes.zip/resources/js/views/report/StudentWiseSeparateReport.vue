<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Student Separate Report']"/>
      <div class="row">
        <div class="col-md-12">
          <div class="card">
            <div class="card-body">
              <div class="d-flex">
                <div class="flex-grow-1">
                  <div class="row">
                    <div class="col-md-2">
                      <div class="form-group">
                        <select name="sessionId" id="sessionId" v-model="sessionId" class="form-control">
                          <option disabled value="">Select Session</option>
                          <option :value="session.session_id" v-for="(session , index) in sessions" :key="index">{{ session.name }}</option>
                        </select>
                      </div>
                    </div>
                    <div class="col-md-2">
                      <div class="form-group">
                        <input v-model="roll_number" type="text" class="form-control" placeholder="Roll Number">
                      </div>
                    </div>
                    <div class="col-md-2">
                      <button type="submit" @click="getAllStudent" class="btn btn-success"><i class="mdi mdi-filter"></i>Filter</button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        <div class="col-xl-12">
          <div class="card">
            <div class="datatable" v-if="!isLoading">
              <div class="card-body">
                <div class="d-flex">
                  <div class="flex-grow-1">
                    <div class="row">
                      <div class="col-md-2">
<!--                        <input v-model="query" type="text" class="form-control" placeholder="Search">-->
                      </div>
                    </div>
                  </div>
                  <div class="card-tools">
                    <button type="button" class="btn btn-primary btn-sm" @click="reload">
                      <i class="fas fa-sync"></i>
                      Reload
                    </button>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                    <thead>
                      <tr>
                        <th>SN</th>
                        <th>Session name</th>
                        <th>Student Name</th>
                        <th>Student Type</th>
                        <th>Roll</th>
                        <th>Nationality</th>
                        <th>Status</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(student, i) in students" :key="student.student_id" v-if="students.length">
                        <th scope="row">{{ ++i }}</th>
                        <td>{{ student.session_name }}</td>
                        <td>{{ student.first_name }} {{ student.last_name }}</td>
                        <td>{{ student.category_name }}</td>
                        <td>{{ student.roll_no }}</td>
                        <td>{{ student.nationality }}</td>
                        <td>{{ student.status }}</td>
                        <td>
                          <router-link :to="`details-student-bill-payment-report/${student.student_id}`" class="btn btn-info btn-sm"><i class="mdi mdi-eye"></i></router-link>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                </div>
                <div class="row">
                  <div class="col-4">
                    <div class="data-count">
                      Show {{ pagination.from }} to {{ pagination.to }} of {{ pagination.total }} rows
                    </div>
                  </div>
                  <div class="col-8">
                    <pagination
                        v-if="pagination.last_page > 1"
                        :pagination="pagination"
                        :offset="5"
                        @paginate="query === '' ? getAllStudent() : searchData()"
                    ></pagination>
                  </div>
                </div>
              </div>
            </div>
            <div v-else>
              <skeleton-loader :row="14"/>
            </div>
          </div>
        </div>
      </div>
    </div>
    </div>
</template>

<script>
import Datepicker from 'vuejs-datepicker';
import moment from "moment";
import {baseurl} from '../../base_url'
export default {
  name: "List",
  components: {
    Datepicker
  },
  data() {
    return {
      students: [],
      sessions: [],
      schedules: [],
      categories: [],
      session:{},
      pagination: {
        current_page: 1,
        from: 1,
        to: 1,
        total: 1,
      },
      query: "",
      editMode: false,
      isLoading: false,
      sessionId:'',
      roll_number:'',
    }
  },
  watch: {
    query: function(newQ, old) {
      if (newQ === "") {
        this.getAllStudent();
      } else {
        this.searchData();
      }
    }
  },
  mounted() {
    document.title = 'Student List | Bill';
    this.getAllStudent();
    this.getAllSession();
  },
  methods: {
    getAllStudent(){
      axios.get(baseurl+ 'api/student?page='+ this.pagination.current_page
          + "&sessionId=" + this.sessionId
          + "&roll_number=" + this.roll_number
      ).then((response)=>{
        this.students = response.data.data;
        this.pagination = response.data.meta;
      }).catch((error)=>{

      })
    },
    searchData(){
      axios.get(baseurl+"api/search/student/" + this.query + "?page=" + this.pagination.current_page).then(response => {
        this.students = response.data.data;
        this.pagination = response.data.meta;
      }).catch(e => {
        this.isLoading = false;
      });
    },
    reload(){
      this.query = "";
      this.sessionId = '',
      this.roll_number = '',
      this.getAllStudent();
      this.$toaster.success('Data Successfully Refresh');
    },

    getAllSession(){
      axios.get(baseurl+'api/get-all-session').then((response)=>{
        this.sessions = response.data.sessions;
      }).catch((error)=>{

      })
    },
    getAllCategory(){
      axios.get(baseurl+'api/get-all-category').then((response)=>{
        this.categories = response.data.categories;
      }).catch((error)=>{

      })
    },
    customFormatter(date) {
      return moment(date).format('YYYY-MM-DD');
    }
  },
}
</script>

<style scoped>

</style>
