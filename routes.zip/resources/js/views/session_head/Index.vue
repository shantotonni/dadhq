<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Sessions Fees']">
        <button class="btn btn-primary" @click="addSessionHead()">Add Session Head</button>
      </breadcrumb>
      <advanced-datatable :options="tableOptions">
        <template slot="action" slot-scope="row">
          <a href="javascript:" @click="addSessionHead(row.item)"> <i class="ti-pencil-alt"></i></a>
        </template>
      </advanced-datatable>
      <add-edit-session-head @changeStatus="changeStatus" v-if="loading"/>
      <reset-password @changeStatus="changeStatus" v-if="loading"/>
    </div>
  </div>
</template>
<script>
import {bus} from "../../app";
import {Common} from "../../mixins/common";

export default {
  mixins: [Common],
  data() {
    return {
      tableOptions: {
        source: 'session-head/list',
        search: false,
        slots: [3],
        hideColumn: ['session_head_id'],
        slotsName: ['action'],
        sortable: [],
        pages: [20, 50, 100],
        addHeader: ['Action']
      },
      loading: false,
      cpLoading: false
    }
  },
  mounted() {
    bus.$off('changeStatus',function () {
      this.changeStatus()
    })
  },
  methods: {
    changeStatus() {
      this.loading = false
    },
    addSessionHead(row = '') {
      this.loading = true;
      setTimeout(() => {
        bus.$emit('add-edit-session-head', row);
      })
    }
  }
}
</script>
