<template>
  <div class="content">
    <div class="container-fluid">
      <breadcrumb :options="['Purpose List']"/>
      <div class="row">
        <div class="col-xl-12">
          <div class="card">
            <div class="datatable" v-if="!isLoading">
              <div class="card-body">
                <div class="d-flex">
                  <div class="flex-grow-1">
                    <div class="row">
                      <div class="col-md-2">
                        <input v-model="query" type="text" class="form-control" placeholder="Search">
                      </div>
                    </div>
                  </div>
                  <div class="card-tools">
                    <button type="button" class="btn btn-success btn-sm" @click="createPurpose">
                      <i class="fas fa-plus"></i>
                      Add Purpose
                    </button>
                    <button type="button" class="btn btn-primary btn-sm" @click="reload">
                      <i class="fas fa-sync"></i>
                      Reload
                    </button>
                  </div>
                </div>
                <div class="table-responsive">
                  <table class="table table-bordered table-striped dt-responsive nowrap dataTable no-footer dtr-inline table-sm small">
                    <thead>
                      <tr>
                        <th>SN</th>
                        <th>Purpose Name</th>
                        <th>Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      <tr v-for="(purpose, i) in purposes" :key="purpose.id" v-if="purposes.length">
                        <th scope="row">{{ ++i }}</th>
                        <td>{{ purpose.name }}</td>
                        <td>
                          <button @click="edit(purpose)" class="btn btn-success btn-sm"><i class="far fa-edit"></i></button>
                         <button @click="destroy(purpose.id)" class="btn btn-danger btn-sm"><i class="fas fa-trash"></i></button>
                        </td>
                      </tr>
                    </tbody>
                  </table>
                  <br>
                  <pagination
                      v-if="pagination.last_page > 1"
                      :pagination="pagination"
                      :offset="5"
                      @paginate="query === '' ? getAllPurpose() : searchData()"
                  ></pagination>
                </div>
              </div>
            </div>
            <div v-else>
              <skeleton-loader :row="14"/>
            </div>
          </div>
        </div>
      </div>
    </div>
    <!--  Modal content for the above example -->
    <div class="modal fade" id="PurposeModal" tabindex="-1" role="dialog" aria-labelledby="myLargeModalLabel" aria-hidden="true">
      <div class="modal-dialog modal-lg">
        <div class="modal-content">
          <div class="modal-header">
            <h5 class="modal-title mt-0" id="myLargeModalLabel">{{ editMode ? "Edit" : "Add" }} Purpose</h5>
            <button type="button" class="close" data-dismiss="modal" aria-hidden="true" @click="closeModal">×</button>
          </div>
          <form @submit.prevent="editMode ? update() : store()" @keydown="form.onKeydown($event)">
            <div class="modal-body">
              <div class="col-md-12">
                <div class="row">
                  <div class="col-md-6">
                    <div class="form-group">
                      <label>Purpose Name</label>
                      <input type="text" name="name" v-model="form.name" class="form-control" :class="{ 'is-invalid': form.errors.has('name') }">
                      <div class="error" v-if="form.errors.has('name')" v-html="form.errors.get('name')" />
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <div class="modal-footer">
              <button type="button" class="btn btn-secondary" data-dismiss="modal" @click="closeModal">Close</button>
              <button :disabled="form.busy" type="submit" class="btn btn-primary">{{ editMode ? "Update" : "Create" }} Purpose</button>
            </div>
          </form>
        </div>
      </div>
    </div>
  </div>
</template>

<script>
import {baseurl} from '../../base_url'
export default {
  name: "List",
  data() {
    return {
      purposes: [],
      pagination: {
        current_page: 1
      },
      query: "",
      editMode: false,
      isLoading: false,
      form: new Form({
        id :'',
        name :'',
      }),
    }
  },
  watch: {
    query: function(newQ, old) {
      if (newQ === "") {
        this.getAllPurpose();
      } else {
        this.searchData();
      }
    }
  },
  mounted() {
    document.title = 'Purpose List | Bill';
    this.getAllPurpose();
  },
  methods: {
    getAllPurpose(){
      this.isLoading = true;
      axios.get(baseurl + 'api/purpose?page='+ this.pagination.current_page).then((response)=>{
        console.log(response)
        this.purposes = response.data.data;
        this.pagination = response.data.meta;
        this.isLoading = false;
      }).catch((error)=>{

      })
    },
    searchData(){
      axios.get(baseurl + "api/search/purpose/" + this.query + "?page=" + this.pagination.current_page).then(response => {
        this.purposes = response.data.data;
        this.pagination = response.data.meta;
      }).catch(e => {
        this.isLoading = false;
      });
    },
    reload(){
      this.getAllPurpose();
      this.query = "";
      this.$toaster.success('Data Successfully Refresh');
    },
    closeModal(){
      $("#PurposeModal").modal("hide");
    },
    createPurpose(){
      this.editMode = false;
      this.form.reset();
      this.form.clear();
      $("#PurposeModal").modal("show");
    },
    store(){
      this.form.busy = true;
      this.form.post(baseurl + "api/purpose").then(response => {
        $("#PurposeModal").modal("hide");
        this.getAllPurpose();
      }).catch(e => {
        this.isLoading = false;
      });
    },
    edit(category) {
      this.editMode = true;
      this.form.reset();
      this.form.clear();
      this.form.fill(category);
      $("#PurposeModal").modal("show");
    },
    update(){
      this.form.busy = true;
      this.form.put(baseurl + "api/purpose/" + this.form.id).then(response => {
        $("#PurposeModal").modal("hide");
        this.getAllPurpose();
      }).catch(e => {
        this.isLoading = false;
      });
    },
    destroy(id){
      Swal.fire({
        title: 'You can not delete this item',
         text: "You won't be able to revert this!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
         confirmButtonText: 'Yes, delete it!'
      }).then((result) => {
        if (result.isConfirmed) {
          axios.delete(baseurl + 'api/purpose/'+ id).then((response)=>{
            this.getAllPurpose();
            Swal.fire(
                'Deleted!',
                'Your file has been deleted.',
                'success'
            )
          })
        }
      })
    },
  },
}
</script>

<style scoped>

</style>
