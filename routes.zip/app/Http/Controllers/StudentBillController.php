<?php

namespace App\Http\Controllers;

use App\Exports\StudentScheduleData;
use App\Http\Requests\Student\StudentBillRequest;
use App\Http\Requests\Student\StudentRequest;
use App\Http\Resources\Student\StudentBillCollection;
use App\Http\Resources\Student\StudentCollection;
use App\Models\Sessions;
use App\Models\Student;
use App\Models\StudentBill;
use Illuminate\Support\Facades\Auth;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Facades\Excel;

class StudentBillController extends Controller
{
    public function index(Request $request)
    {
        $student_batch = $request->studentBatch;
        $roll_no = $request->roll_no;
        $sessionId = $request->sessionId;

        $student = Student::where('batch_number',$student_batch)->where('roll_no',$roll_no)->first();

        $student_bill = StudentBill::query()->orderBy('ordering','asc')->with('student','student.category.currency','student.session','student.category');
        if (!empty($student)){
            $student_bill = $student_bill->where('student_id',$student->student_id);
        }
        if (!empty($roll_no)){
            $student_bill = $student_bill->whereHas('student',function ($query) use ($roll_no){
                $query->where('roll_no',$roll_no);
            });
        }
        if (!empty($sessionId)){
            $student_bill = $student_bill->whereHas('student',function ($query) use ($sessionId){
                $query->where('session_id',$sessionId);
            });
        }

        $student_bill = $student_bill->paginate(15);
        return new StudentBillCollection($student_bill);
    }

    public function store(StudentBillRequest $request)
    {
        $student_bill = new StudentBill();
        $student_bill->student_id = $request->student_id;
        $student_bill->payment_head = $request->payment_head;
        $student_bill->amount = $request->amount;
        $student_bill->paid_amount = $request->paid_amount;
        $student_bill->due_amount = $request->amount;
        $student_bill->expected_payment_date = date('Y-m-d',strtotime($request->expected_payment_date));
        $student_bill->ordering = $request->ordering;

        $student_bill->created_by = Auth::user()->user_id;
        $student_bill->created_by_ip = $_SERVER['REMOTE_ADDR'];
        $student_bill->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Student Bill created successfully'
        ]);
    }

    public function update(StudentBillRequest $request,$id)
    {
        $student_bill = StudentBill::where('student_bill_id', $request->student_bill_id)->first();
        //$student_bill->student_id = $request->student_id;
        $student_bill->payment_head = $request->payment_head;
        $student_bill->amount = $request->amount;
        $student_bill->paid_amount = $request->paid_amount;
        $student_bill->due_amount = $request->amount;
        $student_bill->expected_payment_date = $request->expected_payment_date;
        $student_bill->ordering = $request->ordering;

        $student_bill->updated_by = Auth::user()->user_id;
        $student_bill->updated_by_ip = $_SERVER['REMOTE_ADDR'];
        $student_bill->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Student Bill Updated successfully'
        ]);
    }

    public function destroy($id)
    {
        StudentBill::where('student_bill_id',$id)->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'Student Bill Deleted successfully'
        ]);
    }

    public function search($query)
    {
        return new StudentBillCollection(StudentBill::where('payment_head','LIKE',"%$query%")->latest()->paginate(20));
    }

    public function exportStudentWiseSchedule(Request $request){
        $studentBatch = $request->studentBatch;
        $roll_no = $request->roll_no;
        $sessionId = $request->sessionId;
        $student = Student::where('roll_no',$roll_no)->where('batch_number',$studentBatch)->where('session_id',$sessionId)->first();

        $students = StudentBill::query()->orderBy('ordering','asc')->with('student');
        if (!empty($student)){
            $students = $students->where('student_id',$student->student_id);
        }

        $students = $students->get();
        return new StudentBillCollection($students);
    }

    public function sessionWiseStudent(Request $request){
       // $students = Student::where('session_id',$request->sessionId)->get();
        //return new StudentCollection($students);

        $session = Sessions::where('session_id',$request->sessionId)->first();
        return response()->json([
            'status' => 'success',
            'session' => $session
        ]);
    }

    public function sessionRollWiseStudent(Request $request){
        $student = Student::where('session_id',$request->session_id)->where('roll_no',$request->roll_no)->first();
        if ($student){
            return response()->json([
                'status' => 'success',
                'student' => $student
            ]);
        }else{
            return response()->json([
                'status' => 'success',
                'student' => 'No Found'
            ]);
        }

    }
}
