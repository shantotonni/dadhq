<?php

namespace App\Http\Controllers;

use App\Http\Resources\MiscellaniousCollection;
use App\Http\Resources\MiscellaniousResource;
use App\Models\Miscellanious;
use App\Models\Sessions;
use Illuminate\Http\Request;

class MiscellaniousController extends Controller
{
    public function index(Request $request)
    {
        $sessionId = $request->sessionId;
        $categoryId = $request->categoryId;

        $miscellanious = Miscellanious::orderBy('id','desc')->with('purpose');

        if (!empty($sessionId)){
            $miscellanious = $miscellanious->where('session',$sessionId);
        }
        if (!empty($categoryId)){
            $miscellanious = $miscellanious->where('category',$categoryId);
        }

        $miscellanious = $miscellanious->paginate(15);

        return new MiscellaniousCollection($miscellanious);
    }

    public function store(Request $request)
    {
        $this->validate($request,[
            'purpose_id' => 'required',
            'title' => 'required',
            'amount' => 'required',
            'check_no' => 'required',
            'payment_date' => 'required',
        ]);

        $session = Sessions::where('session_id',$request->session_id)->first();

        $miscellanious = new Miscellanious();
        $miscellanious->purpose_id = $request->purpose_id;
        $miscellanious->title = $request->title;
        $miscellanious->amount = $request->amount;
        $miscellanious->check_no = $request->check_no;
        $miscellanious->payment_date = date('Y-m-d',strtotime($request->payment_date));
        $miscellanious->roll_no = $request->roll_no;
        $miscellanious->batch_number = $request->batch_number;
        $miscellanious->session = $session->name;
        $miscellanious->category = $request->category;
        $miscellanious->received_from = $request->received_from;
        $miscellanious->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Miscellanious created successfully'
        ]);
    }

    public function update(Request $request,$id)
    {
        $this->validate($request,[
            'purpose_id' => 'required',
            'title' => 'required',
            'amount' => 'required',
            'check_no' => 'required',
            'payment_date' => 'required',
        ]);

        $session = Sessions::where('session_id',$request->session_id)->first();

        $miscellanious =Miscellanious::find($id);
        $miscellanious->purpose_id = $request->purpose_id;
        $miscellanious->title = $request->title;
        $miscellanious->amount = $request->amount;
        $miscellanious->check_no = $request->check_no;
        $miscellanious->payment_date = date('Y-m-d',strtotime($request->payment_date));
        $miscellanious->roll_no = $request->roll_no;
        $miscellanious->batch_number = $request->batch_number;
        $miscellanious->session = $session->name;
        $miscellanious->category = $request->category;
        $miscellanious->received_from = $request->received_from;
        $miscellanious->save();


        return response()->json([
            'status' => 'success',
            'message' => 'Miscellanious Updated successfully'
        ]);
    }

    public function destroy($id)
    {
        Miscellanious::where('id',$id)->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'Category Deleted successfully'
        ]);
    }

    public function search($query)
    {
        return new MiscellaniousCollection(Miscellanious::where('roll_no','LIKE',"%$query%")->latest()->paginate(20));
    }

    public function miscellaneousInvoice($id){
        $miscellanious = Miscellanious::orderBy('id','desc')->where('id',$id)->with('purpose')->first();
        return new MiscellaniousResource($miscellanious);
    }
}
