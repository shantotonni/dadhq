<?php

namespace App\Http\Controllers;

use App\Models\SessionHead;
use Illuminate\Http\Request;

class SessionHeadController extends Controller
{
    public function index(Request $request)
    {
        $take = $request->take;
        return SessionHead::select('session_heads.session_head_id','sessions.name as Session','heads.name as Head','session_heads.amount as Amount')
            ->join('sessions','sessions.session_id','session_heads.session_id')
            ->join('heads','heads.head_id','session_heads.head_id')->paginate($take);
    }

    public function store(Request $request)
    {
        $request->validate([
            'session_id' => 'required',
            'head_id' => 'required'
        ]);
        try {
            SessionHead::create([
                'session_id' => $request->session_id,
                'head_id' => $request->head_id,
                'amount' => $request->amount
            ]);
            return response()->json([
                'status' => 'success',
                'message' => 'Session Head configured successfully.'
            ]);
        } catch (\Exception $exception) {
            return response()->json([
                'status' => 'error',
                'message' => 'Something went wrong! '.$exception->getMessage()
            ],500);
        }
    }

    public function update(Request $request,$id)
    {
        $request->validate([
            'session_id' => 'required',
            'head_id' => 'required',
            'amount' => 'required'
        ]);
        try {
            SessionHead::where('session_head_id',$id)->update([
                'session_id' => $request->session_id,
                'head_id' => $request->head_id,
                'amount' => $request->amount
            ]);
            return response()->json([
                'status' => 'success',
                'message' => 'Session Head has been updated successfully'
            ]);
        } catch (\Exception $exception) {
            return response()->json([
                'status' => 'error',
                'message' => $exception->getMessage()
            ],500);
        }
    }

    public function byId($id)
    {
        return response()->json([
            'status' => 'success',
            'data' => SessionHead::where('session_head_id',$id)->first()
        ]);
    }
}
