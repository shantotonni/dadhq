<?php

namespace App\Http\Controllers;

use App\Http\Requests\HostelFee\HostelFeeRequest;
use App\Http\Resources\HostelFee\HostelFeeCollection;
use App\Http\Resources\HostelFee\HostelFeeResource;
use App\Http\Resources\Student\StudentCollection;
use App\Models\Bank;
use App\Models\Branch;
use App\Models\HostelFee;
use App\Models\Sessions;
use App\Models\Student;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class HostelFeeController extends Controller
{
    public function index(Request $request)
    {
        $sessionId = $request->sessionId;
        $categoryId = $request->categoryId;

        $hostel_fee = HostelFee::query()->with('session','category');
        if (!empty($sessionId)){
            $hostel_fee = $hostel_fee->where('session',$sessionId);
        }
        if (!empty($categoryId)){
            $hostel_fee = $hostel_fee->where('category',$categoryId);
        }
        $hostel_fee = $hostel_fee->orderBy('id','desc')->paginate(15);
        return new HostelFeeCollection($hostel_fee);
    }

    public function store(HostelFeeRequest $request)
    {
        try {
            $bank = Bank::where('id',$request->bank_id)->first();
            $branch = Branch::where('id',$request->branch_id)->first();
            $session = Sessions::where('session_id',$request->session_id)->first();

            $hostel_fee = new HostelFee();
            $hostel_fee->from_month = date('Y-m-d',strtotime($request->from_month));
            $hostel_fee->to_month = date('Y-m-d',strtotime($request->to_month));
            $hostel_fee->mro_no = $request->mro_no;
            $hostel_fee->title = $request->title;
            $hostel_fee->received_from = $request->received_from;
            $hostel_fee->total_months = $request->total_months;
            $hostel_fee->roll_no = $request->roll_no;
            $hostel_fee->batch_number = $request->batch_number;
            $hostel_fee->id_card = $request->id_card;
            $hostel_fee->room_no = $request->room_no;
            $hostel_fee->seat_no = $request->seat_no;
            $hostel_fee->total_amount = $request->total_amount;
            $hostel_fee->remarks = $request->remarks;
            $hostel_fee->currency = $request->currency;
            $hostel_fee->bank_id = $request->bank_id;
            $hostel_fee->branch_id = $request->branch_id;
            $hostel_fee->bank_name = isset($bank) ? $bank->name : '';
            $hostel_fee->branch_name = isset($branch) ? $branch->name : '';
            $hostel_fee->category = $request->category;
            $hostel_fee->session = $session->name;
            $hostel_fee->po_do_no = $request->po_do_no;
            $hostel_fee->po_date = date('Y-m-d',strtotime($request->po_date));
            $hostel_fee->student_id = $request->student_id;
            $hostel_fee->pay_from_bank_name = $request->pay_from_bank_name;
            $hostel_fee->pay_from_account_no = $request->pay_from_account_no;
            $hostel_fee->account_no = $request->account_no;
            $hostel_fee->save();

            return response()->json([
                'status' => 'success',
                'message' => 'Hostel Fee created successfully'
            ]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'status'=>400,
                'message'=>$e->getMessage()
            ],400);
        }
    }

    public function update(HostelFeeRequest $request, $id)
    {
        try {
            $bank = Bank::where('id',$request->bank_id)->first();
            $branch = Branch::where('id',$request->branch_id)->first();
            $session = Sessions::where('session_id',$request->session_id)->first();

            $hostel_fee = HostelFee::where('id',$id)->first();
            $hostel_fee->from_month = date('Y-m-d',strtotime($request->from_month));
            $hostel_fee->to_month = date('Y-m-d',strtotime($request->to_month));
            $hostel_fee->mro_no = $request->mro_no;
            $hostel_fee->title = $request->title;
            $hostel_fee->received_from = $request->received_from;
            $hostel_fee->total_months = $request->total_months;
            $hostel_fee->roll_no = $request->roll_no;
            $hostel_fee->batch_number = $request->batch_number;
            $hostel_fee->id_card = $request->id_card;
            $hostel_fee->room_no = $request->room_no;
            $hostel_fee->seat_no = $request->seat_no;
            $hostel_fee->total_amount = $request->total_amount;
            $hostel_fee->remarks = $request->remarks;
            $hostel_fee->currency = $request->currency;
            $hostel_fee->bank_id = $request->bank_id;
            $hostel_fee->branch_id = $request->branch_id;
            $hostel_fee->bank_name = isset($bank) ? $bank->name : '';
            $hostel_fee->branch_name = isset($branch) ? $branch->name : '';
            $hostel_fee->category = $request->category;
            $hostel_fee->session = $session->name;
            $hostel_fee->po_do_no = $request->po_do_no;
            $hostel_fee->po_date = date('Y-m-d',strtotime($request->po_date));
            $hostel_fee->student_id = $request->student_id;
            $hostel_fee->pay_from_bank_name = $request->pay_from_bank_name;
            $hostel_fee->pay_from_account_no = $request->pay_from_account_no;
            $hostel_fee->account_no = $request->account_no;
            $hostel_fee->save();

            return response()->json([
                'status' => 'success',
                'message' => 'Hostel Fee created successfully'
            ]);

        } catch (\Exception $e) {
            DB::rollback();
            return response()->json([
                'status'=>400,
                'message'=>$e->getMessage()
            ],400);
        }
    }

    public function hostelFeeInvoice($id){
        $hostel_fee = HostelFee::where('id',$id)->with('session','category')->first();
        return new HostelFeeResource($hostel_fee);
    }

    public function hostelStudentList(Request $request){
        $sessionId = $request->sessionId;
        $roll_number = $request->roll_number;

        $students = Student::query()->with('session','category');
        if (!empty($sessionId)){
            $students = $students->where('session_id',$sessionId);
        }
        if (!empty($roll_number)){
            $students = $students->where('roll_no',$roll_number);
        }

        $students = $students->orderBy('student_id','desc')->where('status','Y')->paginate(15);
        return new StudentCollection($students);
    }
}
