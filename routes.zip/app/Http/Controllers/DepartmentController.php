<?php

namespace App\Http\Controllers;

use App\Models\Department;
use App\Services\DepartmentService;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class DepartmentController extends Controller
{
    public function departmentList()
    {
        $data = DepartmentService::list();
        return response()->json([
            'status' => 'success',
            'data' => $data
        ]);
    }
}
