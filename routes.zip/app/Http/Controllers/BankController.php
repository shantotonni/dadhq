<?php

namespace App\Http\Controllers;

use App\Http\Resources\Bank\BankCollection;
use App\Models\Bank;
use Illuminate\Http\Request;

class BankController extends Controller
{
    public function index()
    {
        $banks = Bank::orderBy('id','desc')->paginate(15);
        return new BankCollection($banks);
    }

    public function store(Request $request)
    {
        $this->validate($request,[
            'name' => 'required'
        ]);

        $bank = new Bank();
        $bank->name = $request->name;
        $bank->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Bank created successfully'
        ]);
    }

    public function update(Request $request,$id)
    {
        $this->validate($request,[
            'name' => 'required'
        ]);

        $bank = Bank::find($id);
        $bank->name = $request->name;
        $bank->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Bank Updated successfully'
        ]);
    }

    public function destroy($id)
    {
        Bank::where('id',$id)->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'Category Deleted successfully'
        ]);
    }

    public function search($query)
    {
        return new BankCollection(Bank::where('name','LIKE',"%$query%")->latest()->paginate(20));
    }
}
