<?php

namespace App\Http\Controllers;

use App\Models\Advances;
use App\Models\Banks;
use App\Models\Business;
use App\Models\Requisitions;
use App\Services\BusinessService;
use App\Services\PaymentModeService;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\DB;

class RequisitionController extends Controller
{
    public function pending(Request $request)
    {
        $take = $request->take;
        $search = $request->search;
        $query = Requisitions::join('Users', 'Users.StaffID', 'Requisitions.CreatedBy')
            ->where(function ($q) use ($search) {
                $q->where('Requisitions.RequisitionID', 'like', '%' . $search . '%');
            });
        $query->where('Requisitions.CreatedBy',Auth::user()->StaffID);
        $query->where('Requisitions.Status', 'Pending')
            ->where('Requisitions.Deleted', 0)
            ->orderBy('Requisitions.CreatedAt', 'desc')
            ->select('Requisitions.RequisitionID', DB::raw("CONCAT(Users.StaffName,'(',Users.StaffID,')') as StaffName"), 'Requisitions.TotalAdvance', 'Requisitions.PaymentRequiredBy', 'Requisitions.CreatedAt')
            ->paginate($take);
        return $query->paginate($take);
    }

    public function approved(Request $request)
    {
        $take = $request->take;
        $search = $request->search;
        $query = Requisitions::join('Users', 'Users.StaffID', 'Requisitions.CreatedBy')
            ->where(function ($q) use ($search) {
                $q->where('Requisitions.RequisitionID', 'like', '%' . $search . '%');
            });
        $query->where('Requisitions.CreatedBy',Auth::user()->StaffID);
        $query->where('Requisitions.Status', 'Approved')
            ->where('Requisitions.Deleted', 0)
            ->orderBy('Requisitions.CreatedAt', 'desc')
            ->select('Requisitions.RequisitionID', DB::raw("CONCAT(Users.StaffName,'(',Users.StaffID,')') as StaffName"), 'Requisitions.TotalAdvance', 'Requisitions.PaymentRequiredBy', 'Requisitions.Status', 'Requisitions.CreatedAt')
            ->paginate($take);
        return $query->paginate($take);
    }

    public function rejected(Request $request)
    {
        $take = $request->take;
        $search = $request->search;
        $query = Requisitions::join('Users', 'Users.StaffID', 'Requisitions.CreatedBy')
            ->where(function ($q) use ($search) {
                $q->where('Requisitions.RequisitionID', 'like', '%' . $search . '%');
            });
        $query->where('Requisitions.CreatedBy',Auth::user()->StaffID);
        $query->where('Requisitions.Status', 'Rejected')
            ->where('Requisitions.Deleted', 0)
            ->orderBy('Requisitions.CreatedAt', 'desc')
            ->select('Requisitions.RequisitionID', DB::raw("CONCAT(Users.StaffName,'(',Users.StaffID,')') as StaffName"), 'Requisitions.TotalAdvance', 'Requisitions.PaymentRequiredBy', 'Requisitions.Status', 'Requisitions.CreatedAt')
            ->paginate($take);
        return $query->paginate($take);
    }

    public function createRequisitionData(Request $request)
    {
        $requisition = '';
        if ($request->has('id') && $request->id != '') {
            $requisition = Requisitions::where('RequisitionID',$request->id)->with('advances')->first();
        }
        return response()->json([
            'status' => 'success',
            'business' => BusinessService::list(),
            'paymentModes' => PaymentModeService::list(),
            'banks' => Banks::all(),
            'requisition' => $requisition,
            'businessList' => BusinessService::list(),
            'me' => Auth::user()
        ]);
    }

    public function store(Request $request)
    {
        DB::beginTransaction();
        try {
            if (count($request->fields) > 0) {
                $auth = Auth::user();
                $requisition = new Requisitions();
                $requisition->CreatedBy = $auth->StaffID;
                $requisition->CreatedByIP = $request->ip();
                $requisition->Status = 'Pending';
                $requisition->PaymentRequiredBy = $request->paymentDate;
                $requisition->TotalAdvance = array_sum(array_column($request->fields, 'amount'));
                $requisition->CreatedAt = Carbon::now()->format('Y-m-d H:i:s');
                $requisition->UpdatedAt = Carbon::now()->format('Y-m-d H:i:s');
                $requisition->save();
                $data = [];
                foreach ($request->fields as $key => $field) {
                    $data[] = [
                        'AdvanceID' => $requisition->RequisitionID . sprintf("%02d", $key + 1),
                        'RequisitionID' => $requisition->RequisitionID,
                        'ResStaffID' => $field['staffId'],
                        'ResStaffName' => $field['staffName'],
                        'ResStaffDesignation' => $field['designation'],
                        'ResStaffDepartment' => $field['department'],
                        'ResStaffEmail' => $field['email'],
                        'ResStaffMobile' => $field['mobile'],
                        'CreatedBy' => $auth->StaffID,
                        'CreatedByIP' => $request->ip(),
                        'Purpose' => $field['purpose'],
                        'Amount' => $field['amount'],
                        'PaymentMode' => $field['payment_mode'],
                        'ProgramDate' => $field['program_date'],
                        'AdjustmentDueDate' => $field['due_date'],
                        'AdvanceForBusiness' => $field['advance_for_business']['Business'],
                        'Remarks' => $field['remarks'],
                        'Payee' => $field['payee'],
                        'AccountNo' => isset($field['account_number']) && $field['account_number'] !== '' ? $field['account_number'] : NULL,
                        'BankID' => isset($field['bank_id']) && $field['bank_id'] !== '' && $field['bank_id'] !== '0' ? $field['bank_id'] : NULL,
                        'BranchName' => $field['branch_name'] ?? '',
                        'RoutingNo' => $field['routing_no'] ?? '',
                        'CreatedAt' => Carbon::now()->format('Y-m-d H:i:s'),
                        'UpdatedAt' => Carbon::now()->format('Y-m-d H:i:s')
                    ];
                }
                Advances::insert($data);
                DB::commit();
                return response()->json([
                    'status' => 'success',
                    'message' => 'Requisition Submitted.',
                    'requisitionID' => $requisition->RequisitionID
                ]);
            }
            return response()->json([
                'status' => 'error',
                'message' => 'No data passed!'
            ], 400);
        } catch (\Exception $exception) {
            DB::rollBack();
            return response()->json([
                'status' => 'success',
                'message' => $exception->getMessage()
            ], 500);
        }
    }

    public function update(Request $request)
    {
        DB::beginTransaction();
        try {
            $request->validate([
                'requisitionId' => 'required'
            ]);
            if (count($request->fields) > 0) {
                $auth = Auth::user();
                //REMOVE ADVANCES
                Advances::where('RequisitionID',$request->requisitionId)->delete();
                //INSERT ADVANCES
                $requisition = Requisitions::find($request->requisitionId);
                $old = $requisition;
                if ($requisition->Status !== 'Pending') {
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Not a pending status'
                    ],400);
                }
                $requisition->EditedBy = $auth->StaffID;
                $requisition->EditedByIP = $request->ip();
                $requisition->Status = 'Pending';
                $requisition->PaymentRequiredBy = $request->paymentDate;
                $requisition->TotalAdvance = array_sum(array_column($request->fields, 'amount'));
                $requisition->UpdatedAt = Carbon::now()->format('Y-m-d H:i:s');
                $requisition->save();
                $data = [];
                foreach ($request->fields as $key => $field) {
                    $data[] = [
                        'AdvanceID' => $requisition->RequisitionID . sprintf("%02d", $key + 1),
                        'RequisitionID' => $requisition->RequisitionID,
                        'ResStaffID' => $field['staffId'],
                        'ResStaffName' => $field['staffName'],
                        'ResStaffDesignation' => $field['designation'],
                        'ResStaffDepartment' => $field['department'],
                        'ResStaffEmail' => $field['email'],
                        'ResStaffMobile' => $field['mobile'],
                        'Purpose' => $field['purpose'],
                        'Amount' => $field['amount'],
                        'PaymentMode' => $field['payment_mode'],
                        'ProgramDate' => $field['program_date'],
                        'AdjustmentDueDate' => $field['due_date'],
                        'AdvanceForBusiness' => $field['advance_for_business'],
                        'Remarks' => $field['remarks'],
                        'Payee' => $field['payee'],
                        'AccountNo' => isset($field['account_number']) && $field['account_number'] !== '' ? $field['account_number'] : NULL,
                        'BankID' => isset($field['bank_id']) && $field['bank_id'] !== '' && $field['bank_id'] !== '0' ? $field['bank_id'] : NULL,
                        'BranchName' => $field['branch_name'] ?? '',
                        'RoutingNo' => $field['routing_no'] ?? '',
                        'CreatedAt' => $old->CreatedAt,
                        'UpdatedAt' => Carbon::now()->format('Y-m-d H:i:s')
                    ];
                }
                Advances::insert($data);
                DB::commit();
                return response()->json([
                    'status' => 'success',
                    'message' => 'Requisition Submitted.'
                ]);
            }
            return response()->json([
                'status' => 'error',
                'message' => 'No data passed!'
            ], 400);
        } catch (\Exception $exception) {
            DB::rollBack();
            return response()->json([
                'status' => 'success',
                'message' => $exception->getMessage()
            ], 500);
        }
    }

    public function byId($id)
    {
        $query = Requisitions::where('RequisitionID', $id)->with(['advances', 'representative', 'representative.business', 'advances.bank','advances.paymentModeName'])->first();
        if ($query) {
            return response()->json([
                'status' => 'success',
                'data' => $query
            ]);
        }
        return response()->json([
            'status' => 'error',
            'data' => []
        ], 400);
    }

    public function destroy($id)
    {
        $req = Requisitions::where('RequisitionID',$id);
        if ($first = $req->first()) {
            if ($first->Status === 'Pending') {
                $req->update([
                   'Deleted' => 1
                ]);
                return response()->json([
                    'status' => 'success',
                    'message' => 'Requisition deleted successfully'
                ]);
            }
        }
        return response()->json([
            'status' => 'error',
            'message' => 'Something went wrong!'
        ],400);
    }
}
