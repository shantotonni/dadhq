<?php

namespace App\Http\Controllers;

use App\Http\Resources\Branch\BranchCollection;
use App\Models\Branch;
use Illuminate\Http\Request;

class BranchController extends Controller
{
    public function index()
    {
        $branches = Branch::orderBy('id','desc')->with('bank')->paginate(15);
        return new BranchCollection($branches);
    }

    public function store(Request $request)
    {
        $this->validate($request,[
            'bank_id' => 'required',
            'name' => 'required'
        ]);

        $branch             = new Branch();
        $branch->bank_id    = $request->bank_id;
        $branch->name       = $request->name;
        $branch->account_no = $request->account_no;
        $branch->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Branch created successfully'
        ]);
    }

    public function update(Request $request,$id)
    {
        $this->validate($request,[
            'bank_id' => 'required',
            'name' => 'required'
        ]);

        $branch             = Branch::find($id);
        $branch->bank_id    = $request->bank_id;
        $branch->name       = $request->name;
        $branch->account_no = $request->account_no;
        $branch->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Branch Updated successfully'
        ]);
    }

    public function destroy($id)
    {
        Branch::where('id',$id)->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'Branch Deleted successfully'
        ]);
    }

    public function search($query)
    {
        return new BranchCollection(Branch::where('name','LIKE',"%$query%")->latest()->paginate(20));
    }

    public function getAccountNoByBranch(Request $request){
        $account_no = Branch::where('bank_id',$request->bank_id)->where('id',$request->branch_id)->first();
        return response()->json([
            'status' => 'success',
            'account_no' => $account_no->account_no
        ]);
    }
}
