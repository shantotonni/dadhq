<?php

namespace App\Http\Controllers;

use App\Http\Resources\HostelBillReportCollection;
use App\Http\Resources\HostelFee\HostelFeeCollection;
use App\Http\Resources\Student\StudentBillCollection;
use App\Http\Resources\Student\StudentPaymentBillCollection;
use App\Http\Resources\Student\StudentPaymentBillResource;
use App\Http\Resources\StudentIndividualPaymentCollection;
use App\Http\Resources\StudentPaymentReportCollection;
use App\Models\HostelFee;
use App\Models\Student;
use App\Models\StudentBill;
use App\Models\StudentBillPayment;
use App\Models\StudentBillPaymentDetails;
use App\Models\Year;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class ReportController extends Controller
{
    public function studentPayment(Request $request){
        $sessionId = $request->sessionId;
        $categoryId = $request->categoryId;

//        $payment_summary_report = StudentBillPaymentDetails::query()
//            ->select('roll_no','session','batch_number',DB::raw('sum(amount_bdt) as amount_bdt'), DB::raw('sum(amount_usd) as amount_usd'))
//            ->groupBy('roll_no','session','batch_number')
//            ->get();
//
//        if (!empty($sessionId)){
//            $payment_summary_report = $payment_summary_report->where('session_id',$sessionId);
//        }
//        if (!empty($categoryId)){
//            $payment_summary_report = $payment_summary_report->where('category_id',$categoryId);
//        }
//        if (!empty($request->from_date) && !empty($request->to_date)){
//            $payment_summary_report = $payment_summary_report->whereDate('payment_date','>=',$request->from_date)->whereDate('payment_date','<=',$request->to_date);
//        }
//        $payment_summary_report = $payment_summary_report->paginate(15);
//
//        return new StudentPaymentReportCollection($payment_summary_report);

        $students = StudentBillPayment::query()->with(['student','bank','branch','category'])
            ->select('student_id','session_id','bank_id','branch_id','category_id','session','currency','name','roll_no','batch_number')
            ->groupBy('student_id','session_id','session','bank_id','branch_id','category_id','currency','name','roll_no','batch_number');

        if (!empty($sessionId)){
            $students = $students->where('session_id',$sessionId);
        }
        if (!empty($categoryId)){
            $students = $students->where('category_id',$categoryId);
        }
        if (!empty($request->from_date) && !empty($request->to_date)){
            $students = $students->whereDate('payment_date','>=',$request->from_date)->whereDate('payment_date','<=',$request->to_date);
        }

        $students = $students->paginate(15);

        return new StudentPaymentBillCollection($students);
    }

    public function studentPaymentReportDetails($roll_no, $batch_number){
        $students = StudentBillPayment::query()->orderBy('id','desc')->with(['student','bank','branch','details','details.head'])
            ->where('batch_number',$batch_number)
            ->where('roll_no',$roll_no)->get();

        $payment_details = StudentBillPaymentDetails::where('batch_number',$batch_number)->where('roll_no',$roll_no)->get();
        return response()->json([
            'student_payment_bill'=> new StudentPaymentBillCollection($students),
            'payment_details'=> $payment_details,
        ]);
    }

    public function studentPaymentReportExport(Request $request){
        $sessionId = $request->sessionId;
        $categoryId = $request->categoryId;

        $students = StudentBillPayment::query()->with('student','bank','branch','category')
            ->select('student_id','session_id','bank_id','branch_id','category_id','session','currency','name','roll_no','batch_number', DB::raw('sum(amount) as amount'))
            ->groupBy('student_id','session_id','session','bank_id','branch_id','category_id','currency','name','roll_no','batch_number');

        if (!empty($sessionId)){
            $students = $students->where('session_id',$sessionId);
        }
        if (!empty($categoryId)){
            $students = $students->where('category_id',$categoryId);
        }
        if (!empty($request->from_date) && !empty($request->to_date)){
            $students = $students->whereDate('payment_date','>=',$request->from_date)->whereDate('payment_date','<=',$request->to_date);
        }
        $students = $students->orderBy('id','desc')->paginate(15);

        return new StudentPaymentBillCollection($students);
    }

    public function studentReportPrint(Request $request){
        return $request->all();
    }

    public function studentHostelBillReport(Request $request){
        $sessionId = $request->sessionId;
        $categoryId = $request->categoryId;

        $hostelFee = HostelFee::query()->with('session','category')
            ->select('received_from','category as CategoryName','session as SessionName','roll_no','batch_number','currency', DB::raw('sum(total_amount) as amount'))
            ->groupBy('received_from','category','session','roll_no','batch_number','currency');

        if (!empty($sessionId) && !empty($categoryId)){
            $hostelFee = $hostelFee->where('session',$sessionId)->where('category',$categoryId);
        }
//        if ($categoryId){
//            $hostelFee = $hostelFee->where('category',$categoryId);
//        }
        if (!empty($request->from_date) && !empty($request->to_date)){
            $hostelFee = $hostelFee->whereDate('from_month','>=',$request->from_date)->whereDate('to_month','<=',$request->to_date);
        }
        $hostelFee = $hostelFee->paginate(15);
        return new HostelBillReportCollection($hostelFee);
    }

    public function studentHostelBillReportDetails($roll_no, $batch_number){
        $hostelFee = HostelFee::query()->with('session','category')->where('batch_number',$batch_number)->where('roll_no',$roll_no)->get();
        return new HostelFeeCollection($hostelFee);
    }

    public function studentHostelBillReportExport(Request $request){
        $sessionId = $request->sessionId;
        $categoryId = $request->categoryId;

        $hostelFee = HostelFee::query()->with('session','category')
            ->select('received_from','category as CategoryName','session as SessionName','roll_no','batch_number','currency', DB::raw('sum(total_amount) as amount'))
            ->groupBy('received_from','category','session','roll_no','batch_number','currency');

        if (!empty($sessionId) && !empty($categoryId)){
            $hostelFee = $hostelFee->where('session',$sessionId)->where('category',$categoryId);
        }
//        if ($categoryId){
//            $hostelFee = $hostelFee->where('category',$categoryId);
//        }
        if (!empty($request->from_date) && !empty($request->to_date)){
            $hostelFee = $hostelFee->whereDate('from_month','>=',$request->from_date)->whereDate('to_month','<=',$request->to_date);
        }
        $hostelFee = $hostelFee->paginate(15);
        return new HostelBillReportCollection($hostelFee);
    }

    public function headWisePaymentReport(Request $request){
        $student_batch = $request->studentBatch;
        $headId = $request->headId;
        $roll_no = $request->roll_no;
        $sessionId = $request->sessionId;

        $student_bill = StudentBill::query()->orderBy('ordering','asc')->with('student','student.category.currency');
        if (!empty($student)){
            $student = Student::where('batch_number',$student_batch)->where('roll_no',$roll_no)->first();
            $student_bill = $student_bill->where('student_id',$student->student_id);
        }
        if (!empty($roll_no)){
            $student_bill = $student_bill->whereHas('student',function ($query) use ($roll_no){
                $query->where('roll_no',$roll_no);
            });
        }
        if (!empty($sessionId)){
            $student_bill = $student_bill->whereHas('student',function ($query) use ($sessionId){
                $query->where('session_id',$sessionId);
            });
        }
        if (!empty($headId)){
            $head = Year::where('year_id',$headId)->first();
            $student_bill = $student_bill->where('payment_head', $head->name);
        }

        $student_bill = $student_bill->orderBy('ordering','asc')->paginate(20);
        return new StudentBillCollection($student_bill);
    }

    public function headWisePaymentReportPrint($sessionId, $roll_no, $batchNumber){
        $student_batch = $batchNumber;

        $student_bill = StudentBill::query()->orderBy('ordering','asc')->with('student','student.category.currency');
        if (!empty($student_batch)){
            $student = Student::where('batch_number',$student_batch)->where('roll_no',$roll_no)->first();
            $student_bill = $student_bill->where('student_id',$student->student_id);
        }
        if (!empty($roll_no)){
            $student_bill = $student_bill->whereHas('student',function ($query) use ($roll_no){
                $query->where('roll_no',$roll_no);
            });
        }
        if (!empty($sessionId)){
            $student_bill = $student_bill->whereHas('student',function ($query) use ($sessionId){
                $query->where('session_id',$sessionId);
            });
        }
        if (!empty($headId)){
            $head = Year::where('year_id',$headId)->first();
            $student_bill = $student_bill->where('payment_head', $head->name);
        }

        $student_bill = $student_bill->orderBy('ordering','asc')->paginate(20);
        return new StudentBillCollection($student_bill);
    }

    public function studentIndividualReport(Request $request){
        $sessionId = $request->sessionId;
        $roll_no = $request->roll_no;
        $studentBatch = $request->studentBatch;

        if ($sessionId && $roll_no && $studentBatch){
            $payment_summary_report = StudentBillPaymentDetails::query()
                ->select('payment_head','roll_no','session','batch_number',DB::raw('sum(amount_bdt) as amount_bdt'), DB::raw('sum(amount_usd) as amount_usd'))
                ->where('roll_no',$roll_no)->where('batch_number', $studentBatch)
                ->groupBy('payment_head','roll_no','session','batch_number')
                ->get();
            $student = Student::with('category')->where('roll_no',$roll_no)->where('batch_number',$studentBatch)->first();
            $all_student_bill = StudentBill::where('student_id',$student->student_id)->get();

            $hostel_fee = HostelFee::query()->with('session','category')->where('roll_no',$roll_no)->where('batch_number',$studentBatch)->get();

            return response()->json([
                'payment_summary_report' => new StudentIndividualPaymentCollection($payment_summary_report),
                'all_student_bill' => new StudentBillCollection($all_student_bill),
                'hostel_fee' => new HostelFeeCollection($hostel_fee)
            ]);
        }else {
            return response()->json([
                'payment_summary_report' => []
            ]);
        }
    }

    public function ExportStudentHeadWisePaymentReport(Request $request){
        $headId = $request->headId;
        $sessionId = $request->sessionId;

        $student_bill = StudentBill::query()->orderBy('ordering','asc')->with('student','student.category.currency');
        if (!empty($roll_no)){
            $student_bill = $student_bill->whereHas('student',function ($query) use ($roll_no){
                $query->where('roll_no',$roll_no);
            });
        }
        if (!empty($sessionId)){
            $student_bill = $student_bill->whereHas('student',function ($query) use ($sessionId){
                $query->where('session_id',$sessionId);
            });
        }
        if (!empty($headId)){
            $head = Year::where('year_id',$headId)->first();
            $student_bill = $student_bill->where('payment_head', $head->name);
        }

        $student_bill = $student_bill->get();
        return new StudentBillCollection($student_bill);
    }
}
