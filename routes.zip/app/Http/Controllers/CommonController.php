<?php

namespace App\Http\Controllers;

use App\Http\Resources\Student\StudentCollection;
use App\Models\Bank;
use App\Models\Branch;
use App\Models\Category;
use App\Models\Currency;
use App\Models\Menu;
use App\Models\Miscellanious;
use App\Models\Purpose;
use App\Models\Role;
use App\Models\Sessions;
use App\Models\Student;
use App\Models\StudentBill;
use App\Models\StudentBillPayment;
use App\Models\Year;
use App\Services\BusinessService;
use App\Services\DepartmentService;
use App\Services\RoleService;
use Illuminate\Http\Request;

class CommonController extends Controller
{
    public function userModalData() {
        return response()->json([
            'status' => 'success',
            'roles' => RoleService::list(),
            'business' => BusinessService::list(),
            'department' => DepartmentService::list(),
            'allSubMenus' => Menu::whereNotIn('MenuID',['Dashboard','Users'])->with('allSubMenus')->get()
        ]);
    }

    public function getAllSession(){
        return response()->json([
            'status' => 'success',
            'sessions' => Sessions::all(),
        ]);
    }

    public function getAllPurpose(){
        return response()->json([
            'status' => 'success',
            'purpose' => Purpose::all(),
        ]);
    }

    public function getAllHead(){
        return response()->json([
            'status' => 'success',
            'heads' => Year::all(),
        ]);
    }

    public function getAllStudent(){
        return response()->json([
            'status' => 'success',
            'students' => new StudentCollection(Student::all()),
        ]);
    }

    public function getAllCurrency(){
        return response()->json([
            'status' => 'success',
            'currencies' => Currency::all(),
        ]);
    }

    public function getAllCategory(){
        return response()->json([
            'status' => 'success',
            'categories' => Category::all(),
        ]);
    }

    public function getAllRole(){
        return response()->json([
            'status' => 'success',
            'roles' => Role::all(),
        ]);
    }

    public function getAllBank(){
        return response()->json([
            'status' => 'success',
            'banks' => Bank::all(),
        ]);
    }

    public function getBankWiseBranches($bank_id){
        $branches = Branch::where('bank_id',$bank_id)->get();
        return response()->json([
            'status' => 'success',
            'branches' => $branches,
        ]);
    }

    public function getMroNo(){
        $mro = StudentBillPayment::orderBy('id','desc')->first();
        if ($mro){
            $no = $mro->id + 1;
        }else{
            $no = 1;
        }
        return response()->json([
            'status' => 'success',
            'mro_no' => $no,
        ]);
    }

    public function getAllPaymentMethod(){
        return response()->json([
            'status' => 'success',
            'payment_method' => Year::orderBy('ordering','asc')->get(),
        ]);
    }

    public function getRollWiseStudent(Request $request){
        $student = Student::where('session_id', $request->session_id);
        if ($request->roll_no){
            $student = $student-> where('roll_no', $request->roll_no);
        }
        if ($request->batch_number){
            $student = $student-> where('batch_number', $request->batch_number);
        }
        $student = $student->with(['session','category.currency'])->first();
        if ($student){
            $bill_schedule = StudentBill::where('student_id',$student->student_id)->orderBy('ordering','asc')->get();
            return response()->json([
                'status' => 'success',
                'student' => $student,
                'bill_schedule' => $bill_schedule,
            ]);
        }else{
            return response()->json([
                'status' => 'success',
                'student' => [],
                'bill_schedule' => [],
            ]);
        }
    }

    public function sessionWiseBatch($session_id){
        $session = Sessions::where('session_id',$session_id)->first();
        return response()->json([
            'status' => 'success',
            'batch' => $session->batch_number,
        ]);
    }
}
