<?php

namespace App\Http\Controllers;

use App\Http\Resources\Session\SessionFeeCollection;
use App\Models\Category;
use App\Models\SessionFee;
use Illuminate\Http\Request;

class SessionFeeController extends Controller
{
    public function index(Request $request)
    {
        $sessionId = $request->sessionId;
        $categoryId = $request->categoryId;
        $sessions_fess = SessionFee::with('session','year','category')->orderBy('session_fee_id','desc');
        if (!empty($sessionId) && $sessionId != 'undefined'){
            $sessions_fess = $sessions_fess->where('session_id',$sessionId);
        }
        if (!empty($categoryId) && $categoryId != 'undefined'){
            $sessions_fess = $sessions_fess->where('category_id',$categoryId);
        }
        $sessions_fess = $sessions_fess->paginate(15);
        return new SessionFeeCollection($sessions_fess);
    }

    public function store(Request $request)
    {
        $this->validate($request,[
            'session_id' => 'required',
            'year_id' => 'required',
        ]);

        try {
            $finds = $request->finds;
            foreach ($finds as $value){
                $exist = SessionFee::where('session_id',$request->session_id)->where('year_id',$request->year_id)->where('category_id',$value['catId'])->exists();
                if ($exist){
                    return response()->json([
                        'status' => 'error',
                        'message' => 'Already added'
                    ],500);
                }
            }
            foreach ($finds as $value){
                $session_fee = new SessionFee();
                $session_fee->session_id = $request->session_id;
                $session_fee->year_id = $request->year_id;
                $session_fee->category_id = $value['catId'];
                $session_fee->amount = $value['cat_wise_amount'];
                $session_fee->save();
            }
            return response()->json([
                'status' => 'success',
                'message' => 'Session fee configured successfully.'
            ]);
        } catch (\Exception $exception) {
            return response()->json([
                'status' => 'error',
                'message' => 'Something went wrong! '.$exception->getMessage()
            ],500);
        }
    }

    public function update(Request $request,$id)
    {
        $this->validate($request,[
            'session_id' => 'required',
            'year_id' => 'required',
            'category_id' => 'required',
            'amount' => 'required',
        ]);

        try {
            $session_fee = SessionFee::find($id);
            $session_fee->session_id = $request->session_id;
            $session_fee->year_id = $request->year_id;
            $session_fee->category_id = $request->category_id;
            $session_fee->amount = $request->amount;
            $session_fee->save();
            return response()->json([
                'status' => 'success',
                'message' => 'Session fee has been updated successfully'
            ]);
        } catch (\Exception $exception) {
            return response()->json([
                'status' => 'error',
                'message' => $exception->getMessage()
            ],500);
        }
    }

    public function destroy($id)
    {
        SessionFee::where('session_fee_id',$id)->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'Session Fee Deleted successfully'
        ]);
    }

    public function byId($id)
    {
        return response()->json([
            'status' => 'success',
            'data' => SessionFee::where('session_fee_id',$id)->first()
        ]);
    }
}
