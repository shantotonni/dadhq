<?php

namespace App\Http\Controllers;

use App\Models\Year;
use Illuminate\Http\Request;

class YearController extends Controller
{
    public function index(Request $request)
    {
        $take = $request->take;
        return Year::select('year_id','name as Name','ordering as Ordering','year_serial as Year Serial', 'status as Status')->where('status','Y')->orderBy('ordering','asc')->paginate($take);
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required',
            'year_serial' => 'required',
            'status' => 'required'
        ]);
        try {
            Year::create([
                'name' => $request->name,
                'ordering' => $request->ordering,
                'status' => $request->status,
                'year_serial' => $request->year_serial
            ]);
            return response()->json([
                'status' => 'success',
                'message' => 'Payment Mode has been created successfully'
            ]);
        } catch (\Exception $exception) {
            return response()->json([
                'status' => 'error',
                'message' => $exception->getMessage()
            ],500);
        }
    }

    public function update(Request $request,$id)
    {
        $request->validate([
            'name' => 'required',
            'year_serial' => 'required',
            'status' => 'required'
        ]);
        try {
            Year::where('year_id',$id)->update([
                'name' => $request->name,
                'ordering' => $request->ordering,
                'year_serial' => $request->year_serial,
                'status' => $request->status
            ]);
            return response()->json([
                'status' => 'success',
                'message' => 'Payment Mode has been updated successfully'
            ]);
        } catch (\Exception $exception) {
            return response()->json([
                'status' => 'error',
                'message' => $exception->getMessage()
            ],500);
        }
    }

    public function byId($id)
    {
        return response()->json([
            'status' => 'success',
            'data' => Year::where('year_id',$id)->first()
        ]);
    }
}
