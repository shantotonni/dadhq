<?php

namespace App\Http\Controllers;

use App\Http\Resources\PurposeCollection;
use App\Models\Purpose;
use Illuminate\Http\Request;

class PurposeController extends Controller
{
    public function index()
    {
        $puspose = Purpose::orderBy('id','desc')->paginate(15);
        return new PurposeCollection($puspose);
    }

    public function store(Request $request)
    {
        $this->validate($request,[
            'name' => 'required'
        ]);

        $puspose = new Purpose();
        $puspose->name = $request->name;
        $puspose->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Purpose created successfully'
        ]);
    }

    public function update(Request $request,$id)
    {
        $this->validate($request,[
            'name' => 'required'
        ]);

        $puspose = Purpose::find($id);
        $puspose->name = $request->name;
        $puspose->save();

        return response()->json([
            'status' => 'success',
            'message' => 'Purpose Updated successfully'
        ]);
    }

    public function destroy($id)
    {
        Purpose::where('id',$id)->delete();
        return response()->json([
            'status' => 'success',
            'message' => 'Purpose Deleted successfully'
        ]);
    }

    public function search($query)
    {
        return new PurposeCollection(Purpose::where('name','LIKE',"%$query%")->latest()->paginate(20));
    }
}
