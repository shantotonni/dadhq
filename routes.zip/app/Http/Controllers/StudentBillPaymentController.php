<?php

namespace App\Http\Controllers;

use App\Exports\Student\StudentBillPaymentExport;
use App\Exports\Student\StudentPaymentBillExport;
use App\Http\Requests\Student\StudentPaymentBillRequest;
use App\Http\Resources\Student\StudentPaymentBillCollection;
use App\Http\Resources\Student\StudentPaymentBillResource;
use App\Models\Sessions;
use App\Models\Student;
use App\Models\StudentBill;
use App\Models\StudentBillPayment;
use App\Models\StudentBillPaymentDetails;
use App\Models\Year;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Facades\Excel;

class StudentBillPaymentController extends Controller
{
    public function index(Request $request)
    {
        $sessionId = $request->sessionId;
        $roll_number = $request->roll_number;
        $bankId = $request->bank_id;
        $students = StudentBillPayment::query()->orderBy('id','desc')->with('student','bank','branch','category');
        if (!empty($sessionId)){
            $students = $students->where('session_id',$sessionId);
        }
        if (!empty($roll_number)){
            $students = $students->where('roll_no',$roll_number);
        }
        if (!empty($bankId)){
            $students = $students->where('bank_id',$bankId);
        }
        $students = $students->paginate(15);
        return new StudentPaymentBillCollection($students);
    }

    public function store(StudentPaymentBillRequest $request){

        DB::beginTransaction();
        try {
            $head_data = $request->finds;
            $session = Sessions::where('session_id',$request->session_id)->first();

            $bill_payment = new StudentBillPayment();
            $bill_payment->student_id = $request->student_id;
            $bill_payment->session_id = $request->session_id;
            $bill_payment->bank_id = $request->bank_id;
            $bill_payment->branch_id = $request->branch_id;
            $bill_payment->payment_date = date('Y-m-d',strtotime($request->payment_date));
            $bill_payment->session = $session->name;
            $bill_payment->roll_no = $request->roll_no;
            $bill_payment->batch_number = $request->batch_number;
            $bill_payment->category_id = $request->categoryId;
            $bill_payment->pay_from_bank_name = $request->pay_from_bank_name;
            $bill_payment->pay_from_account_no = $request->pay_from_account_no;
            $bill_payment->name = $request->name;
            $bill_payment->po_do_no = $request->po_do_no;
            $bill_payment->po_date = date('Y-m-d',strtotime($request->po_date));
            $bill_payment->account_no = $request->account_no;
            $bill_payment->currency = $request->currency;
            $bill_payment->remarks = $request->remarks;
            $bill_payment->late_fee = $request->late_fee;
            $bill_payment->late_fee_percentage = $request->late_fee_percentage;
            $bill_payment->late_fee_amount = $request->late_fee_amount;
            $bill_payment->status = 'Y';
            if ($bill_payment->save()){
                foreach ($head_data as $value){
                    $head = Year::where('year_id',$value['head_id'])->first();
                    $student_bill = StudentBill::where('payment_head',$head->name)->where('student_id',$request->student_id)->first();
                    //return $student_bill;

//                    if ($value['amount_bdt'] > $student_bill->due_amount){
//                        return response()->json([
//                            'status' => 'error',
//                            'message' => 'This amount should be less than Due Amount'
//                        ]);
//                    }
                    if ($request->currency == 'BDT'){
                        $student_bill->paid_amount = $student_bill->paid_amount + $value['amount_bdt'];
                        $student_bill->due_amount = $student_bill->due_amount - $value['amount_bdt'];
                    }else{
                        $student_bill->paid_amount = $student_bill->paid_amount + $value['amount_usd'];
                        $student_bill->due_amount = $student_bill->due_amount - $value['amount_usd'];
                    }
                    $student_bill->save();

                    $details               = new StudentBillPaymentDetails();
                    $details->student_bill_payment_id = $bill_payment->id;
                    $details->head_id      = $head->year_id;
                    $details->payment_head = $head->name;
                    $details->session      = $session->name;
                    $details->currency     = $request->currency;
                    $details->roll_no      = $request->roll_no;
                    $details->batch_number = $request->batch_number;
                    $details->amount_bdt   = $value['amount_bdt'];
                    $details->amount_usd   = $value['amount_usd'];
                    $details->save();
                }

                DB::commit();
                return response()->json([
                    'status' => 'success',
                    'message' => 'Payment created successfully'
                ]);
            }
        }catch (\Exception $e){
            DB::rollback();
            return response()->json([
                'status'=>400,
                'message'=>$e->getMessage()
            ],400);
        }
    }

    public function update(StudentPaymentBillRequest $request){
        DB::beginTransaction();
        try {

            $session = Sessions::where('session_id',$request->session_id)->first();

            $bill_payment = StudentBillPayment::where('id',$request->id)->first();
            $bill_payment->student_id = $request->student_id;
            $bill_payment->session_id = $request->session_id;
            $bill_payment->bank_id = $request->bank_id;
            $bill_payment->branch_id = $request->branch_id;
            $bill_payment->payment_date = date('Y-m-d',strtotime($request->payment_date));
            $bill_payment->session = $session->name;
            $bill_payment->roll_no = $request->roll_no;
            $bill_payment->batch_number = $request->batch_number;
            $bill_payment->category_id = $request->categoryId;
            $bill_payment->name = $request->name;
            $bill_payment->pay_from_bank_name = $request->pay_from_bank_name;
            $bill_payment->pay_from_account_no = $request->pay_from_account_no;
            $bill_payment->po_do_no = $request->po_do_no;
            $bill_payment->po_date = date('Y-m-d',strtotime($request->po_date));
            $bill_payment->account_no = $request->account_no;
            $bill_payment->currency = $request->currency;
            $bill_payment->remarks = $request->remarks;
            $bill_payment->late_fee = $request->late_fee;
            $bill_payment->late_fee_percentage = $request->late_fee_percentage;
            $bill_payment->late_fee_amount = $request->late_fee_amount;

            if ($bill_payment->save()){
                $this->editPaymentBill($request, $bill_payment);
                DB::commit();
                return response()->json([
                    'status' => 'success',
                    'message' => 'Payment created successfully'
                ]);
            }
        }catch (\Exception $e){
            DB::rollback();
            return response()->json([
                'status'=>400,
                'message'=>$e->getMessage()
            ],400);
        }
    }

    public function editPaymentBill($request, $bill_payment){
        $head_data = $request->finds;
        $detailsData = StudentBillPaymentDetails::where('student_bill_payment_id',$request->id)->get();
        $session = Sessions::where('session_id',$request->session_id)->first();
        foreach ($detailsData as $item){
            $head = Year::where('year_id',$item->head_id)->first();
            $student_bill = StudentBill::where('payment_head',$head->name)->where('student_id',$request->student_id)->first();
            if ($request->currency == 'BDT'){
                $student_bill->paid_amount = $student_bill->paid_amount - $item->amount_bdt;
                $student_bill->due_amount = $student_bill->due_amount + $item['amount_bdt'];
            }else{
                $student_bill->paid_amount = $student_bill->paid_amount - $item->amount_usd;
                $student_bill->due_amount = $student_bill->due_amount + $item['amount_usd'];
            }
            $student_bill->save();
        }

        StudentBillPaymentDetails::where('student_bill_payment_id',$request->id)->delete();

        foreach ($head_data as $value){

            $head = Year::where('year_id',$value['head_id'])->first();

            $student_bill = StudentBill::where('payment_head',$head->name)->where('student_id',$request->student_id)->first();

            if ($request->currency == 'BDT'){
                $student_bill->paid_amount = $student_bill->paid_amount + $value['amount_bdt'];
                $student_bill->due_amount = $student_bill->due_amount - $value['amount_bdt'];
            }else{
                $student_bill->paid_amount = $student_bill->paid_amount + $value['amount_usd'];
                $student_bill->due_amount = $student_bill->due_amount - $value['amount_usd'];
            }
            $student_bill->save();

            $details = new StudentBillPaymentDetails();
            $details->student_bill_payment_id = $bill_payment->id;
            $details->head_id = $head->year_id;
            $details->payment_head = $head->name;
            $details->session      = $session->name;
            $details->roll_no      = $request->roll_no;
            $details->currency     = $request->currency;
            $details->batch_number = $request->batch_number;
            $details->amount_bdt = $value['amount_bdt'];
            $details->amount_usd = $value['amount_usd'];
            $details->save();
        }
        return true;
    }

    public function show($id){
        $student_payment_bill = StudentBillPayment::where('id',$id)->with('student','bank','branch','details')->first();
        return new StudentPaymentBillResource($student_payment_bill);
    }

    public function details($id){

        $student_payment_bill = StudentBillPayment::where('id',$id)->with('student','bank','branch','details')->first();

        $bill_schedule = StudentBill::where('student_id',$student_payment_bill->student_id)->orderBy('ordering','asc')->get();
        return response()->json([
            'status' => 'success',
            'student_payment_bill' => new StudentPaymentBillResource($student_payment_bill),
            'bill_schedule' => $bill_schedule,
        ]);
    }

    public function destroy($id){
        DB::beginTransaction();
        try {
            $student_bill_payment = StudentBillPayment::where('id',$id)->first();

            if ($student_bill_payment){
                $detailsData = StudentBillPaymentDetails::where('student_bill_payment_id',$student_bill_payment->id)->get();
                foreach ($detailsData as $item){
                    $head = Year::where('year_id',$item->head_id)->first();
                    $student_bill = StudentBill::where('payment_head',$head->name)->where('student_id',$student_bill_payment->student_id)->first();
                    if ($student_bill_payment->currency == 'BDT'){
                        $student_bill->paid_amount = $student_bill->paid_amount - $item->amount_bdt;
                        $student_bill->due_amount = $student_bill->due_amount + $item['amount_bdt'];
                    }else{
                        $student_bill->paid_amount = $student_bill->paid_amount - $item->amount_usd;
                        $student_bill->due_amount = $student_bill->due_amount + $item['amount_usd'];
                    }
                    $student_bill->save();
                }

                StudentBillPaymentDetails::where('student_bill_payment_id',$student_bill_payment->id)->delete();
                StudentBillPayment::where('id',$id)->delete();
                DB::commit();
                return response()->json([
                    'status' => 'success',
                    'message' => 'Payment Deleted successfully'
                ]);
            }
        }catch (\Exception $e){
            DB::rollback();
            return response()->json([
                'status'=>400,
                'message'=>$e->getMessage()
            ],400);
        }
    }

    public function checkAmount(Request $request){
        //return $request->all();
        $head = Year::where('year_id',$request->head_id)->first();
        $student_bill = StudentBill::where('payment_head',$head->name)->where('student_id',$request->student_id)->first();

        if ($student_bill->due_amount == 0){
            return response()->json([
                'status' => 'error',
                'message' => 'Payment Already Done For This Head'
            ]);
        }else{
            if ($request->amount > $student_bill->due_amount ){
                return response()->json([
                    'status' => 'error',
                    'message' => 'This amount should be less than Due Amount'
                ]);
            }else{
                return response()->json([
                    'status' => 'success',
                    'message' => 'Successfully Match'
                ]);
            }
        }
    }

    public function checkAmountForEdit(Request $request){
        $head = Year::where('year_id',$request->head_id)->first();
        $student_bill = StudentBill::where('payment_head',$head->name)->where('student_id',$request->student_id)->first();

        if ($request->amount > $student_bill->amount ){
            return response()->json([
                'status' => 'error',
                'message' => 'This amount should be less than Actual Amount'
            ]);
        }else{
            return response()->json([
                'status' => 'success',
                'message' => 'Successfully Match'
            ]);
        }
    }

    public function studentPaymentBillDataExport(Request $request){

        $studentId = $request->student_id;
        $roll_number = $request->roll_number;
        $students = StudentBillPayment::query()->orderBy('id','desc')->with('student','bank','branch');
        if (!empty($studentId)){
            $students = $students->where('student_id',$studentId);
        }
        if (!empty($roll_number)){
            $students = $students->where('roll_no',$roll_number);
        }
        $students = $students->get();
        return new StudentPaymentBillCollection($students);

        //return Excel::download(new StudentBillPaymentExport($request), 'students_Payment_bill.csv');

    }

    public function billInvoice($id){
        $students = StudentBillPayment::where('id',$id)->with('student','bank','branch','category','details')->first();
        return new StudentPaymentBillResource($students);
    }

}
