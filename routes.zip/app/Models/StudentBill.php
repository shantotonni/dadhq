<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentBill extends Model
{
    use HasFactory;

    protected $table = "student_bills";
    protected $primaryKey = "student_bill_id";
    protected $guarded = [];

    public function student(){
        return $this->belongsTo(Student::class,'student_id','student_id');
    }
}
