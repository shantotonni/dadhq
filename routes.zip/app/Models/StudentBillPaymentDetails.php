<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class StudentBillPaymentDetails extends Model
{
    use HasFactory;

    protected $table = "student_bill_payment_details";
    protected $primaryKey = "id";
    protected $guarded = [];

    public function student_bill_payment(){
        return $this->belongsTo(StudentBillPayment::class,'student_bill_payment_id','id');
    }
    public function head(){
        return $this->belongsTo(StudentBill::class,'head_id','student_bill_id');
    }
}
