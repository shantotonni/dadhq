<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class SessionHead extends Model
{
    use HasFactory;

    protected $table = "session_heads";
    protected $primaryKey = "session_head_id";
    protected $guarded = [];
}
