<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class HostelFee extends Model
{
    use HasFactory;

    protected $table = 'hostel_fee';
    public $primaryKey = 'id';
    protected $guarded = [];

    public function session(){
        return $this->belongsTo(Sessions::class,'session_id','session_id');
    }

    public function category(){
        return $this->belongsTo(Category::class,'category_id','id');
    }
}
