<template>
<!--    <router-view/>-->
  <div><router-view/></div>
</template>
<script>
export default {
    data(){
        return{

        }
    }
}
</script>
